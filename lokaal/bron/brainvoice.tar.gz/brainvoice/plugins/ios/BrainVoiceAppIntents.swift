import AppIntents
import Foundation

// BrainVoice App Intents – added to the app target by plugins/withBrainVoiceIOS.js.
//
// Each intent appends a record to the App Group queue and opens the app; the JS side
// drains the queue (BrainVoiceNative.consumePendingIntents) and starts the capture flow
// with the spoken text, so the same Intent Engine, preview and undo apply.
//
// Siri phrases are declared in BrainVoiceShortcuts (AppShortcutsProvider) – no user setup needed.

enum BrainVoiceIntentQueue {
  static let appGroup = "group.com.brainvoice.app"
  static let key = "brainvoice.pendingIntents"

  static func enqueue(kind: String, text: String?) {
    guard let defaults = UserDefaults(suiteName: appGroup) else { return }
    var list = defaults.array(forKey: key) as? [[String: Any]] ?? []
    var record: [String: Any] = [
      "id": UUID().uuidString,
      "kind": kind,
      "createdAt": ISO8601DateFormatter().string(from: Date()),
    ]
    if let text { record["text"] = text }
    list.append(record)
    defaults.set(list, forKey: key)
  }
}

@available(iOS 17.0, *)
struct CaptureThoughtIntent: AppIntent {
  static var title: LocalizedStringResource = "Capture Thought"
  static var description = IntentDescription("Say anything – a thought, idea, task, reminder or event. BrainVoice understands it and asks you to confirm.")
  static var openAppWhenRun: Bool = true

  @Parameter(title: "Thought", requestValueDialog: "What do you want to capture?")
  var text: String

  func perform() async throws -> some IntentResult & ProvidesDialog {
    BrainVoiceIntentQueue.enqueue(kind: "capture", text: text)
    return .result(dialog: "Got it. Opening BrainVoice to confirm.")
  }
}

@available(iOS 17.0, *)
struct CreateTaskIntent: AppIntent {
  static var title: LocalizedStringResource = "Create Task"
  static var description = IntentDescription("Creates a task in BrainVoice.")
  static var openAppWhenRun: Bool = true

  @Parameter(title: "Task", requestValueDialog: "What is the task?")
  var text: String

  func perform() async throws -> some IntentResult & ProvidesDialog {
    BrainVoiceIntentQueue.enqueue(kind: "task", text: text)
    return .result(dialog: "Creating the task in BrainVoice.")
  }
}

@available(iOS 17.0, *)
struct CreateReminderIntent: AppIntent {
  static var title: LocalizedStringResource = "Create Reminder"
  static var description = IntentDescription("Creates a reminder in BrainVoice, e.g. “tomorrow at 8 call Yakup”.")
  static var openAppWhenRun: Bool = true

  @Parameter(title: "Reminder", requestValueDialog: "What should I remind you of, and when?")
  var text: String

  func perform() async throws -> some IntentResult & ProvidesDialog {
    BrainVoiceIntentQueue.enqueue(kind: "reminder", text: text)
    return .result(dialog: "Setting up the reminder in BrainVoice.")
  }
}

@available(iOS 17.0, *)
struct AddCalendarEventIntent: AppIntent {
  static var title: LocalizedStringResource = "Add Calendar Event"
  static var description = IntentDescription("Adds an event to your calendar through BrainVoice.")
  static var openAppWhenRun: Bool = true

  @Parameter(title: "Event", requestValueDialog: "What should I add to your calendar, and when?")
  var text: String

  func perform() async throws -> some IntentResult & ProvidesDialog {
    BrainVoiceIntentQueue.enqueue(kind: "event", text: text)
    return .result(dialog: "Adding it to your calendar with BrainVoice.")
  }
}

@available(iOS 17.0, *)
struct SetBrainVoiceAlarmIntent: AppIntent {
  static var title: LocalizedStringResource = "Set BrainVoice Alarm"
  static var description = IntentDescription("Sets an alarm through BrainVoice, e.g. “tomorrow at 6:30”.")
  static var openAppWhenRun: Bool = true

  @Parameter(title: "Alarm", requestValueDialog: "When should the alarm ring?")
  var text: String

  func perform() async throws -> some IntentResult & ProvidesDialog {
    BrainVoiceIntentQueue.enqueue(kind: "alarm", text: text)
    return .result(dialog: "Setting the alarm with BrainVoice.")
  }
}

@available(iOS 17.0, *)
struct AskBrainVoiceIntent: AppIntent {
  static var title: LocalizedStringResource = "Ask BrainVoice"
  static var description = IntentDescription("Ask what you need to do, what is scheduled, or search your notes.")
  static var openAppWhenRun: Bool = true

  @Parameter(title: "Question", requestValueDialog: "What do you want to know?")
  var question: String

  func perform() async throws -> some IntentResult & ProvidesDialog {
    BrainVoiceIntentQueue.enqueue(kind: "ask", text: question)
    return .result(dialog: "Looking that up in BrainVoice.")
  }
}

@available(iOS 17.0, *)
struct OpenBrainInboxIntent: AppIntent {
  static var title: LocalizedStringResource = "Open Brain Inbox"
  static var description = IntentDescription("Opens the Brain Inbox in BrainVoice.")
  static var openAppWhenRun: Bool = true

  func perform() async throws -> some IntentResult {
    BrainVoiceIntentQueue.enqueue(kind: "open_inbox", text: nil)
    return .result()
  }
}

@available(iOS 17.0, *)
struct BrainVoiceShortcuts: AppShortcutsProvider {
  static var shortcutTileColor: ShortcutTileColor = .purple

  static var appShortcuts: [AppShortcut] {
    AppShortcut(
      intent: CaptureThoughtIntent(),
      phrases: [
        "Capture with \(.applicationName)",
        "Capture a thought in \(.applicationName)",
        "Tell \(.applicationName) something",
        "Vastleggen met \(.applicationName)",
        "Capturer avec \(.applicationName)",
      ],
      shortTitle: "Capture",
      systemImageName: "mic.fill"
    )
    AppShortcut(
      intent: CreateReminderIntent(),
      phrases: ["Remind me with \(.applicationName)", "Create a reminder in \(.applicationName)"],
      shortTitle: "Reminder",
      systemImageName: "bell.fill"
    )
    AppShortcut(
      intent: CreateTaskIntent(),
      phrases: ["Add a task to \(.applicationName)", "Create a task in \(.applicationName)"],
      shortTitle: "Task",
      systemImageName: "checkmark.circle.fill"
    )
    AppShortcut(
      intent: AddCalendarEventIntent(),
      phrases: ["Add an event with \(.applicationName)", "Schedule with \(.applicationName)"],
      shortTitle: "Event",
      systemImageName: "calendar"
    )
    AppShortcut(
      intent: SetBrainVoiceAlarmIntent(),
      phrases: ["Set an alarm with \(.applicationName)", "Wake me with \(.applicationName)"],
      shortTitle: "Alarm",
      systemImageName: "alarm.fill"
    )
    AppShortcut(
      intent: AskBrainVoiceIntent(),
      phrases: ["Ask \(.applicationName)", "What do I need to do in \(.applicationName)"],
      shortTitle: "Ask",
      systemImageName: "questionmark.bubble.fill"
    )
    AppShortcut(
      intent: OpenBrainInboxIntent(),
      phrases: ["Open my \(.applicationName) inbox", "Show the \(.applicationName) inbox"],
      shortTitle: "Inbox",
      systemImageName: "tray.full.fill"
    )
  }
}
