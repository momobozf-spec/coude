package com.brainvoice.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

/**
 * "Tap to capture" home-screen widget. Tapping opens the app on the capture screen
 * through the deep link `brainvoice://capture?source=widget`, which starts listening
 * immediately. Registered in AndroidManifest.xml by plugins/withBrainVoiceAndroid.js.
 */
class BrainVoiceWidgetProvider : AppWidgetProvider() {
  override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
    for (appWidgetId in appWidgetIds) {
      val intent = Intent(Intent.ACTION_VIEW, Uri.parse("brainvoice://capture?source=widget")).apply {
        setPackage(context.packageName)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
      }
      val pendingIntent = PendingIntent.getActivity(
        context,
        appWidgetId,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )
      val views = RemoteViews(context.packageName, R.layout.brainvoice_widget)
      views.setOnClickPendingIntent(R.id.brainvoice_widget_root, pendingIntent)
      appWidgetManager.updateAppWidget(appWidgetId, views)
    }
  }
}
