import ExpoModulesCore
import Foundation
import SwiftUI

#if canImport(AlarmKit)
import AlarmKit
#endif

// MARK: - Records (arguments coming from JavaScript)

struct AlarmScheduleOptions: Record {
  @Field var localId: String = ""
  @Field var fireISO: String = ""
  @Field var hour: Int = 0
  @Field var minute: Int = 0
  @Field var label: String = "Alarm"
  /// ISO weekdays: 1 = Monday … 7 = Sunday. Empty = one-off alarm at `fireISO`.
  @Field var repeatWeekdays: [Int] = []
}

struct TimerScheduleOptions: Record {
  @Field var localId: String = ""
  @Field var seconds: Double = 0
  @Field var label: String = "Timer"
}

struct ClockAlarmOptions: Record {
  @Field var hour: Int = 0
  @Field var minute: Int = 0
  @Field var label: String = ""
  @Field var days: [Int] = []
  @Field var skipUi: Bool = true
}

struct ClockTimerOptions: Record {
  @Field var seconds: Int = 0
  @Field var label: String = ""
  @Field var skipUi: Bool = true
}

// MARK: - Exceptions

final class AlarmKitUnavailableException: Exception {
  override var reason: String { "AlarmKit requires iOS 26 or later" }
}

final class InvalidAlarmDateException: Exception {
  override var reason: String { "The alarm date could not be parsed" }
}

final class AlarmKitAuthorizationException: Exception {
  override var reason: String { "AlarmKit authorization was denied" }
}

// MARK: - AlarmKit metadata

#if canImport(AlarmKit)
@available(iOS 26.0, *)
nonisolated struct BrainVoiceAlarmMetadata: AlarmMetadata {
  let localId: String
  let kind: String
}
#endif

// MARK: - Module

/// BrainVoiceNative – AlarmKit bridge + App Intents queue reader.
///
/// AlarmKit (WWDC25, iOS 26) is the only supported way to create real, Clock-style alarms.
/// Countdown timers display a live countdown only when the app ships a Live Activity
/// (see native/ios-widget/README.md); without it the timer still fires as an alert.
public class BrainVoiceNativeModule: Module {
  private let appGroupId = "group.com.brainvoice.app"
  private let pendingKey = "brainvoice.pendingIntents"

  public func definition() -> ModuleDefinition {
    Name("BrainVoiceNative")

    // MARK: AlarmKit availability & authorization

    Function("isAlarmKitAvailable") { () -> Bool in
      #if canImport(AlarmKit)
      if #available(iOS 26.0, *) { return true }
      #endif
      return false
    }

    AsyncFunction("getAlarmAuthorizationStatus") { () -> String in
      #if canImport(AlarmKit)
      if #available(iOS 26.0, *) {
        return Self.describe(AlarmManager.shared.authorizationState)
      }
      #endif
      return "unavailable"
    }

    AsyncFunction("requestAlarmAuthorization") { () async throws -> String in
      #if canImport(AlarmKit)
      if #available(iOS 26.0, *) {
        let state = try await AlarmManager.shared.requestAuthorization()
        return Self.describe(state)
      }
      #endif
      return "unavailable"
    }

    // MARK: Alarms

    AsyncFunction("scheduleAlarm") { (options: AlarmScheduleOptions) async throws -> [String: Any] in
      #if canImport(AlarmKit)
      if #available(iOS 26.0, *) {
        let id = UUID()
        let stopButton = AlarmButton(text: "Stop", textColor: .white, systemImageName: "stop.fill")
        let alert = AlarmPresentation.Alert(
          title: LocalizedStringResource(stringLiteral: options.label),
          stopButton: stopButton
        )
        let attributes = AlarmAttributes<BrainVoiceAlarmMetadata>(
          presentation: AlarmPresentation(alert: alert),
          metadata: BrainVoiceAlarmMetadata(localId: options.localId, kind: "alarm"),
          tintColor: Color(red: 0.49, green: 0.36, blue: 1.0)
        )

        let schedule: Alarm.Schedule
        if !options.repeatWeekdays.isEmpty {
          let time = Alarm.Schedule.Relative.Time(hour: options.hour, minute: options.minute)
          let weekdays = options.repeatWeekdays.compactMap(Self.localeWeekday)
          schedule = .relative(Alarm.Schedule.Relative(time: time, repeats: .weekly(weekdays)))
        } else if let date = Self.parseISO(options.fireISO) {
          schedule = .fixed(date)
        } else {
          throw InvalidAlarmDateException()
        }

        let configuration = AlarmManager.AlarmConfiguration(schedule: schedule, attributes: attributes)
        _ = try await AlarmManager.shared.schedule(id: id, configuration: configuration)
        return ["externalId": id.uuidString, "backend": "alarmkit"]
      }
      #endif
      throw AlarmKitUnavailableException()
    }

    // MARK: Timers

    AsyncFunction("scheduleTimer") { (options: TimerScheduleOptions) async throws -> [String: Any] in
      #if canImport(AlarmKit)
      if #available(iOS 26.0, *) {
        let id = UUID()
        let stopButton = AlarmButton(text: "Done", textColor: .white, systemImageName: "checkmark")
        let pauseButton = AlarmButton(text: "Pause", textColor: .white, systemImageName: "pause.fill")
        let resumeButton = AlarmButton(text: "Resume", textColor: .white, systemImageName: "play.fill")
        let alert = AlarmPresentation.Alert(
          title: LocalizedStringResource(stringLiteral: options.label),
          stopButton: stopButton
        )
        let countdown = AlarmPresentation.Countdown(
          title: LocalizedStringResource(stringLiteral: options.label),
          pauseButton: pauseButton
        )
        let paused = AlarmPresentation.Paused(
          title: LocalizedStringResource(stringLiteral: "Paused"),
          resumeButton: resumeButton
        )
        let attributes = AlarmAttributes<BrainVoiceAlarmMetadata>(
          presentation: AlarmPresentation(alert: alert, countdown: countdown, paused: paused),
          metadata: BrainVoiceAlarmMetadata(localId: options.localId, kind: "timer"),
          tintColor: Color(red: 0.49, green: 0.36, blue: 1.0)
        )
        let configuration = AlarmManager.AlarmConfiguration.timer(
          duration: TimeInterval(options.seconds),
          attributes: attributes
        )
        _ = try await AlarmManager.shared.schedule(id: id, configuration: configuration)
        return ["externalId": id.uuidString, "backend": "alarmkit"]
      }
      #endif
      throw AlarmKitUnavailableException()
    }

    AsyncFunction("cancelAlarm") { (externalId: String) throws -> Bool in
      #if canImport(AlarmKit)
      if #available(iOS 26.0, *), let uuid = UUID(uuidString: externalId) {
        try AlarmManager.shared.cancel(id: uuid)
        return true
      }
      #endif
      return false
    }

    // MARK: Android-only surface (parity so JS has one interface)

    Function("hasClockApp") { () -> Bool in false }
    AsyncFunction("setClockAlarm") { (_: ClockAlarmOptions) -> Bool in false }
    AsyncFunction("setClockTimer") { (_: ClockTimerOptions) -> Bool in false }
    AsyncFunction("dismissClockAlarm") { (_: String) -> Bool in false }
    AsyncFunction("dismissClockTimer") { () -> Bool in false }
    AsyncFunction("showClockAlarms") { () -> Bool in false }

    // MARK: App Intents queue

    /// Intents (Siri / Shortcuts / Action Button) append records to the App Group defaults;
    /// the app drains the queue when it becomes active and routes each record to the capture flow.
    Function("consumePendingIntents") { () -> [[String: Any]] in
      guard let defaults = UserDefaults(suiteName: self.appGroupId) else { return [] }
      let list = defaults.array(forKey: self.pendingKey) as? [[String: Any]] ?? []
      defaults.removeObject(forKey: self.pendingKey)
      return list
    }
  }

  // MARK: - Helpers

  #if canImport(AlarmKit)
  @available(iOS 26.0, *)
  private static func describe(_ state: AlarmManager.AuthorizationState) -> String {
    switch state {
    case .authorized: return "granted"
    case .denied: return "denied"
    case .notDetermined: return "undetermined"
    @unknown default: return "undetermined"
    }
  }
  #endif

  private static func parseISO(_ value: String) -> Date? {
    let withFraction = ISO8601DateFormatter()
    withFraction.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    if let date = withFraction.date(from: value) { return date }
    let plain = ISO8601DateFormatter()
    plain.formatOptions = [.withInternetDateTime]
    return plain.date(from: value)
  }

  /// ISO weekday (1 = Monday … 7 = Sunday) → Locale.Weekday
  private static func localeWeekday(_ iso: Int) -> Locale.Weekday? {
    switch iso {
    case 1: return .monday
    case 2: return .tuesday
    case 3: return .wednesday
    case 4: return .thursday
    case 5: return .friday
    case 6: return .saturday
    case 7: return .sunday
    default: return nil
    }
  }
}
