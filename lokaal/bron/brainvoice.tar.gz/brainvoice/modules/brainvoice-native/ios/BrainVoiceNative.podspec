Pod::Spec.new do |s|
  s.name           = 'BrainVoiceNative'
  s.version        = '0.1.0'
  s.summary        = 'BrainVoice native bridge: AlarmKit alarms/timers and the App Intents queue.'
  s.description    = 'Local Expo module used by the BrainVoice app. Exposes AlarmKit (iOS 26+) and reads intents queued by the App Intents extension through the shared App Group.'
  s.author         = 'BrainVoice'
  s.homepage       = 'https://brainvoice.app'
  s.license        = { :type => 'MIT' }
  s.platforms      = { :ios => '17.0' }
  s.swift_version  = '5.9'
  s.source         = { :git => '' }
  s.static_framework = true

  s.dependency 'ExpoModulesCore'

  # AlarmKit only exists on iOS 26+. Link it weakly so the app still launches on older versions;
  # every call site is guarded with `#available(iOS 26.0, *)` and `#if canImport(AlarmKit)`.
  s.weak_frameworks = 'AlarmKit'

  s.pod_target_xcconfig = {
    'DEFINES_MODULE' => 'YES',
    'SWIFT_COMPILATION_MODE' => 'wholemodule'
  }

  s.source_files = '**/*.{h,m,mm,swift}'
end
