package com.brainvoice.native

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.AlarmClock
import expo.modules.kotlin.exception.CodedException
import expo.modules.kotlin.exception.Exceptions
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import expo.modules.kotlin.records.Field
import expo.modules.kotlin.records.Record

/** Arguments coming from JavaScript (shared shape with iOS). */
class AlarmScheduleOptions : Record {
  @Field val localId: String = ""
  @Field val fireISO: String = ""
  @Field val hour: Int = 0
  @Field val minute: Int = 0
  @Field val label: String = "Alarm"
  @Field val repeatWeekdays: List<Int> = emptyList()
}

class TimerScheduleOptions : Record {
  @Field val localId: String = ""
  @Field val seconds: Double = 0.0
  @Field val label: String = "Timer"
}

class ClockAlarmOptions : Record {
  @Field val hour: Int = 0
  @Field val minute: Int = 0
  @Field val label: String = ""
  /** java.util.Calendar weekdays: Sunday = 1 … Saturday = 7 */
  @Field val days: List<Int> = emptyList()
  @Field val skipUi: Boolean = true
}

class ClockTimerOptions : Record {
  @Field val seconds: Int = 0
  @Field val label: String = ""
  @Field val skipUi: Boolean = true
}

class AlarmKitUnavailableException : CodedException("AlarmKit is only available on iOS 26 and later")

/**
 * BrainVoiceNative – Android implementation.
 *
 * Real alarms and timers are created through the documented `android.provider.AlarmClock`
 * intents, which hand the request to the user's clock app. This is the only supported way
 * to create a clock-app alarm from a third-party app; it needs the
 * `com.android.alarm.permission.SET_ALARM` permission (declared in app.config.ts).
 *
 * Limitations (documented in ANDROID_INTEGRATION.md):
 *  - ACTION_SET_ALARM takes a time and optional repeat days, never a calendar date.
 *  - Cancelling uses ACTION_DISMISS_ALARM with a label search; behaviour depends on the clock app.
 */
class BrainVoiceNativeModule : Module() {
  private val context: Context
    get() = appContext.reactContext ?: throw Exceptions.ReactContextLost()

  override fun definition() = ModuleDefinition {
    Name("BrainVoiceNative")

    // ---- iOS-only surface (parity) -------------------------------------------------------
    Function("isAlarmKitAvailable") { false }
    AsyncFunction("getAlarmAuthorizationStatus") { "unavailable" }
    AsyncFunction("requestAlarmAuthorization") { "unavailable" }
    AsyncFunction("scheduleAlarm") { _: AlarmScheduleOptions -> throw AlarmKitUnavailableException() }
    AsyncFunction("scheduleTimer") { _: TimerScheduleOptions -> throw AlarmKitUnavailableException() }
    AsyncFunction("cancelAlarm") { _: String -> false }
    Function("consumePendingIntents") { emptyList<Map<String, Any?>>() }

    // ---- AlarmClock intents --------------------------------------------------------------
    Function("hasClockApp") {
      Intent(AlarmClock.ACTION_SET_ALARM).resolveActivity(context.packageManager) != null
    }

    AsyncFunction("setClockAlarm") { options: ClockAlarmOptions ->
      val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
        putExtra(AlarmClock.EXTRA_HOUR, options.hour)
        putExtra(AlarmClock.EXTRA_MINUTES, options.minute)
        putExtra(AlarmClock.EXTRA_MESSAGE, options.label)
        putExtra(AlarmClock.EXTRA_SKIP_UI, options.skipUi)
        putExtra(AlarmClock.EXTRA_VIBRATE, true)
        if (options.days.isNotEmpty()) {
          putIntegerArrayListExtra(AlarmClock.EXTRA_DAYS, ArrayList(options.days))
        }
      }
      launch(intent)
    }

    AsyncFunction("setClockTimer") { options: ClockTimerOptions ->
      val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
        putExtra(AlarmClock.EXTRA_LENGTH, options.seconds)
        putExtra(AlarmClock.EXTRA_MESSAGE, options.label)
        putExtra(AlarmClock.EXTRA_SKIP_UI, options.skipUi)
      }
      launch(intent)
    }

    AsyncFunction("dismissClockAlarm") { label: String ->
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
        false
      } else {
        val intent = Intent(AlarmClock.ACTION_DISMISS_ALARM).apply {
          putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_LABEL)
          putExtra(AlarmClock.EXTRA_MESSAGE, label)
          putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        launch(intent)
      }
    }

    AsyncFunction("dismissClockTimer") {
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
        false
      } else {
        val intent = Intent(AlarmClock.ACTION_DISMISS_TIMER).apply {
          putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        launch(intent)
      }
    }

    AsyncFunction("showClockAlarms") {
      launch(Intent(AlarmClock.ACTION_SHOW_ALARMS))
    }
  }

  private fun launch(intent: Intent): Boolean {
    if (intent.resolveActivity(context.packageManager) == null) return false
    return try {
      val activity = appContext.currentActivity
      if (activity != null) {
        activity.startActivity(intent)
      } else {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
      }
      true
    } catch (e: Exception) {
      false
    }
  }
}
