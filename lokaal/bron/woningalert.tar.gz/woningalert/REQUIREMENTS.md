# Vastgoed & Huurwoning Alert Platform — Productspecificatie

Je bent mijn senior full-stack engineer, SaaS architect, DevOps engineer, security engineer en product owner.

Ik wil dat je een VOLLEDIG PRODUCTIEKLARE SaaS bouwt van:

# Vastgoed & Huurwoning Alert Platform

DIT IS GEEN DEMO.
DIT IS GEEN PROTOTYPE.
DIT IS GEEN MOCK-UP.
DIT IS GEEN SCHOOLPROJECT.

Ik wil een echte commerciële applicatie die ik na configuratie en deployment aan betalende klanten kan aanbieden.

Je mag dus NIET stoppen bij:
- demo data
- mock API's
- fake vastgoedconnectors
- placeholders
- TODO's
- lege knoppen
- nepbetalingen
- gesimuleerde notificaties
- fictieve scraper-resultaten
- alleen frontend zonder werkende backend
- alleen architectuurdocumentatie

Alles wat in de UI als werkend wordt aangeboden moet ook daadwerkelijk werken.

---

# 1. PRODUCTDOEL

Bouw een SaaS-platform voor consumenten in België en Nederland die een huurwoning of koopwoning zoeken.

Het systeem verzamelt automatisch nieuwe woningadvertenties uit meerdere legitieme bronnen, normaliseert deze, verwijdert duplicaten en vergelijkt nieuwe woningen met opgeslagen zoekprofielen van gebruikers.

Wanneer een nieuwe woning overeenkomt met een zoekprofiel, moet de gebruiker automatisch zo snel mogelijk een notificatie ontvangen.

Kanalen:

- e-mail
- WhatsApp
- SMS
- web push indien haalbaar

Het platform moet 24/7 autonoom kunnen draaien.

---

# 2. BELANGRIJKE PRODUCTREGEL

Gebruik alleen bronnen en methodes die technisch en juridisch toegestaan zijn.

Gebruik bij voorkeur:

1. officiële API's
2. officiële feeds
3. XML/JSON feeds
4. RSS
5. partnerfeeds
6. publieke endpoints waarvoor gebruik toegestaan is
7. expliciet toegestane crawling

Respecteer:
- robots.txt
- Terms of Service
- rate limits
- copyright
- GDPR
- databankrechten

NIET doen:

- CAPTCHA omzeilen
- botdetectie omzeilen
- loginbeveiliging omzeilen
- IP-ban evasion
- proxyrotatie gebruiken om blokkades te ontwijken
- private endpoints misbruiken
- gesloten data verzamelen
- authenticatie nabootsen zonder toestemming

Als voor een strategische bron een officiële samenwerking/API nodig is:

bouw wel de volledige connectorinterface, configuratie, dataflow en foutafhandeling zodat alleen de credentials/feed nog toegevoegd hoeven te worden.

Presenteer zo'n bron NIET als live zolang er geen echte toegang is.

---

# 3. GEEN DEMODATA IN PRODUCTIE

Gebruik demo-/seeddata uitsluitend voor lokale automated tests indien absoluut noodzakelijk.

Productie moet standaard:

- geen fictieve woningen tonen
- geen fictieve gebruikers bevatten
- geen fictieve betalingen bevatten
- geen fictieve statistieken bevatten
- geen nep-alerts genereren

Als er nog geen woningbronnen geconfigureerd zijn moet de UI duidelijk melden:

"Nog geen woningbronnen actief."

Niet automatisch dummywoningen tonen.

---

# 4. ACCOUNT & AUTHENTICATIE

Productieklaar accountbeheer.

Gebruiker moet kunnen:

- registreren
- e-mail bevestigen
- inloggen
- uitloggen
- wachtwoord vergeten
- wachtwoord wijzigen
- sessies beheren
- profiel wijzigen
- notificatievoorkeuren wijzigen
- abonnement beheren
- persoonsgegevens exporteren
- account definitief verwijderen

Ondersteun:

- e-mail/password
- Google OAuth

Gebruik veilige sessies.

Implementeer:
- email verification
- password reset tokens
- token expiry
- brute-force bescherming
- login rate limiting

---

# 5. ZOEKPROFIELEN

Gebruikers moeten meerdere alerts kunnen aanmaken.

Filters:

## Locatie

- België / Nederland
- provincie
- regio
- gemeente
- postcode
- meerdere gemeenten
- straal in kilometer
- kaartgebied indien haalbaar

## Type

- huur
- koop

## Woning

- appartement
- woning
- studio
- kamer
- villa
- nieuwbouw
- andere

## Budget

- minimumprijs
- maximumprijs

## Kenmerken

- minimum slaapkamers
- minimum badkamers
- minimum oppervlakte
- maximum oppervlakte
- tuin
- terras
- balkon
- parking
- garage
- gemeubileerd
- huisdieren toegestaan
- lift
- energielabel/EPC

## Extra

- vrije keywords
- uitgesloten keywords
- beschikbaar vanaf
- bouwjaar indien beschikbaar

Elke SearchProfile bevat:

- naam
- actief/inactief
- notificatiekanalen
- creation date
- last match
- number of matches

---

# 6. LIVE PROPERTY INGESTION PLATFORM

Bouw een echte ingestion architectuur.

Maak een plugin/adapter interface:

PropertySourceConnector

Bijvoorbeeld:

interface PropertySourceConnector {
    sourceId
    validateConfiguration()
    healthCheck()
    fetchListings()
    fetchListingDetails()
    normalize()
}

Elke connector moet:

- afzonderlijk enabled/disabled kunnen worden
- eigen credentials ondersteunen
- eigen rate limits hebben
- eigen polling interval hebben
- eigen retry policy hebben
- errors loggen
- healthstatus bijhouden

---

# 7. PRODUCTIEKLARE CRAWLER/SCHEDULER

Bouw een distributed-safe scheduler.

Gebruik bijvoorbeeld:

- BullMQ
- Redis
- PostgreSQL locks

Voorkom:

- dubbele runs
- race conditions
- dubbele imports
- dubbele notificaties

Gebruik:

- exponential backoff
- retry limits
- dead-letter queue
- rate limiting
- jitter
- circuit breaker
- cooldown per bron

Cron/polling moet 24/7 betrouwbaar draaien.

---

# 8. PROPERTY DATAMODEL

Maak één Canonical Property Model.

Minimaal:

Property

- id
- canonicalId
- title
- description
- listingType
- propertyType
- price
- currency
- serviceCosts
- deposit
- address
- houseNumber
- postalCode
- city
- municipality
- province
- region
- country
- latitude
- longitude
- bedrooms
- bathrooms
- livingArea
- lotArea
- floor
- totalFloors
- constructionYear
- energyLabel
- epcValue
- furnished
- petsAllowed
- garden
- terrace
- balcony
- garage
- parking
- availableFrom
- status
- publishedAt
- firstSeenAt
- lastSeenAt
- removedAt
- createdAt
- updatedAt

Maak aparte entiteit:

PropertyOccurrence

voor dezelfde woning op verschillende bronnen.

Velden:

- source
- externalId
- externalUrl
- sourcePrice
- sourcePublishedAt
- detectedAt
- lastSeenAt

---

# 9. DEDUPLICATIE

Cruciaal.

Dezelfde woning kan op verschillende sites voorkomen.

Bouw een degelijke deduplication pipeline.

Gebruik:

- normalized address
- postcode + huisnummer
- geolocation
- prijs
- oppervlakte
- slaapkamers
- normalized title
- description similarity
- image fingerprinting indien mogelijk

Score:

duplicateProbability 0-100

Gebruik duidelijke threshold-regels.

Bewaar auditinformatie waarom twee listings als duplicate beschouwd worden.

---

# 10. MATCHING ENGINE

Bij iedere nieuwe of gewijzigde woning:

1. normalize
2. deduplicate
3. persist
4. zoek relevante SearchProfiles
5. apply hard filters
6. calculate match score
7. create PropertyMatch
8. trigger alerts

Match score 0-100.

Voorbeeld:

Locatie: 100%
Prijs: 100%
Slaapkamers: 100%
Oppervlakte: 90%
Extra voorkeuren: 80%

Totale match: 94%

Gebruiker moet kunnen zien waarom iets matcht.

---

# 11. ALERTS MOETEN ECHT WERKEN

Geen console.log-notifications.

## E-mail

Integreer echte provider.

Bijvoorbeeld:

- Resend
- Postmark
- SendGrid

Maak:

- transactional templates
- delivery status
- bounce handling
- unsubscribe
- retry

## WhatsApp

Gebruik officiële:

Meta WhatsApp Cloud API

of

Twilio WhatsApp.

Ondersteun:

- template messages
- opt-in
- delivery status
- failure handling

## SMS

Gebruik echte provider zoals:

Twilio.

Kosten moeten gemeten kunnen worden.

---

# 12. NOTIFICATION PIPELINE

Notification lifecycle:

QUEUED
SENDING
SENT
DELIVERED
FAILED
RETRYING

Bewaar:

- recipient
- channel
- provider
- providerMessageId
- sentAt
- deliveredAt
- failedAt
- errorCode

Voorkom dubbele notificaties.

Een gebruiker mag niet 3 keer dezelfde woning ontvangen.

---

# 13. SNELHEID METEN

Voor elke listing:

sourcePublishedAt
detectedAt
processedAt
matchedAt
notificationQueuedAt
notificationSentAt

Bereken:

DetectionLatency
ProcessingLatency
NotificationLatency
TotalLatency

Admin dashboard moet p50/p95 laten zien.

---

# 14. USER DASHBOARD

Volledig productieklaar.

Pagina's:

## Dashboard

- nieuwe matches
- matches vandaag
- actieve alerts
- saved properties
- subscription status

## Zoekopdrachten

CRUD.

## Matches

Filters:

- newest
- best match
- price low-high
- price high-low
- source
- city
- viewed/unviewed

## Property Detail

Toon:

- foto's
- prijs
- locatie
- kaart
- kenmerken
- omschrijving
- matchscore
- waarom het matcht
- wanneer wij het vonden
- bron
- knop naar originele advertentie

Kopieer niet zonder toestemming volledige copyrighted content.

## Favorieten

## Notification settings

## Billing

## Account

---

# 15. PROPERTY STATUS

Track woningen.

Statussen:

ACTIVE
PRICE_CHANGED
UNDER_OPTION
RENTED
SOLD
REMOVED
UNKNOWN

Wanneer prijs wijzigt:

bewaar PriceHistory.

Gebruiker kan optioneel ook alert ontvangen bij:

- prijsdaling
- woning opnieuw beschikbaar
- wijziging beschikbaarheidsdatum

---

# 16. MAP

Productieklare kaart.

Gebruik bijvoorbeeld:

Mapbox
of
Leaflet + OpenStreetMap.

Ondersteun:

- markers
- clustering
- property preview
- filters
- search in viewport indien relevant

---

# 17. BETALINGEN

Geen mock checkout.

Integreer echte payment provider.

Voorkeur:

Mollie

omdat Nederland + België belangrijk zijn.

Ondersteun minimaal:

- iDEAL
- Bancontact
- creditcard

Abonnementen:

FREE
PREMIUM_MONTHLY
PREMIUM_3_MONTH

Startprijzen:

Free
€9,99 / maand
€25 / 3 maanden

Maar alle prijzen moeten admin-configureerbaar zijn.

---

# 18. SUBSCRIPTION ENTITLEMENTS

Geen frontend-only beperking.

Enforce abonnementen SERVER SIDE.

Voorbeeld:

FREE:
- 1 search profile
- e-mail
- lagere scanprioriteit

PREMIUM:
- meerdere searches
- snellere scans
- WhatsApp
- SMS optioneel
- instant alerts
- meer history

Gebruik entitlements/configuration zodat plannen later eenvoudig aangepast kunnen worden.

---

# 19. PAYMENT WEBHOOKS

Productieklaar.

Implementeer:

- signature verification
- idempotency
- retry safety
- duplicate webhook protection
- event logging

Status:

ACTIVE
PAST_DUE
CANCELLED
EXPIRED
TRIALING

Toegang moet automatisch veranderen.

---

# 20. ADMIN PLATFORM

Volwaardige admin.

Dashboard:

- total users
- active users
- new registrations
- paid users
- MRR
- churn
- failed payments
- active subscriptions
- searches
- properties
- matches
- alerts
- notification delivery rate

Bronmonitoring:

- source status
- last crawl
- runtime
- fetched
- inserted
- updated
- duplicates
- failures
- rate-limit events

Admin moet:

- connector enable/disable
- polling aanpassen
- config aanpassen
- retry starten
- gebruikers beheren
- subscriptions bekijken
- notificatieproblemen bekijken

---

# 21. OBSERVABILITY

Productie vereist observability.

Implementeer:

- structured logs
- correlation IDs
- error tracking
- metrics
- health endpoints

Bij voorkeur:

Sentry

plus logging.

Health:

/api/health

Controleert:

- app
- PostgreSQL
- Redis
- queue
- worker

Geen secrets teruggeven.

---

# 22. DATABASE

PostgreSQL + Prisma.

Maak production-quality schema.

Minimaal:

User
Account
Session
VerificationToken
SearchProfile
Property
PropertyOccurrence
PropertyImage
PropertyPriceHistory
PropertyMatch
Favorite
NotificationPreference
Notification
NotificationAttempt
PropertySource
PropertySourceConfig
CrawlerRun
SourceHealth
Subscription
Payment
PaymentEvent
AuditLog

Voeg correcte:

- indexes
- composite indexes
- unique constraints
- cascading rules
- timestamps

toe.

---

# 23. PERFORMANCE

Ontwerp zodat later veel listings verwerkt kunnen worden.

Gebruik:

- pagination
- indexed querying
- background workers
- queues
- batch processing
- database transactions waar nodig
- caching alleen waar nuttig

Geen N+1 query problemen.

---

# 24. SECURITY

Productie-security.

Minimaal:

- secure headers
- CSP
- HSTS in production
- secure cookies
- HTTP only
- SameSite
- CSRF protection indien nodig
- Zod validation
- RBAC
- admin protection
- API rate limiting
- brute-force protection
- webhook verification
- secret management
- safe logs
- no stack traces naar eindgebruikers

Run dependency vulnerability checks.

---

# 25. GDPR

Volledig meenemen.

Gebruikers moeten:

- consent kunnen geven
- marketing apart kunnen accepteren
- SMS/WhatsApp apart opt-in
- gegevens kunnen downloaden
- gegevens kunnen verwijderen
- notificaties kunnen stoppen

Maak:

Privacy Policy page
Terms page
Cookie page

Plaats duidelijke placeholders voor juridische tekst die later juridisch gevalideerd moet worden.

Functionaliteit voor privacyrechten moet wel werken.

---

# 26. E-MAILS

Maak echte transactional mails voor:

- verification
- welcome
- reset password
- payment confirmation
- payment failed
- subscription cancelled
- property alert
- price-drop alert
- account deletion confirmation

---

# 27. UX/UI

Premium consumentenproduct.

Geen admin-template uitstraling voor gebruikers.

Mobile first.

Stijl:

- modern
- betrouwbaar
- vastgoedgericht
- clean
- professioneel

Gebruik:

Next.js
React
TypeScript
Tailwind
shadcn/ui

Volledig responsive.

---

# 28. LANDINGPAGE

Echte commerciële homepage.

Hero:

"Stop met tientallen vastgoedsites controleren."

Sub:

"Maak één woningzoekopdracht. Wij volgen meerdere bronnen en waarschuwen je zodra we een passende nieuwe woning detecteren."

CTA:

"Maak gratis een alert"

Secties:

- Problem
- How it works
- Features
- Alerts
- Multi-source
- Pricing
- FAQ
- Testimonials NIET tonen zolang er geen echte testimonials zijn
- CTA

Geen nepklanten.
Geen nep-reviewscore.
Geen "10.000 gebruikers" als dat niet waar is.

---

# 29. INTERNATIONALIZATION

Vanaf begin:

NL
FR
EN

Maak i18n architectuur.

Nederlands default.

---

# 30. DEPLOYMENT

Dit project moet echt deploybaar zijn.

Maak productieconfiguratie voor bijvoorbeeld:

Frontend/API:
Vercel of containerized deployment

Database:
managed PostgreSQL

Redis:
managed Redis

Worker:
separate always-on worker

Kies architectuur waarbij crawler/worker NIET afhankelijk is van serverless request lifecycle.

Maak ook:

Dockerfile
docker-compose.yml

voor lokale ontwikkeling.

---

# 31. CI/CD

Maak GitHub Actions.

Op iedere PR:

- install
- typecheck
- lint
- unit tests
- integration tests waar mogelijk
- production build

Deployment alleen als pipeline groen is.

---

# 32. MIGRATIONS

Gebruik echte Prisma migrations.

Geen db push als production deploystrategie.

Maak:

migration workflow
rollback guidance
seed alleen voor noodzakelijke reference/config data

NOOIT demo properties seeden naar productie.

---

# 33. TESTING

Tests moeten relevant zijn.

Unit:

- normalizer
- dedup
- matching
- entitlement
- filters

Integration:

- database
- property ingestion
- payments webhook
- notifications

E2E:

REGISTER
→ VERIFY
→ LOGIN
→ CREATE SEARCH
→ INGEST REALISTIC TEST FIXTURE
→ MATCH
→ QUEUE ALERT
→ VIEW MATCH

Payment sandbox test:

CHECKOUT
→ WEBHOOK
→ ACTIVE SUBSCRIPTION
→ ENTITLEMENTS

Testdata uitsluitend in testomgeving.

---

# 34. CONFIGURATION

Maak volledige .env.example.

Bijvoorbeeld:

DATABASE_URL
REDIS_URL

AUTH_SECRET
GOOGLE_CLIENT_ID
GOOGLE_CLIENT_SECRET

MOLLIE_API_KEY
MOLLIE_WEBHOOK_SECRET

RESEND_API_KEY

TWILIO_ACCOUNT_SID
TWILIO_AUTH_TOKEN
TWILIO_PHONE_NUMBER

WHATSAPP_...

SENTRY_DSN

MAPBOX_TOKEN

Geen echte secrets committen.

---

# 35. SOURCE CONFIGURATION

Bronnen moeten via environment/admin-config configureerbaar zijn.

Voor elke bron:

enabled
baseUrl
apiKey indien nodig
pollInterval
rateLimit
maxRetries

Geen broncredentials hardcoden.

---

# 36. LAUNCH READINESS

Maak een:

LAUNCH_CHECKLIST.md

met:

Infrastructure
DNS
SSL
Database
Redis
workers
email
payments
WhatsApp
SMS
analytics
Sentry
backups
privacy
terms
monitoring
source connectors
cron/workers

---

# 37. BACKUPS

Voorzie/documenteer:

- automatische PostgreSQL backups
- restoreprocedure
- retention
- disaster recovery basics

---

# 38. ANALYTICS

Integreer privacyvriendelijke product analytics.

Track:

- registration_completed
- search_created
- match_viewed
- favorite_added
- checkout_started
- subscription_started
- subscription_cancelled

Geen gevoelige woningvoorkeuren naar externe analytics sturen zonder noodzaak.

---

# 39. PRODUCTIESTATUS

Maak in README duidelijk onderscheid:

LIVE
CONFIGURATION REQUIRED
NOT AVAILABLE

Voor externe integraties.

Nooit iets als "working" markeren wanneer alleen interface/mock bestaat.

---

# 40. DEFINITION OF DONE

Je mag pas zeggen:

"Production ready"

wanneer minimaal:

npm install -> PASS
typecheck -> PASS
lint -> PASS
unit tests -> PASS
integration tests -> PASS
production build -> PASS

En:

- authentication werkt
- database werkt
- migrations werken
- zoekprofielen werken
- ingestion pipeline werkt
- dedup werkt
- matching werkt
- minstens één daadwerkelijk configureerbare legitieme property source connector werkt
- notifications werken met echte providers
- Mollie checkout werkt
- webhooks werken
- subscriptions server-side enforced zijn
- admin werkt
- logging werkt
- worker werkt
- Docker werkt
- README volledig is
- .env.example volledig is

Geen TODO's in kritieke businessflows.

Geen mocked production integrations.

---

# 41. BELANGRIJKSTE INSTRUCTIE

Werk zelfstandig door tot het volledige product technisch klaar is.

Vraag mij NIET na elke stap toestemming.

Maak redelijke technische beslissingen zelf.

Als er bestaande code is:

INSPECTEER EERST DE HELE REPOSITORY.

Breek geen goed werkende functionaliteit.

Werk incrementeel.

Na elke grote fase:

- typecheck
- lint
- tests

Los fouten meteen op.

Stop niet omdat één integratie externe credentials nodig heeft.

Bouw alles eromheen volledig af en documenteer exact welke credentials ik nog moet invullen.

---

# 42. START NU

Voer eerst uit:

1. Repository audit
2. Architecture design
3. Gap analysis tegenover bovenstaande requirements
4. Database design
5. Implementatieplan
6. Begin daarna DIRECT met bouwen

Ik wil uiteindelijk geen voorstel of proof-of-concept.

Ik wil een commercieel inzetbaar product dat klaarstaat om online te zetten en betalende klanten te ontvangen.
