import { describe, expect, it } from 'vitest'

import { searchProfileSchema } from '@/server/search-profiles/schemas'

/**
 * Search profile validation (REQUIREMENTS §5).
 *
 * The schema is the only definition of what a valid profile is, so these tests
 * are the specification of the filters in executable form.
 */

const VALID = {
  name: 'Appartement Gent',
  countries: ['BE'],
  listingType: 'RENT',
  notificationChannels: ['EMAIL'],
}

function parse(overrides: Record<string, unknown> = {}) {
  return searchProfileSchema.safeParse({ ...VALID, ...overrides })
}

function messages(result: ReturnType<typeof parse>): string[] {
  return result.success ? [] : result.error.issues.map((issue) => issue.message)
}

describe('required fields', () => {
  it('accepts a minimal profile', () => {
    const result = parse()
    expect(result.success).toBe(true)
  })

  it('requires a name', () => {
    expect(messages(parse({ name: '   ' }))).toContain('nameRequired')
  })

  it('requires at least one country', () => {
    expect(messages(parse({ countries: [] }))).toContain('countryRequired')
  })

  it('requires a listing type', () => {
    expect(messages(parse({ listingType: undefined }))).toContain('listingTypeRequired')
  })

  it('requires at least one notification channel', () => {
    // A profile with no channel would match listings and never tell anyone.
    expect(messages(parse({ notificationChannels: [] }))).toContain('channelRequired')
  })
})

describe('defaults', () => {
  it('defaults to active, with empty lists and no requirements', () => {
    const result = parse()
    expect(result.success).toBe(true)
    if (!result.success) return

    expect(result.data.isActive).toBe(true)
    expect(result.data.propertyTypes).toEqual([])
    expect(result.data.municipalities).toEqual([])
    expect(result.data.requireGarden).toBe(false)
    expect(result.data.notifyOnPriceDrop).toBe(false)
  })
})

describe('price and area ranges', () => {
  it('rejects a maximum below the minimum', () => {
    const result = parse({ minPrice: '1200', maxPrice: '800' })
    expect(messages(result)).toContain('maxPriceBelowMin')
  })

  it('accepts a minimum equal to the maximum', () => {
    expect(parse({ minPrice: '900', maxPrice: '900' }).success).toBe(true)
  })

  it('accepts a maximum without a minimum', () => {
    expect(parse({ maxPrice: '900' }).success).toBe(true)
  })

  it('rejects a maximum area below the minimum area', () => {
    expect(messages(parse({ minLivingArea: '90', maxLivingArea: '60' }))).toContain(
      'maxAreaBelowMin',
    )
  })

  it('coerces numeric strings from the form into numbers', () => {
    const result = parse({ maxPrice: '950', minBedrooms: '2' })
    expect(result.success).toBe(true)
    if (result.success) {
      expect(result.data.maxPrice).toBe(950)
      expect(result.data.minBedrooms).toBe(2)
    }
  })

  it('treats an empty string as an absent value', () => {
    // Every untouched number input submits "", which must not become 0.
    const result = parse({ maxPrice: '', minBedrooms: '' })
    expect(result.success).toBe(true)
    if (result.success) {
      expect(result.data.maxPrice).toBeUndefined()
      expect(result.data.minBedrooms).toBeUndefined()
    }
  })
})

describe('radius search', () => {
  it('accepts all three parts together', () => {
    expect(parse({ centerLat: '51.05', centerLng: '3.72', radiusKm: '10' }).success).toBe(true)
  })

  it('accepts none of them', () => {
    expect(parse({ centerLat: '', centerLng: '', radiusKm: '' }).success).toBe(true)
  })

  it('rejects a partly filled radius', () => {
    // A radius without a centre matches nothing; a centre without a radius is
    // ignored. Both are a half-filled form rather than an intention.
    expect(messages(parse({ radiusKm: '10' }))).toContain('radiusIncomplete')
    expect(messages(parse({ centerLat: '51.05', centerLng: '3.72' }))).toContain(
      'radiusIncomplete',
    )
  })

  it('rejects coordinates outside the globe', () => {
    expect(parse({ centerLat: '95', centerLng: '3.72', radiusKm: '10' }).success).toBe(false)
  })
})

describe('map bounds', () => {
  it('rejects a partly filled box', () => {
    expect(messages(parse({ boundsNorth: '51.1', boundsSouth: '51.0' }))).toContain(
      'boundsIncomplete',
    )
  })

  it('rejects a box whose north edge is below its south edge', () => {
    const result = parse({
      boundsNorth: '51.0',
      boundsSouth: '51.1',
      boundsEast: '3.8',
      boundsWest: '3.6',
    })
    expect(messages(result)).toContain('boundsInverted')
  })

  it('accepts a well-formed box', () => {
    expect(
      parse({ boundsNorth: '51.1', boundsSouth: '51.0', boundsEast: '3.8', boundsWest: '3.6' })
        .success,
    ).toBe(true)
  })
})

describe('postcodes', () => {
  it('accepts Belgian four-digit codes', () => {
    const result = parse({ postalCodes: ['9000', '1000'] })
    expect(result.success).toBe(true)
  })

  it('accepts Dutch codes and normalises them', () => {
    const result = parse({ postalCodes: ['1012 ab'] })
    expect(result.success).toBe(true)
    // Stored without the space and upper-cased, so "1012ab" and "1012 AB" are
    // the same filter.
    if (result.success) expect(result.data.postalCodes).toEqual(['1012AB'])
  })

  it('rejects something that is not a postcode', () => {
    expect(messages(parse({ postalCodes: ['Gent'] }))).toContain('postalCodeInvalid')
  })
})

describe('keywords', () => {
  it('rejects a word that is both required and excluded', () => {
    // The exclusion always wins, so the profile would silently reject
    // everything the user asked for.
    const result = parse({ keywords: ['tuin'], excludedKeywords: ['Tuin'] })
    expect(messages(result)).toContain('keywordConflict')
  })

  it('allows distinct keyword lists', () => {
    expect(parse({ keywords: ['tuin'], excludedKeywords: ['garage'] }).success).toBe(true)
  })

  it('caps the number of keywords', () => {
    const many = Array.from({ length: 25 }, (_value, index) => `woord${index}`)
    expect(messages(parse({ keywords: many }))).toContain('tooManyValues')
  })
})

describe('lists', () => {
  it('removes duplicate municipalities', () => {
    const result = parse({ municipalities: ['Gent', 'Gent', 'Brugge'] })
    expect(result.success).toBe(true)
    // A repeated value widens nothing and only slows the matcher down.
    if (result.success) expect(result.data.municipalities).toEqual(['Gent', 'Brugge'])
  })

  it('rejects an unknown property type', () => {
    expect(parse({ propertyTypes: ['CASTLE'] }).success).toBe(false)
  })

  it('rejects an unknown notification channel', () => {
    expect(parse({ notificationChannels: ['CARRIER_PIGEON'] }).success).toBe(false)
  })
})
