import { describe, expect, it } from 'vitest'

import {
  forgotPasswordSchema,
  loginSchema,
  registerSchema,
  resetPasswordSchema,
  safeCallbackUrl,
} from '@/server/auth/schemas'

describe('registerSchema', () => {
  const valid = {
    email: 'Jan@Voorbeeld.BE',
    password: 'grijze kat op het dak',
    passwordConfirm: 'grijze kat op het dak',
    acceptTerms: true,
    marketingConsent: false,
  }

  it('accepts a valid registration and lowercases the e-mail', () => {
    const result = registerSchema.safeParse(valid)
    expect(result.success).toBe(true)
    // "Jan@x.be" and "jan@x.be" must be the same account, so normalisation
    // happens in the schema rather than at every call site.
    expect(result.success && result.data.email).toBe('jan@voorbeeld.be')
  })

  it('trims surrounding whitespace from the e-mail', () => {
    const result = registerSchema.safeParse({ ...valid, email: '  jan@voorbeeld.be  ' })
    expect(result.success && result.data.email).toBe('jan@voorbeeld.be')
  })

  it('rejects mismatched password confirmation on the confirm field', () => {
    const result = registerSchema.safeParse({ ...valid, passwordConfirm: 'iets anders' })
    expect(result.success).toBe(false)
    if (!result.success) {
      const issue = result.error.issues.find((candidate) => candidate.message === 'passwordsDoNotMatch')
      expect(issue?.path).toEqual(['passwordConfirm'])
    }
  })

  it('rejects a registration without accepting the terms', () => {
    const result = registerSchema.safeParse({ ...valid, acceptTerms: false })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues.some((issue) => issue.message === 'termsRequired')).toBe(true)
    }
  })

  it('rejects an invalid e-mail address', () => {
    const result = registerSchema.safeParse({ ...valid, email: 'geen-adres' })
    expect(result.success).toBe(false)
  })

  it('rejects a password shorter than the policy minimum', () => {
    const result = registerSchema.safeParse({ ...valid, password: 'kort', passwordConfirm: 'kort' })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues.some((issue) => issue.message === 'passwordTooShort')).toBe(true)
    }
  })
})

describe('loginSchema', () => {
  it('accepts any non-empty password, because the policy applies when setting one', () => {
    // An account created before a policy change must still be able to sign in.
    const result = loginSchema.safeParse({ email: 'jan@voorbeeld.be', password: 'x' })
    expect(result.success).toBe(true)
  })

  it('rejects an empty password', () => {
    const result = loginSchema.safeParse({ email: 'jan@voorbeeld.be', password: '' })
    expect(result.success).toBe(false)
  })
})

describe('forgotPasswordSchema and resetPasswordSchema', () => {
  it('normalises the e-mail on a reset request', () => {
    const result = forgotPasswordSchema.safeParse({ email: 'JAN@VOORBEELD.BE' })
    expect(result.success && result.data.email).toBe('jan@voorbeeld.be')
  })

  it('requires a token when resetting', () => {
    const result = resetPasswordSchema.safeParse({
      token: '',
      password: 'grijze kat op het dak',
      passwordConfirm: 'grijze kat op het dak',
    })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues.some((issue) => issue.message === 'tokenRequired')).toBe(true)
    }
  })
})

describe('safeCallbackUrl', () => {
  it('keeps a same-origin relative path', () => {
    expect(safeCallbackUrl('/dashboard/searches')).toBe('/dashboard/searches')
  })

  it('falls back for an absolute URL to another host', () => {
    // Otherwise /login?callbackUrl=https://evil.example is an open redirect that
    // phishes from our own domain.
    expect(safeCallbackUrl('https://evil.example')).toBe('/dashboard')
  })

  it('falls back for a protocol-relative URL', () => {
    expect(safeCallbackUrl('//evil.example')).toBe('/dashboard')
  })

  it('falls back for a backslash-obfuscated URL', () => {
    // Some browsers normalise "\" to "/", so "/\evil.example" can escape too.
    expect(safeCallbackUrl('/\\evil.example')).toBe('/dashboard')
  })

  it('falls back for null, undefined and empty input', () => {
    expect(safeCallbackUrl(null)).toBe('/dashboard')
    expect(safeCallbackUrl(undefined)).toBe('/dashboard')
    expect(safeCallbackUrl('')).toBe('/dashboard')
  })

  it('honours an explicit fallback', () => {
    expect(safeCallbackUrl('https://evil.example', '/account')).toBe('/account')
  })
})
