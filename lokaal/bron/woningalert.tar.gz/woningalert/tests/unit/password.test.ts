import { describe, expect, it } from 'vitest'

import {
  DUMMY_PASSWORD_HASH,
  PASSWORD_MIN_LENGTH,
  checkPasswordPolicy,
  equalizeTiming,
  hashPassword,
  verifyPassword,
} from '@/server/auth/password'

describe('password hashing', () => {
  it('produces a bcrypt hash that verifies against the original', async () => {
    const hash = await hashPassword('een lange zin die ik onthoud')

    expect(hash).toMatch(/^\$2[aby]\$12\$/)
    expect(await verifyPassword('een lange zin die ik onthoud', hash)).toBe(true)
  })

  it('rejects a wrong password', async () => {
    const hash = await hashPassword('een lange zin die ik onthoud')
    expect(await verifyPassword('een andere zin', hash)).toBe(false)
  })

  it('produces a different hash for the same password each time', async () => {
    const [first, second] = await Promise.all([
      hashPassword('zelfde wachtwoord hier'),
      hashPassword('zelfde wachtwoord hier'),
    ])
    // Different salts. Equal hashes would mean the salt is not random, which
    // would make a rainbow table viable.
    expect(first).not.toBe(second)
  })

  it('refuses to hash input longer than bcrypt can represent', async () => {
    // bcrypt silently truncates at 72 bytes. Truncating would mean two
    // different long passwords authenticate each other.
    await expect(hashPassword('a'.repeat(73))).rejects.toThrow(/72 bytes/)
  })

  it('returns false rather than throwing when verifying over-long input', async () => {
    const hash = await hashPassword('een lange zin die ik onthoud')
    expect(await verifyPassword('a'.repeat(200), hash)).toBe(false)
  })

  it('has a usable dummy hash for timing equalisation', async () => {
    // If this hash were malformed, bcrypt.compare would throw and the
    // unknown-account path would be measurably faster than the wrong-password
    // path — the enumeration leak the dummy hash exists to prevent.
    await expect(equalizeTiming()).resolves.toBeUndefined()
    expect(await verifyPassword('anything at all', DUMMY_PASSWORD_HASH)).toBe(false)
  })
})

describe('password policy', () => {
  it('accepts a long passphrase', () => {
    expect(checkPasswordPolicy('grijze kat op het dak')).toEqual({ ok: true, problems: [] })
  })

  it(`rejects anything shorter than ${PASSWORD_MIN_LENGTH} characters`, () => {
    const result = checkPasswordPolicy('kort123')
    expect(result.ok).toBe(false)
    expect(result.problems).toContain('tooShort')
  })

  it('rejects a single repeated character', () => {
    const result = checkPasswordPolicy('aaaaaaaaaaaa')
    expect(result.ok).toBe(false)
    expect(result.problems).toContain('repeatedCharacter')
  })

  it('rejects passwords from the common list, case-insensitively', () => {
    expect(checkPasswordPolicy('Wachtwoord123').problems).toContain('tooCommon')
    expect(checkPasswordPolicy('password123').problems).toContain('tooCommon')
  })

  it('rejects a password containing the local part of the e-mail address', () => {
    const result = checkPasswordPolicy('mohamedbouzouf1', { email: 'mohamedbouzouf@example.be' })
    expect(result.ok).toBe(false)
    expect(result.problems).toContain('containsEmail')
  })

  it('ignores very short local parts, which would match almost anything', () => {
    // "jo" appearing inside a passphrase is not evidence of a weak password.
    const result = checkPasswordPolicy('jouw grote blauwe fiets', { email: 'jo@example.be' })
    expect(result.ok).toBe(true)
  })

  it('rejects input bcrypt would truncate', () => {
    const result = checkPasswordPolicy('a'.repeat(80))
    expect(result.problems).toContain('tooLong')
  })

  it('reports every problem at once rather than one at a time', () => {
    const result = checkPasswordPolicy('aaa')
    expect(result.problems).toEqual(expect.arrayContaining(['tooShort', 'repeatedCharacter']))
  })
})
