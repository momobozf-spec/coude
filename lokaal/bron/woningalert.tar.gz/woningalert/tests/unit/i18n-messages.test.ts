import { describe, expect, it } from 'vitest'

import en from '@/i18n/messages/en.json'
import fr from '@/i18n/messages/fr.json'
import nl from '@/i18n/messages/nl.json'
import { defaultLocale, locales } from '@/i18n/routing'
import {
  defaultEmailLocale,
  emailBundles,
  emailLocales,
  emailTranslate,
} from '@/server/email/i18n'

/**
 * Translation completeness (REQUIREMENTS §29).
 *
 * next-intl falls back to the key name when a message is missing, so an
 * untranslated string does not crash — it silently ships to a French user as
 * `home.heroTitle`. This test is the only thing that catches that before a
 * customer does.
 */

type MessageTree = { [key: string]: string | MessageTree }

const bundles: Record<string, MessageTree> = { nl, fr, en }

function flattenKeys(tree: MessageTree, prefix = ''): string[] {
  return Object.entries(tree).flatMap(([key, value]) => {
    const path = prefix ? `${prefix}.${key}` : key
    return typeof value === 'string' ? [path] : flattenKeys(value, path)
  })
}

/**
 * Extracts the top-level ICU argument names from a message, so the signatures
 * of two translations can be compared.
 *
 * A naive `/\{(\w+)/g` cannot be used: in
 * `{count, plural, =0 {no matches yet} other {# matches}}` it would also pick
 * up `no` from the plural branch, and since the branches are worded differently
 * per language every plural message would look like a mismatch. Brace depth is
 * tracked so only arguments outside a sub-message are counted.
 */
function placeholdersOf(message: string): string[] {
  const names: string[] = []
  let depth = 0

  for (let index = 0; index < message.length; index += 1) {
    const character = message[index]

    if (character === '}') {
      depth -= 1
      continue
    }

    if (character !== '{') continue

    depth += 1
    if (depth !== 1) continue

    // Only `{name}` and `{name, ...}` are arguments; `{# matches}` is text.
    const rest = message.slice(index + 1)
    const match = /^(\w+)\s*[,}]/.exec(rest)
    if (match?.[1]) names.push(match[1])
  }

  return names.sort()
}

function messageAt(tree: MessageTree, path: string): string | undefined {
  const value = path.split('.').reduce<string | MessageTree | undefined>((node, segment) => {
    if (node === undefined || typeof node === 'string') return undefined
    return node[segment]
  }, tree)
  return typeof value === 'string' ? value : undefined
}

const referenceKeys = flattenKeys(bundles[defaultLocale] as MessageTree).sort()

describe('i18n message bundles', () => {
  it('exposes a bundle for every configured locale', () => {
    for (const locale of locales) {
      expect(bundles[locale], `no message bundle imported for "${locale}"`).toBeDefined()
    }
  })

  it.each(locales.filter((locale) => locale !== defaultLocale))(
    'locale "%s" defines exactly the keys of the default locale',
    (locale) => {
      const keys = flattenKeys(bundles[locale] as MessageTree).sort()

      const missing = referenceKeys.filter((key) => !keys.includes(key))
      const extra = keys.filter((key) => !referenceKeys.includes(key))

      expect(missing, `missing in ${locale}.json`).toEqual([])
      expect(extra, `present in ${locale}.json but not in ${defaultLocale}.json`).toEqual([])
    },
  )

  it.each(locales.filter((locale) => locale !== defaultLocale))(
    'locale "%s" uses the same ICU placeholders as the default locale',
    (locale) => {
      const mismatches: string[] = []

      for (const key of referenceKeys) {
        const reference = messageAt(bundles[defaultLocale] as MessageTree, key)
        const translated = messageAt(bundles[locale] as MessageTree, key)
        if (reference === undefined || translated === undefined) continue

        const expected = placeholdersOf(reference)
        const actual = placeholdersOf(translated)

        if (expected.join(',') !== actual.join(',')) {
          mismatches.push(`${key}: expected {${expected.join(', ')}} but got {${actual.join(', ')}}`)
        }
      }

      expect(mismatches).toEqual([])
    },
  )

  it('has no empty message values', () => {
    for (const [locale, bundle] of Object.entries(bundles)) {
      for (const key of flattenKeys(bundle)) {
        expect(messageAt(bundle, key)?.trim(), `${locale}.json -> ${key} is empty`).not.toBe('')
      }
    }
  })
})

// ---------------------------------------------------------------------------
// E-mail bundles
// ---------------------------------------------------------------------------

describe('e-mail message bundles', () => {
  // E-mail copy lives in its own bundles because the worker renders alerts
  // outside a Next.js request and cannot use next-intl. Same failure mode
  // though: a missing key ships as the dotted path to a real customer.
  const emailReference = flattenKeys(emailBundles[defaultEmailLocale] as MessageTree).sort()

  it.each(emailLocales.filter((locale) => locale !== defaultEmailLocale))(
    'e-mail locale "%s" defines exactly the keys of the default locale',
    (locale) => {
      const keys = flattenKeys(emailBundles[locale] as MessageTree).sort()

      expect(
        emailReference.filter((key) => !keys.includes(key)),
        `missing in email/${locale}.json`,
      ).toEqual([])
      expect(
        keys.filter((key) => !emailReference.includes(key)),
        `present in email/${locale}.json but not in the default locale`,
      ).toEqual([])
    },
  )

  it('falls back to the default locale rather than to the key itself', () => {
    // A key that exists nowhere returns the path, which is the signal the
    // parity test above is meant to prevent from ever shipping.
    expect(emailTranslate('fr', 'verification.subject')).not.toBe('verification.subject')
    expect(emailTranslate('fr', 'does.not.exist')).toBe('does.not.exist')
  })

  it('substitutes placeholders and leaves unknown ones alone', () => {
    expect(emailTranslate('nl', 'layout.footerTagline')).toContain('Woningalerts')
  })
})
