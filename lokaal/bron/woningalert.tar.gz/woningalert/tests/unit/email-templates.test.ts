import { describe, expect, it } from 'vitest'

import { emailLocales } from '@/server/email/i18n'
import { escapeHtml } from '@/server/email/layout'
import {
  renderPasswordChangedEmail,
  renderPasswordResetEmail,
  renderVerificationEmail,
  renderWelcomeEmail,
} from '@/server/email/templates'

const appUrl = 'https://woningalert.test'

describe('escapeHtml', () => {
  it('escapes every character that could break out of markup', () => {
    expect(escapeHtml('<script>alert("x") & \'y\'</script>')).toBe(
      '&lt;script&gt;alert(&quot;x&quot;) &amp; &#39;y&#39;&lt;/script&gt;',
    )
  })
})

describe('verification e-mail', () => {
  it('contains the verification link in both the HTML and the text part', () => {
    const url = `${appUrl}/verify-email?token=abc123`
    const mail = renderVerificationEmail({ locale: 'nl', appUrl, verifyUrl: url })

    expect(mail.html).toContain(url)
    expect(mail.text).toContain(url)
  })

  it('always ships a plain-text alternative', () => {
    // HTML-only mail scores markedly worse with spam filters, and some clients
    // still render text only.
    const mail = renderVerificationEmail({
      locale: 'nl',
      appUrl,
      verifyUrl: `${appUrl}/verify-email?token=t`,
    })
    expect(mail.text.trim().length).toBeGreaterThan(50)
    expect(mail.text).not.toContain('<')
  })

  it('renders in every supported locale with a locale-specific subject', () => {
    const subjects = emailLocales.map(
      (locale) =>
        renderVerificationEmail({ locale, appUrl, verifyUrl: `${appUrl}/v?token=t` }).subject,
    )

    expect(new Set(subjects).size).toBe(emailLocales.length)
    for (const subject of subjects) {
      expect(subject.length).toBeGreaterThan(0)
      // A missing key would fall through to the dotted path itself.
      expect(subject).not.toContain('verification.')
    }
  })

  it('sets the html lang attribute to the requested locale', () => {
    const mail = renderVerificationEmail({
      locale: 'fr',
      appUrl,
      verifyUrl: `${appUrl}/v?token=t`,
    })
    expect(mail.html).toContain('<html lang="fr">')
  })
})

describe('welcome e-mail', () => {
  const base = {
    locale: 'nl' as const,
    appUrl,
    dashboardUrl: `${appUrl}/dashboard`,
    preferencesUrl: `${appUrl}/account/notifications`,
  }

  it('states plainly that no sources are active yet', () => {
    // REQUIREMENTS §3: never imply listings are flowing when none can arrive.
    const mail = renderWelcomeEmail({ ...base, hasActiveSources: false })
    expect(mail.text).toContain('nog geen woningbronnen actief')
  })

  it('omits that notice once a source is active', () => {
    const mail = renderWelcomeEmail({ ...base, hasActiveSources: true })
    expect(mail.text).not.toContain('nog geen woningbronnen actief')
  })

  it('links to the notification preferences', () => {
    const mail = renderWelcomeEmail({ ...base, hasActiveSources: true })
    expect(mail.html).toContain(base.preferencesUrl)
  })
})

describe('password e-mails', () => {
  it('includes the reset link', () => {
    const url = `${appUrl}/reset-password?token=xyz`
    const mail = renderPasswordResetEmail({ locale: 'nl', appUrl, resetUrl: url })
    expect(mail.html).toContain(url)
    expect(mail.text).toContain(url)
  })

  it('keeps the preferences link out of security mail', () => {
    // One less clickable destination on a page an attacker may have driven the
    // user towards.
    const mail = renderPasswordResetEmail({
      locale: 'nl',
      appUrl,
      resetUrl: `${appUrl}/reset-password?token=xyz`,
    })
    expect(mail.html).not.toContain('/account/notifications')
  })

  it('warns the reader in the password-changed notice', () => {
    const mail = renderPasswordChangedEmail({
      locale: 'nl',
      appUrl,
      accountUrl: `${appUrl}/account`,
    })
    expect(mail.text.toLowerCase()).toContain('niet gedaan')
  })
})

describe('template escaping', () => {
  it('escapes a URL that contains markup characters', () => {
    const hostile = `${appUrl}/verify-email?token=a"><script>alert(1)</script>`
    const mail = renderVerificationEmail({ locale: 'nl', appUrl, verifyUrl: hostile })

    expect(mail.html).not.toContain('<script>alert(1)</script>')
    expect(mail.html).toContain('&lt;script&gt;')
  })
})
