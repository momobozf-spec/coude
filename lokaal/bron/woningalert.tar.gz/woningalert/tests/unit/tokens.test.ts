import { describe, expect, it } from 'vitest'

import {
  EMAIL_VERIFICATION_TTL_MS,
  PASSWORD_RESET_TTL_MS,
  generateSessionToken,
  generateToken,
  hashToken,
  isExpired,
  tokenHashEquals,
} from '@/server/auth/tokens'

describe('one-time tokens', () => {
  it('never returns the same token twice', () => {
    const tokens = new Set(Array.from({ length: 200 }, () => generateToken(1000).token))
    expect(tokens.size).toBe(200)
  })

  it('produces URL-safe tokens', () => {
    // base64url only. A `+`, `/` or `=` would be mangled in a query string and
    // the link in the e-mail would stop working.
    for (let i = 0; i < 50; i += 1) {
      expect(generateToken(1000).token).toMatch(/^[A-Za-z0-9_-]+$/)
    }
  })

  it('stores a hash that differs from the token itself', () => {
    const { token, tokenHash } = generateToken(1000)
    expect(tokenHash).not.toBe(token)
    expect(tokenHash).toMatch(/^[0-9a-f]{64}$/)
  })

  it('hashes deterministically, so a link can be looked up', () => {
    const { token, tokenHash } = generateToken(1000)
    expect(hashToken(token)).toBe(tokenHash)
  })

  it('gives different tokens different hashes', () => {
    const a = generateToken(1000)
    const b = generateToken(1000)
    expect(a.tokenHash).not.toBe(b.tokenHash)
  })

  it('sets the expiry from the requested TTL', () => {
    const before = Date.now()
    const { expiresAt } = generateToken(60_000)
    expect(expiresAt.getTime()).toBeGreaterThanOrEqual(before + 60_000)
    expect(expiresAt.getTime()).toBeLessThanOrEqual(Date.now() + 60_000)
  })

  it('uses the TTLs the requirements ask for', () => {
    expect(EMAIL_VERIFICATION_TTL_MS).toBe(24 * 60 * 60 * 1000)
    expect(PASSWORD_RESET_TTL_MS).toBe(60 * 60 * 1000)
  })
})

describe('tokenHashEquals', () => {
  it('matches identical hashes', () => {
    const hash = hashToken('abc')
    expect(tokenHashEquals(hash, hash)).toBe(true)
  })

  it('rejects different hashes', () => {
    expect(tokenHashEquals(hashToken('abc'), hashToken('abd'))).toBe(false)
  })

  it('rejects different lengths without throwing', () => {
    // timingSafeEqual throws on mismatched lengths; the guard must catch that.
    expect(tokenHashEquals('short', hashToken('abc'))).toBe(false)
  })
})

describe('isExpired', () => {
  it('is false before the expiry', () => {
    expect(isExpired(new Date(Date.now() + 1000))).toBe(false)
  })

  it('is true after the expiry', () => {
    expect(isExpired(new Date(Date.now() - 1))).toBe(true)
  })

  it('treats the exact expiry moment as expired', () => {
    const now = new Date()
    expect(isExpired(now, now)).toBe(true)
  })
})

describe('session tokens', () => {
  it('are unique and URL-safe', () => {
    const tokens = new Set(Array.from({ length: 100 }, generateSessionToken))
    expect(tokens.size).toBe(100)
    for (const token of tokens) {
      expect(token).toMatch(/^[A-Za-z0-9_-]+$/)
    }
  })
})
