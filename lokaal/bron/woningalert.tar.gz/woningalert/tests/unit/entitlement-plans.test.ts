import { describe, expect, it } from 'vitest'

import { NotificationChannel, SubscriptionPlan } from '@/generated/prisma/enums'
import {
  DEFAULT_PLAN,
  PLAN_DEFAULTS,
  filterAllowedChannels,
  formatPriceCents,
} from '@/server/entitlements/plans'

/**
 * Plan definitions (REQUIREMENTS §17, §18).
 *
 * These are the code defaults that apply when `PlanConfig` is empty or
 * unreadable, so they are the last line between a broken configuration table
 * and a site where nobody can do anything.
 */

describe('plan defaults', () => {
  it('defines every plan the schema knows about', () => {
    // A plan enum value without a definition would crash `resolvePlan` at
    // runtime for whoever happens to be on it.
    for (const plan of Object.values(SubscriptionPlan)) {
      expect(PLAN_DEFAULTS[plan], `no default for ${plan}`).toBeDefined()
      expect(PLAN_DEFAULTS[plan].plan).toBe(plan)
    }
  })

  it('falls back to the free plan', () => {
    expect(DEFAULT_PLAN).toBe(SubscriptionPlan.FREE)
  })

  it('matches the prices from the requirements', () => {
    // §17: free, EUR 9,99 per month, EUR 25 per three months.
    expect(PLAN_DEFAULTS.FREE.priceCents).toBe(0)
    expect(PLAN_DEFAULTS.PREMIUM_MONTHLY.priceCents).toBe(999)
    expect(PLAN_DEFAULTS.PREMIUM_3_MONTH.priceCents).toBe(2500)
  })

  it('makes the three-month plan cheaper per month than the monthly one', () => {
    const monthly = PLAN_DEFAULTS.PREMIUM_MONTHLY.priceCents
    const quarterlyPerMonth =
      PLAN_DEFAULTS.PREMIUM_3_MONTH.priceCents / PLAN_DEFAULTS.PREMIUM_3_MONTH.intervalMonths

    // Otherwise the longer commitment is a worse deal and nobody would take it.
    expect(quarterlyPerMonth).toBeLessThan(monthly)
  })

  it('gives the free plan exactly one search profile and e-mail only', () => {
    // §18 spells both out.
    expect(PLAN_DEFAULTS.FREE.maxSearchProfiles).toBe(1)
    expect(PLAN_DEFAULTS.FREE.allowedChannels).toEqual([NotificationChannel.EMAIL])
    expect(PLAN_DEFAULTS.FREE.instantAlerts).toBe(false)
  })

  it('gives premium plans more profiles, more channels and instant alerts', () => {
    for (const plan of [PLAN_DEFAULTS.PREMIUM_MONTHLY, PLAN_DEFAULTS.PREMIUM_3_MONTH]) {
      expect(plan.maxSearchProfiles).toBeGreaterThan(PLAN_DEFAULTS.FREE.maxSearchProfiles)
      expect(plan.allowedChannels).toContain(NotificationChannel.WHATSAPP)
      expect(plan.allowedChannels).toContain(NotificationChannel.SMS)
      expect(plan.instantAlerts).toBe(true)
      // Lower number sorts earlier in the poll scheduler.
      expect(plan.pollPriority).toBeLessThan(PLAN_DEFAULTS.FREE.pollPriority)
    }
  })

  it('always includes e-mail in every plan', () => {
    // Every profile needs at least one reachable channel, and e-mail is the one
    // that needs no phone number.
    for (const plan of Object.values(PLAN_DEFAULTS)) {
      expect(plan.allowedChannels).toContain(NotificationChannel.EMAIL)
    }
  })
})

describe('filterAllowedChannels', () => {
  const premium = [
    NotificationChannel.EMAIL,
    NotificationChannel.WHATSAPP,
    NotificationChannel.SMS,
  ]
  const free = [NotificationChannel.EMAIL]

  it('keeps everything a plan permits', () => {
    expect(filterAllowedChannels([NotificationChannel.EMAIL, NotificationChannel.SMS], premium)).toEqual(
      [NotificationChannel.EMAIL, NotificationChannel.SMS],
    )
  })

  it('drops channels outside the plan', () => {
    expect(
      filterAllowedChannels([NotificationChannel.EMAIL, NotificationChannel.SMS], free),
    ).toEqual([NotificationChannel.EMAIL])
  })

  it('never returns an empty list', () => {
    // A profile with no channel would match listings and then have no way to
    // tell anyone — indistinguishable from a broken alert.
    expect(filterAllowedChannels([NotificationChannel.SMS], free)).toEqual([
      NotificationChannel.EMAIL,
    ])
    expect(filterAllowedChannels([], free)).toEqual([NotificationChannel.EMAIL])
  })

  it('preserves the order the user chose', () => {
    expect(
      filterAllowedChannels([NotificationChannel.SMS, NotificationChannel.EMAIL], premium),
    ).toEqual([NotificationChannel.SMS, NotificationChannel.EMAIL])
  })
})

describe('formatPriceCents', () => {
  it('renders cents as a currency amount', () => {
    // Non-breaking spaces vary by ICU version, so the digits are what matter.
    expect(formatPriceCents(999)).toContain('9,99')
    expect(formatPriceCents(2500)).toContain('25,00')
    expect(formatPriceCents(0)).toContain('0,00')
  })
})
