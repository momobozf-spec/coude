import { randomUUID } from 'node:crypto'

import { afterAll, describe, expect, it } from 'vitest'

import { prisma } from '@/server/db'
import { verifyPassword } from '@/server/auth/password'
import { hashToken } from '@/server/auth/tokens'
import { createSession, isSessionValid, listSessions } from '@/server/auth/session-registry'
import {
  issuePasswordResetToken,
  issueVerificationEmail,
  registerUser,
  requestPasswordReset,
  resetPassword,
  verifyEmailToken,
} from '@/server/auth/service'

/**
 * The account lifecycle against a real PostgreSQL (REQUIREMENTS §33).
 *
 * No mocked database: the point is to catch what a mock cannot — that the
 * transaction really is atomic, that unique constraints really fire, and that a
 * token stored as a hash really can be looked up again.
 *
 * Tokens are deliberately unreadable from the database, so the tests obtain one
 * from `issueVerificationEmail` / `issuePasswordResetToken`, the primitives
 * that return the raw value at the moment they mail it.
 *
 * E-mail is not configured in the test environment, so every send is recorded
 * as FAILED with `EMAIL_NOT_CONFIGURED`. That is asserted rather than worked
 * around: it is exactly what the application must do when e-mail is missing.
 */

const createdEmails: string[] = []

const STRONG_PASSWORD = 'grijze kat op het dak'

function uniqueEmail(): string {
  const email = `test-${randomUUID()}@woningalert.test`
  createdEmails.push(email)
  return email
}

async function createVerifiedUser(): Promise<{ id: string; email: string }> {
  const email = uniqueEmail()
  await registerUser({
    email,
    password: STRONG_PASSWORD,
    acceptedTerms: true,
    marketingConsent: false,
  })
  const user = await prisma.user.findUniqueOrThrow({ where: { email }, select: { id: true } })
  return { id: user.id, email }
}

afterAll(async () => {
  // Cascades clean up tokens, notifications, preferences and subscriptions.
  if (createdEmails.length > 0) {
    await prisma.user.deleteMany({ where: { email: { in: createdEmails } } })
  }
})

describe('registration', () => {
  it('creates the user, preferences and a FREE subscription in one transaction', async () => {
    const email = uniqueEmail()

    const result = await registerUser({
      email,
      password: STRONG_PASSWORD,
      name: 'Test Gebruiker',
      locale: 'nl',
      acceptedTerms: true,
      marketingConsent: false,
    })

    expect(result.status).toBe('pending-verification')

    const user = await prisma.user.findUnique({
      where: { email },
      include: { notificationPreference: true, subscriptions: true },
    })

    expect(user).not.toBeNull()
    expect(user!.emailVerified).toBeNull()
    expect(user!.role).toBe('USER')
    expect(user!.termsAcceptedAt).toBeInstanceOf(Date)
    expect(user!.marketingConsentAt).toBeNull()

    // A user without preferences or a plan would break the notification and
    // entitlement code later; the transaction is what guarantees they exist.
    expect(user!.notificationPreference).not.toBeNull()
    expect(user!.notificationPreference!.emailEnabled).toBe(true)
    expect(user!.subscriptions).toHaveLength(1)
    expect(user!.subscriptions[0]!.plan).toBe('FREE')
    expect(user!.subscriptions[0]!.status).toBe('ACTIVE')
  })

  it('writes an audit log entry for the registration', async () => {
    const email = uniqueEmail()
    await registerUser({
      email,
      password: STRONG_PASSWORD,
      acceptedTerms: true,
      marketingConsent: false,
    })

    const user = await prisma.user.findUniqueOrThrow({ where: { email }, select: { id: true } })
    const audit = await prisma.auditLog.findFirst({
      where: { actorUserId: user.id, action: 'user.registered' },
    })

    expect(audit).not.toBeNull()
    expect(audit!.entityType).toBe('User')
  })

  it('normalises the e-mail address to lower case', async () => {
    const email = uniqueEmail()
    await registerUser({
      email: email.toUpperCase(),
      password: STRONG_PASSWORD,
      acceptedTerms: true,
      marketingConsent: false,
    })

    expect(await prisma.user.findUnique({ where: { email } })).not.toBeNull()
  })

  it('stores the password as a bcrypt hash, never in clear text', async () => {
    const email = uniqueEmail()
    await registerUser({
      email,
      password: STRONG_PASSWORD,
      acceptedTerms: true,
      marketingConsent: false,
    })

    const user = await prisma.user.findUniqueOrThrow({
      where: { email },
      select: { passwordHash: true },
    })

    expect(user.passwordHash).not.toBe(STRONG_PASSWORD)
    expect(user.passwordHash).toMatch(/^\$2[aby]\$/)
    expect(await verifyPassword(STRONG_PASSWORD, user.passwordHash!)).toBe(true)
  })

  it('stores the verification token hashed, not in the clear', async () => {
    const { id, email } = await createVerifiedUser()
    const token = await issueVerificationEmail(id, email, 'nl')

    const record = await prisma.emailVerificationToken.findFirstOrThrow({
      where: { userId: id, usedAt: null },
      select: { tokenHash: true },
    })

    // Read access to the database must not be enough to activate an account.
    expect(record.tokenHash).not.toBe(token)
    expect(record.tokenHash).toBe(hashToken(token))
  })

  it('records the failed send honestly when e-mail is not configured', async () => {
    const { id } = await createVerifiedUser()

    const notification = await prisma.notification.findFirstOrThrow({
      where: { userId: id, kind: 'ACCOUNT_VERIFICATION' },
    })

    // Nothing is ever marked SENT that a provider did not accept (§11).
    expect(notification.status).toBe('FAILED')
    expect(notification.errorCode).toBe('EMAIL_NOT_CONFIGURED')
    expect(notification.sentAt).toBeNull()
  })

  it('does not reveal that an address is already taken', async () => {
    const email = uniqueEmail()
    const input = {
      email,
      password: STRONG_PASSWORD,
      acceptedTerms: true,
      marketingConsent: false,
    }

    const first = await registerUser(input)
    const second = await registerUser(input)

    // Identical outcome, so the form cannot be used to enumerate accounts.
    expect(second).toEqual(first)
    expect(await prisma.user.count({ where: { email } })).toBe(1)
  })

  it('refuses registration without accepting the terms', async () => {
    const email = uniqueEmail()
    const result = await registerUser({
      email,
      password: STRONG_PASSWORD,
      acceptedTerms: false,
      marketingConsent: false,
    })

    expect(result.status).toBe('terms-required')
    expect(await prisma.user.findUnique({ where: { email } })).toBeNull()
  })

  it('records marketing consent as a timestamp when given', async () => {
    const email = uniqueEmail()
    await registerUser({
      email,
      password: STRONG_PASSWORD,
      acceptedTerms: true,
      marketingConsent: true,
    })

    const user = await prisma.user.findUniqueOrThrow({ where: { email } })
    // GDPR §25 wants provable consent; a boolean alone is not proof.
    expect(user.marketingConsentAt).toBeInstanceOf(Date)
  })
})

describe('e-mail verification', () => {
  it('marks the account verified and sends a welcome mail', async () => {
    const { id, email } = await createVerifiedUser()
    const token = await issueVerificationEmail(id, email, 'nl')

    expect((await verifyEmailToken(token)).status).toBe('verified')

    const user = await prisma.user.findUniqueOrThrow({ where: { email } })
    expect(user.emailVerified).toBeInstanceOf(Date)

    expect(
      await prisma.notification.findFirst({ where: { userId: id, kind: 'ACCOUNT_WELCOME' } }),
    ).not.toBeNull()
  })

  it('reports an already-verified account instead of failing', async () => {
    const { id, email } = await createVerifiedUser()
    const token = await issueVerificationEmail(id, email, 'nl')
    await verifyEmailToken(token)

    // Mail clients prefetch links; a second visit must not look like an error.
    expect((await verifyEmailToken(token)).status).toBe('already-verified')
  })

  it('rejects an unknown token', async () => {
    expect((await verifyEmailToken('does-not-exist')).status).toBe('invalid')
  })

  it('rejects an expired token and leaves the account unverified', async () => {
    const { id, email } = await createVerifiedUser()
    const token = await issueVerificationEmail(id, email, 'nl')

    await prisma.emailVerificationToken.updateMany({
      where: { tokenHash: hashToken(token) },
      data: { expiresAt: new Date(Date.now() - 1000) },
    })

    expect((await verifyEmailToken(token)).status).toBe('expired')
    expect((await prisma.user.findUniqueOrThrow({ where: { email } })).emailVerified).toBeNull()
  })

  it('invalidates the previous token when a new one is issued', async () => {
    const { id, email } = await createVerifiedUser()

    const firstToken = await issueVerificationEmail(id, email, 'nl')
    const secondToken = await issueVerificationEmail(id, email, 'nl')

    expect(secondToken).not.toBe(firstToken)
    // A superseded link must stop working, or an old mail stays a live key.
    expect((await verifyEmailToken(firstToken)).status).toBe('invalid')
    expect((await verifyEmailToken(secondToken)).status).toBe('verified')
  })
})

describe('password reset', () => {
  it('sets a new password, clears the lockout and revokes every session', async () => {
    const { id, email } = await createVerifiedUser()

    // Simulate a locked-out account with two live sessions.
    await prisma.user.update({
      where: { id },
      data: { failedLoginAttempts: 10, lockedUntil: new Date(Date.now() + 900_000) },
    })
    const sessionA = await createSession(id, { userAgent: 'test-a' })
    const sessionB = await createSession(id, { userAgent: 'test-b' })
    expect(await listSessions(id)).toHaveLength(2)

    const token = await issuePasswordResetToken(id, email, 'nl')
    expect((await resetPassword(token, 'een gloednieuw lang wachtwoord')).status).toBe('reset')

    const updated = await prisma.user.findUniqueOrThrow({ where: { email } })
    expect(await verifyPassword('een gloednieuw lang wachtwoord', updated.passwordHash!)).toBe(true)
    expect(await verifyPassword(STRONG_PASSWORD, updated.passwordHash!)).toBe(false)
    expect(updated.failedLoginAttempts).toBe(0)
    expect(updated.lockedUntil).toBeNull()

    // If the reset happened because the account was taken over, this is the
    // step that actually evicts the attacker.
    expect(await isSessionValid(sessionA)).toBe(false)
    expect(await isSessionValid(sessionB)).toBe(false)
    expect(await listSessions(id)).toHaveLength(0)
  })

  it('consumes the reset token exactly once', async () => {
    const { id, email } = await createVerifiedUser()
    const token = await issuePasswordResetToken(id, email, 'nl')

    expect((await resetPassword(token, 'eerste nieuwe wachtwoord')).status).toBe('reset')
    expect((await resetPassword(token, 'tweede nieuwe wachtwoord')).status).toBe('invalid')
  })

  it('rejects an expired reset token', async () => {
    const { id, email } = await createVerifiedUser()
    const token = await issuePasswordResetToken(id, email, 'nl')

    await prisma.passwordResetToken.updateMany({
      where: { tokenHash: hashToken(token) },
      data: { expiresAt: new Date(Date.now() - 1000) },
    })

    expect((await resetPassword(token, 'nog een nieuw wachtwoord')).status).toBe('expired')
  })

  it('stays silent for an unknown address', async () => {
    // No throw, no row, no way to tell the address apart from a real one.
    await expect(requestPasswordReset('nobody@woningalert.test')).resolves.toBeUndefined()
    expect(
      await prisma.passwordResetToken.count({
        where: { user: { email: 'nobody@woningalert.test' } },
      }),
    ).toBe(0)
  })

  it('issues a token for a real address through the public entry point', async () => {
    const { id, email } = await createVerifiedUser()

    await requestPasswordReset(email, '127.0.0.1')

    const token = await prisma.passwordResetToken.findFirst({
      where: { userId: id, usedAt: null },
    })
    expect(token).not.toBeNull()
    expect(token!.requestIp).toBe('127.0.0.1')
  })

  it('also verifies the account, because mailbox control was proven', async () => {
    const { id, email } = await createVerifiedUser()
    const token = await issuePasswordResetToken(id, email, 'nl')

    await resetPassword(token, 'weer een nieuw lang wachtwoord')

    expect((await prisma.user.findUniqueOrThrow({ where: { email } })).emailVerified).toBeInstanceOf(
      Date,
    )
  })
})

describe('session registry', () => {
  it('lists sessions and marks the current one', async () => {
    const { id } = await createVerifiedUser()

    const current = await createSession(id, { userAgent: 'current', ipAddress: '127.0.0.1' })
    await createSession(id, { userAgent: 'other' })

    const sessions = await listSessions(id, current)
    expect(sessions).toHaveLength(2)
    expect(sessions.filter((session) => session.isCurrent)).toHaveLength(1)
  })

  it('treats an expired session as invalid', async () => {
    const { id } = await createVerifiedUser()
    const token = await createSession(id)

    await prisma.session.updateMany({
      where: { sessionToken: token },
      data: { expires: new Date(Date.now() - 1000) },
    })

    expect(await isSessionValid(token)).toBe(false)
  })
})
