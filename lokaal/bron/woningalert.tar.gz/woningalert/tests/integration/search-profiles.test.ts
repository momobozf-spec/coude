import { randomUUID } from 'node:crypto'

import { afterAll, describe, expect, it } from 'vitest'

import { NotificationChannel } from '@/generated/prisma/enums'
import { registerUser } from '@/server/auth/service'
import { prisma } from '@/server/db'
import { EntitlementError, getEntitlements } from '@/server/entitlements'
import type { SearchProfileInput } from '@/server/search-profiles/schemas'
import {
  createSearchProfile,
  deleteSearchProfile,
  getSearchProfile,
  getSearchProfileQuota,
  listSearchProfiles,
  setSearchProfileActive,
  updateSearchProfile,
} from '@/server/search-profiles/service'

/**
 * Search profile CRUD and plan enforcement against a real database
 * (REQUIREMENTS §5, §18, §33).
 *
 * The point of these tests is the two things a unit test cannot prove: that a
 * plan limit actually stops a second insert, and that one user's id in a WHERE
 * clause really does make another user's row invisible.
 */

const createdEmails: string[] = []

function uniqueEmail(): string {
  const email = `sp-${randomUUID()}@woningalert.test`
  createdEmails.push(email)
  return email
}

async function createUser(plan: 'FREE' | 'PREMIUM_MONTHLY' = 'FREE'): Promise<string> {
  const email = uniqueEmail()
  await registerUser({
    email,
    password: 'grijze kat op het dak',
    acceptedTerms: true,
    marketingConsent: false,
  })

  const user = await prisma.user.findUniqueOrThrow({ where: { email }, select: { id: true } })

  if (plan !== 'FREE') {
    await prisma.subscription.updateMany({ where: { userId: user.id }, data: { plan } })
  }

  return user.id
}

function profileInput(overrides: Partial<SearchProfileInput> = {}): SearchProfileInput {
  return {
    name: 'Appartement Gent',
    isActive: true,
    countries: ['BE'],
    provinces: [],
    regions: [],
    municipalities: ['Gent'],
    postalCodes: ['9000'],
    listingType: 'RENT',
    propertyTypes: ['APARTMENT'],
    requireGarden: false,
    requireTerrace: false,
    requireBalcony: false,
    requireParking: false,
    requireGarage: false,
    requireFurnished: false,
    requirePetsAllowed: false,
    requireLift: false,
    keywords: [],
    excludedKeywords: [],
    notificationChannels: [NotificationChannel.EMAIL],
    notifyOnPriceDrop: false,
    notifyOnBackAvailable: false,
    notifyOnAvailabilityChange: false,
    ...overrides,
  } as SearchProfileInput
}

afterAll(async () => {
  if (createdEmails.length > 0) {
    await prisma.user.deleteMany({ where: { email: { in: createdEmails } } })
  }
})

describe('creating search profiles', () => {
  it('stores every filter it was given', async () => {
    const userId = await createUser()

    const { id } = await createSearchProfile(
      userId,
      profileInput({
        name: 'Huis met tuin',
        listingType: 'BUY',
        maxPrice: 450_000,
        minBedrooms: 3,
        requireGarden: true,
        keywords: ['zuidgericht'],
        excludedKeywords: ['erfpacht'],
        propertyTypes: ['HOUSE', 'VILLA'],
      }),
    )

    const stored = await getSearchProfile(userId, id)

    expect(stored).not.toBeNull()
    expect(stored!.name).toBe('Huis met tuin')
    expect(stored!.listingType).toBe('BUY')
    expect(stored!.maxPrice).toBe(450_000)
    expect(stored!.minBedrooms).toBe(3)
    expect(stored!.requireGarden).toBe(true)
    expect(stored!.keywords).toEqual(['zuidgericht'])
    expect(stored!.excludedKeywords).toEqual(['erfpacht'])
    expect(stored!.propertyTypes).toEqual(['HOUSE', 'VILLA'])
    expect(stored!.matchCount).toBe(0)
    expect(stored!.lastMatchedAt).toBeNull()
  })

  it('writes an audit log entry', async () => {
    const userId = await createUser()
    const { id } = await createSearchProfile(userId, profileInput())

    const audit = await prisma.auditLog.findFirst({
      where: { entityType: 'SearchProfile', entityId: id, action: 'search_profile.created' },
    })

    expect(audit).not.toBeNull()
    expect(audit!.actorUserId).toBe(userId)
  })
})

describe('plan limits', () => {
  it('lets a free account create exactly one profile', async () => {
    const userId = await createUser('FREE')

    await createSearchProfile(userId, profileInput({ name: 'Eerste' }))

    // §18: the free plan gets one search profile, enforced server-side.
    await expect(createSearchProfile(userId, profileInput({ name: 'Tweede' }))).rejects.toThrow(
      EntitlementError,
    )

    expect(await prisma.searchProfile.count({ where: { userId } })).toBe(1)
  })

  it('reports the limit and the current count on the error', async () => {
    const userId = await createUser('FREE')
    await createSearchProfile(userId, profileInput())

    await expect(createSearchProfile(userId, profileInput())).rejects.toMatchObject({
      code: 'SEARCH_PROFILE_LIMIT_REACHED',
      limit: 1,
      current: 1,
    })
  })

  it('lets a premium account create several', async () => {
    const userId = await createUser('PREMIUM_MONTHLY')

    await createSearchProfile(userId, profileInput({ name: 'Een' }))
    await createSearchProfile(userId, profileInput({ name: 'Twee' }))
    await createSearchProfile(userId, profileInput({ name: 'Drie' }))

    expect(await prisma.searchProfile.count({ where: { userId } })).toBe(3)
  })

  it('refuses a channel the plan does not include', async () => {
    const userId = await createUser('FREE')

    await expect(
      createSearchProfile(
        userId,
        profileInput({ notificationChannels: [NotificationChannel.EMAIL, NotificationChannel.SMS] }),
      ),
    ).rejects.toMatchObject({ code: 'CHANNEL_NOT_ALLOWED' })
  })

  it('allows premium channels on a premium plan', async () => {
    const userId = await createUser('PREMIUM_MONTHLY')

    const { id } = await createSearchProfile(
      userId,
      profileInput({
        notificationChannels: [NotificationChannel.EMAIL, NotificationChannel.SMS],
      }),
    )

    const stored = await getSearchProfile(userId, id)
    expect(stored!.notificationChannels).toContain(NotificationChannel.SMS)
  })

  it('reports quota correctly', async () => {
    const userId = await createUser('FREE')

    expect(await getSearchProfileQuota(userId)).toMatchObject({ used: 0, limit: 1, canCreate: true })

    await createSearchProfile(userId, profileInput())

    expect(await getSearchProfileQuota(userId)).toMatchObject({
      used: 1,
      limit: 1,
      canCreate: false,
    })
  })
})

describe('ownership', () => {
  it('hides another user profile entirely', async () => {
    const owner = await createUser('PREMIUM_MONTHLY')
    const stranger = await createUser('PREMIUM_MONTHLY')

    const { id } = await createSearchProfile(owner, profileInput({ name: 'Van de eigenaar' }))

    // "Not found" and "not yours" must be indistinguishable, or profile ids can
    // be probed one by one.
    expect(await getSearchProfile(stranger, id)).toBeNull()
    expect(await listSearchProfiles(stranger)).toHaveLength(0)
  })

  it('refuses to update another user profile', async () => {
    const owner = await createUser('PREMIUM_MONTHLY')
    const stranger = await createUser('PREMIUM_MONTHLY')

    const { id } = await createSearchProfile(owner, profileInput({ name: 'Origineel' }))

    const result = await updateSearchProfile(stranger, id, profileInput({ name: 'Gekaapt' }))

    expect(result.updated).toBe(false)
    expect((await getSearchProfile(owner, id))!.name).toBe('Origineel')
  })

  it('refuses to delete another user profile', async () => {
    const owner = await createUser('PREMIUM_MONTHLY')
    const stranger = await createUser('PREMIUM_MONTHLY')

    const { id } = await createSearchProfile(owner, profileInput())

    expect(await deleteSearchProfile(stranger, id)).toEqual({ deleted: false })
    expect(await getSearchProfile(owner, id)).not.toBeNull()
  })

  it('refuses to toggle another user profile', async () => {
    const owner = await createUser('PREMIUM_MONTHLY')
    const stranger = await createUser('PREMIUM_MONTHLY')

    const { id } = await createSearchProfile(owner, profileInput({ isActive: true }))

    expect(await setSearchProfileActive(stranger, id, false)).toEqual({ updated: false })
    expect((await getSearchProfile(owner, id))!.isActive).toBe(true)
  })
})

describe('updating', () => {
  it('saves changed filters', async () => {
    const userId = await createUser('PREMIUM_MONTHLY')
    const { id } = await createSearchProfile(userId, profileInput({ maxPrice: 900 }))

    await updateSearchProfile(
      userId,
      id,
      profileInput({ name: 'Bijgewerkt', maxPrice: 1200, requireTerrace: true }),
    )

    const stored = await getSearchProfile(userId, id)
    expect(stored!.name).toBe('Bijgewerkt')
    expect(stored!.maxPrice).toBe(1200)
    expect(stored!.requireTerrace).toBe(true)
  })

  it('clears a filter that was removed', async () => {
    const userId = await createUser('PREMIUM_MONTHLY')
    const { id } = await createSearchProfile(userId, profileInput({ maxPrice: 900 }))

    // An absent value must become NULL, not silently keep the old number.
    await updateSearchProfile(userId, id, profileInput({}))

    expect((await getSearchProfile(userId, id))!.maxPrice).toBeNull()
  })

  it('narrows channels instead of refusing the save after a downgrade', async () => {
    const userId = await createUser('PREMIUM_MONTHLY')
    const { id } = await createSearchProfile(
      userId,
      profileInput({
        notificationChannels: [NotificationChannel.EMAIL, NotificationChannel.SMS],
      }),
    )

    // The subscription lapses back to free.
    await prisma.subscription.updateMany({ where: { userId }, data: { plan: 'FREE' } })

    const result = await updateSearchProfile(
      userId,
      id,
      profileInput({
        name: 'Nog steeds bewerkbaar',
        notificationChannels: [NotificationChannel.EMAIL, NotificationChannel.SMS],
      }),
    )

    expect(result.updated).toBe(true)

    // Refusing the save would leave the user unable to edit anything at all.
    const stored = await getSearchProfile(userId, id)
    expect(stored!.notificationChannels).toEqual([NotificationChannel.EMAIL])
    expect(stored!.name).toBe('Nog steeds bewerkbaar')
  })
})

describe('deleting and toggling', () => {
  it('deletes a profile the user owns', async () => {
    const userId = await createUser()
    const { id } = await createSearchProfile(userId, profileInput())

    expect(await deleteSearchProfile(userId, id)).toEqual({ deleted: true })
    expect(await getSearchProfile(userId, id)).toBeNull()
  })

  it('frees up quota after a delete', async () => {
    const userId = await createUser('FREE')
    const { id } = await createSearchProfile(userId, profileInput())

    await deleteSearchProfile(userId, id)

    expect(await getSearchProfileQuota(userId)).toMatchObject({ used: 0, canCreate: true })
  })

  it('toggles active state', async () => {
    const userId = await createUser()
    const { id } = await createSearchProfile(userId, profileInput({ isActive: true }))

    await setSearchProfileActive(userId, id, false)
    expect((await getSearchProfile(userId, id))!.isActive).toBe(false)

    await setSearchProfileActive(userId, id, true)
    expect((await getSearchProfile(userId, id))!.isActive).toBe(true)
  })
})

describe('entitlements', () => {
  it('gives a fresh account the free plan', async () => {
    const userId = await createUser()
    const entitlements = await getEntitlements(userId)

    expect(entitlements.plan).toBe('FREE')
    expect(entitlements.isPremium).toBe(false)
    expect(entitlements.maxSearchProfiles).toBe(1)
    expect(entitlements.allowedChannels).toEqual([NotificationChannel.EMAIL])
  })

  it('falls back to free when a paid period has quietly run out', async () => {
    const userId = await createUser('PREMIUM_MONTHLY')

    await prisma.subscription.updateMany({
      where: { userId },
      data: { currentPeriodEnd: new Date(Date.now() - 24 * 60 * 60 * 1000) },
    })

    // A webhook that never arrived must not leave premium open indefinitely.
    const entitlements = await getEntitlements(userId)
    expect(entitlements.plan).toBe('FREE')
    expect(entitlements.isPremium).toBe(false)
  })

  it('keeps access while a renewal is being retried', async () => {
    const userId = await createUser('PREMIUM_MONTHLY')

    await prisma.subscription.updateMany({
      where: { userId },
      data: {
        status: 'PAST_DUE',
        currentPeriodEnd: new Date(Date.now() + 24 * 60 * 60 * 1000),
      },
    })

    // A failed renewal should not cut someone off mid-search while the payment
    // provider is still retrying.
    expect((await getEntitlements(userId)).isPremium).toBe(true)
  })

  it('drops access once a subscription is cancelled', async () => {
    const userId = await createUser('PREMIUM_MONTHLY')

    await prisma.subscription.updateMany({ where: { userId }, data: { status: 'CANCELLED' } })

    expect((await getEntitlements(userId)).plan).toBe('FREE')
  })
})
