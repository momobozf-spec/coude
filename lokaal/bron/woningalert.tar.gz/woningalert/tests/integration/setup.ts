import { afterAll, beforeAll } from 'vitest'

/**
 * Integration test setup.
 *
 * Integration tests run against a REAL PostgreSQL and a REAL Redis — the same
 * engines as production. They are skipped nowhere and mocked nowhere: a test
 * that passes against a fake database tells you nothing about a schema change.
 *
 * CI provides both as service containers (.github/workflows/ci.yml). Locally:
 *   docker compose up -d db redis
 * or `npm run dev:db` plus a Redis of your choosing.
 */

if (!process.env.DATABASE_URL) {
  throw new Error(
    'Integration tests need DATABASE_URL. Start the stack with `docker compose up -d db redis` ' +
      'or `npm run dev:db`, then re-run. See README.md.',
  )
}

if (!process.env.REDIS_URL) {
  process.env.REDIS_URL = 'redis://127.0.0.1:6379'
}

// Vitest already sets NODE_ENV=test, which silences the logger so a failing
// test shows assertion output rather than a wall of structured log lines. This
// asserts it rather than assigning it: NODE_ENV is typed read-only, and a test
// run that somehow started in another mode should fail loudly here.
if (process.env.NODE_ENV !== 'test') {
  throw new Error(`Integration tests must run with NODE_ENV=test, got "${process.env.NODE_ENV}".`)
}

beforeAll(async () => {
  const { prisma } = await import('@/server/db')
  await prisma.$queryRaw`SELECT 1`
})

afterAll(async () => {
  const { disconnectPrisma } = await import('@/server/db')
  const { redis } = await import('@/server/redis')

  await disconnectPrisma()
  if (redis.status !== 'end') {
    await redis.quit()
  }
})
