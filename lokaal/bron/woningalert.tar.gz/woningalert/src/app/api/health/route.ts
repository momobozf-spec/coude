import { NextResponse } from 'next/server'

import { getHealthReport } from '@/server/health'

export const dynamic = 'force-dynamic'
export const revalidate = 0

/**
 * GET /api/health
 *
 * 200 when every dependency answers, 503 otherwise, so an orchestrator can act
 * on the status code alone. The body never contains secrets (REQUIREMENTS §21).
 */
export async function GET(): Promise<NextResponse> {
  const report = await getHealthReport()

  return NextResponse.json(report, {
    status: report.status === 'ok' ? 200 : 503,
    headers: {
      'Cache-Control': 'no-store, max-age=0',
    },
  })
}
