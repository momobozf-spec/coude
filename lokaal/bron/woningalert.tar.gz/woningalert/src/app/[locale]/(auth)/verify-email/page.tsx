import type { Metadata } from 'next'
import { CheckCircle2Icon, InfoIcon, MailIcon } from 'lucide-react'
import { getTranslations, setRequestLocale } from 'next-intl/server'

import { ResendVerificationForm } from '@/components/auth/resend-verification-form'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Link } from '@/i18n/navigation'
import { verifyEmailToken } from '@/server/auth/service'

// Verification mutates state, so this page must never be cached.
export const dynamic = 'force-dynamic'

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>
}): Promise<Metadata> {
  const { locale } = await params
  const t = await getTranslations({ locale, namespace: 'auth.verifyEmail' })
  return { title: t('pendingTitle'), robots: { index: false, follow: false } }
}

export default async function VerifyEmailPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>
  searchParams: Promise<{ token?: string }>
}) {
  const { locale } = await params
  setRequestLocale(locale)

  const { token } = await searchParams
  const t = await getTranslations('auth')

  // No token: the user landed here straight after registering.
  if (!token) {
    return (
      <Card>
        <CardHeader>
          <MailIcon className="text-primary size-6" />
          <CardTitle>{t('verifyEmail.pendingTitle')}</CardTitle>
          <CardDescription>{t('verifyEmail.pendingBody')}</CardDescription>
        </CardHeader>
        <CardContent>
          <ResendVerificationForm />
        </CardContent>
      </Card>
    )
  }

  const result = await verifyEmailToken(token)

  if (result.status === 'verified' || result.status === 'already-verified') {
    const isNew = result.status === 'verified'
    return (
      <Card>
        <CardHeader>
          <CheckCircle2Icon className="text-success size-6" />
          <CardTitle>
            {isNew ? t('verifyEmail.successTitle') : t('verifyEmail.alreadyTitle')}
          </CardTitle>
          <CardDescription>
            {isNew ? t('verifyEmail.successBody') : t('verifyEmail.alreadyBody')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button asChild size="lg" className="w-full">
            <Link href="/login">{t('verifyEmail.goToLogin')}</Link>
          </Button>
        </CardContent>
      </Card>
    )
  }

  const expired = result.status === 'expired'

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          {expired ? t('verifyEmail.expiredTitle') : t('verifyEmail.invalidTitle')}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <InfoIcon />
          <AlertDescription>
            {expired ? t('verifyEmail.expiredBody') : t('verifyEmail.invalidBody')}
          </AlertDescription>
        </Alert>
        <ResendVerificationForm />
      </CardContent>
    </Card>
  )
}
