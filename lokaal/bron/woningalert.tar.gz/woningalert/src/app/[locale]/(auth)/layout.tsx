import { getTranslations } from 'next-intl/server'

import { Link } from '@/i18n/navigation'

export default async function AuthLayout({ children }: { children: React.ReactNode }) {
  const t = await getTranslations('common')

  return (
    <div className="bg-muted/40 flex min-h-dvh flex-col">
      <header className="px-6 py-6">
        <Link href="/" className="text-primary text-base font-bold tracking-tight">
          {t('appName')}
        </Link>
      </header>

      <main className="flex flex-1 items-start justify-center px-4 pb-16 sm:items-center sm:pb-24">
        <div className="w-full max-w-md">{children}</div>
      </main>
    </div>
  )
}
