import type { Metadata } from 'next'
import { getTranslations, setRequestLocale } from 'next-intl/server'
import { redirect } from 'next/navigation'

import { GoogleButton } from '@/components/auth/google-button'
import { LoginForm } from '@/components/auth/login-form'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Link } from '@/i18n/navigation'
import { integrations } from '@/lib/env'
import { getCurrentUser } from '@/server/auth/guards'
import { safeCallbackUrl } from '@/server/auth/schemas'

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>
}): Promise<Metadata> {
  const { locale } = await params
  const t = await getTranslations({ locale, namespace: 'auth.login' })
  return { title: t('title'), robots: { index: false, follow: false } }
}

export default async function LoginPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>
  searchParams: Promise<{ callbackUrl?: string }>
}) {
  const { locale } = await params
  setRequestLocale(locale)

  const { callbackUrl } = await searchParams
  const destination = safeCallbackUrl(callbackUrl)

  // Already signed in: no reason to show a login form.
  const user = await getCurrentUser()
  if (user) redirect(destination)

  const t = await getTranslations('auth')

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('login.title')}</CardTitle>
        <CardDescription>{t('login.subtitle')}</CardDescription>
      </CardHeader>

      <CardContent className="space-y-5">
        <LoginForm callbackUrl={destination} />

        {/* Rendered only when Google OAuth is configured (§39). */}
        {integrations.googleOAuth ? (
          <>
            <div className="flex items-center gap-3">
              <span className="bg-border h-px flex-1" />
              <span className="text-muted-foreground text-xs uppercase">{t('common.or')}</span>
              <span className="bg-border h-px flex-1" />
            </div>
            <GoogleButton callbackUrl={destination} />
          </>
        ) : null}

        <p className="text-muted-foreground text-center text-sm">
          {t('login.noAccount')}{' '}
          <Link href="/register" className="text-primary font-medium underline-offset-4 hover:underline">
            {t('login.registerLink')}
          </Link>
        </p>
      </CardContent>
    </Card>
  )
}
