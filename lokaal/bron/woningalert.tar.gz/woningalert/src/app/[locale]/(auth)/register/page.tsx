import type { Metadata } from 'next'
import { getTranslations, setRequestLocale } from 'next-intl/server'
import { redirect } from 'next/navigation'

import { GoogleButton } from '@/components/auth/google-button'
import { RegisterForm } from '@/components/auth/register-form'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Link } from '@/i18n/navigation'
import { isLocale, defaultLocale } from '@/i18n/routing'
import { integrations } from '@/lib/env'
import { getCurrentUser } from '@/server/auth/guards'

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>
}): Promise<Metadata> {
  const { locale } = await params
  const t = await getTranslations({ locale, namespace: 'auth.register' })
  return { title: t('title'), robots: { index: false, follow: false } }
}

export default async function RegisterPage({
  params,
}: {
  params: Promise<{ locale: string }>
}) {
  const { locale } = await params
  setRequestLocale(locale)

  const user = await getCurrentUser()
  if (user) redirect('/dashboard')

  const t = await getTranslations('auth')

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('register.title')}</CardTitle>
        <CardDescription>{t('register.subtitle')}</CardDescription>
      </CardHeader>

      <CardContent className="space-y-5">
        <RegisterForm locale={isLocale(locale) ? locale : defaultLocale} />

        {integrations.googleOAuth ? (
          <>
            <div className="flex items-center gap-3">
              <span className="bg-border h-px flex-1" />
              <span className="text-muted-foreground text-xs uppercase">{t('common.or')}</span>
              <span className="bg-border h-px flex-1" />
            </div>
            <GoogleButton />
          </>
        ) : null}

        <p className="text-muted-foreground text-center text-sm">
          {t('register.haveAccount')}{' '}
          <Link href="/login" className="text-primary font-medium underline-offset-4 hover:underline">
            {t('register.loginLink')}
          </Link>
        </p>
      </CardContent>
    </Card>
  )
}
