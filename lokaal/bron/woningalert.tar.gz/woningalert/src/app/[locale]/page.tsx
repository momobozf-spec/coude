import { getTranslations, setRequestLocale } from 'next-intl/server'

/**
 * Phase-0 shell.
 *
 * The commercial landing page (REQUIREMENTS §28) is built in phase 6. What is
 * here now is real copy, not filler: no invented user counts, no testimonials,
 * no review scores.
 */
export default async function HomePage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params
  setRequestLocale(locale)

  const t = await getTranslations('home')
  const tCommon = await getTranslations('common')

  return (
    <main className="mx-auto flex min-h-dvh max-w-3xl flex-col justify-center px-6 py-16">
      <p className="text-primary text-sm font-semibold tracking-wide uppercase">
        {tCommon('appName')}
      </p>
      <h1 className="text-foreground mt-4 text-4xl font-bold tracking-tight text-balance sm:text-5xl">
        {t('heroTitle')}
      </h1>
      <p className="text-muted-foreground mt-6 text-lg text-pretty">{t('heroSubtitle')}</p>
    </main>
  )
}
