import type { Metadata } from 'next'
import { HeartIcon, InfoIcon, PlusIcon, SearchIcon, SparklesIcon } from 'lucide-react'
import { getTranslations, setRequestLocale } from 'next-intl/server'

import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Link } from '@/i18n/navigation'
import { requireUser } from '@/server/auth/guards'
import { prisma } from '@/server/db'
import { getEntitlements } from '@/server/entitlements'

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>
}): Promise<Metadata> {
  const { locale } = await params
  const t = await getTranslations({ locale, namespace: 'nav' })
  return { title: t('dashboard'), robots: { index: false, follow: false } }
}

/**
 * The dashboard (REQUIREMENTS §14).
 *
 * Every number here is counted from the database. Nothing is estimated,
 * rounded up or filled in for effect: with no sources active the counts are
 * genuinely zero, and the page says so rather than inventing activity (§3).
 */
export default async function DashboardPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params
  setRequestLocale(locale)

  const user = await requireUser('/dashboard')
  const t = await getTranslations()

  const startOfToday = new Date()
  startOfToday.setHours(0, 0, 0, 0)

  const [activeSearches, totalSearches, newMatches, matchesToday, favorites, activeSources, entitlements] =
    await Promise.all([
      prisma.searchProfile.count({ where: { userId: user.id, isActive: true } }),
      prisma.searchProfile.count({ where: { userId: user.id } }),
      prisma.propertyMatch.count({ where: { userId: user.id, viewedAt: null } }),
      prisma.propertyMatch.count({ where: { userId: user.id, matchedAt: { gte: startOfToday } } }),
      prisma.favorite.count({ where: { userId: user.id } }),
      prisma.propertySource.count({ where: { isEnabled: true } }),
      getEntitlements(user.id),
    ])

  const stats = [
    { key: 'statNewMatches', value: newMatches, icon: SparklesIcon },
    { key: 'statMatchesToday', value: matchesToday, icon: SparklesIcon },
    { key: 'statActiveSearches', value: activeSearches, icon: SearchIcon },
    { key: 'statFavorites', value: favorites, icon: HeartIcon },
  ] as const

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-8 sm:px-6 sm:py-10">
      <header className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t('nav.dashboard')}</h1>
          <p className="text-muted-foreground mt-1 text-sm">
            {t('dashboard.greeting', { name: user.name ?? user.email })}
          </p>
        </div>
        <Badge variant={entitlements.isPremium ? 'default' : 'muted'}>
          {t(`dashboard.plan${entitlements.plan}`)}
        </Badge>
      </header>

      {activeSources === 0 ? (
        <Alert className="mb-6">
          <InfoIcon />
          <AlertTitle>{t('platformStatus.noSourcesTitle')}</AlertTitle>
          <AlertDescription>{t('platformStatus.noSourcesBody')}</AlertDescription>
        </Alert>
      ) : null}

      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.key}>
            <CardContent className="space-y-1">
              <stat.icon className="text-muted-foreground size-4" aria-hidden="true" />
              <p className="text-2xl font-semibold tabular-nums">{stat.value}</p>
              <p className="text-muted-foreground text-xs leading-tight">
                {t(`dashboard.${stat.key}`)}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardContent className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="font-medium">{t('searchProfiles.list.title')}</p>
            <p className="text-muted-foreground mt-0.5 text-sm">
              {t('searchProfiles.list.quotaUsed', {
                used: totalSearches,
                limit: entitlements.maxSearchProfiles,
              })}
            </p>
          </div>
          <Button asChild variant={totalSearches === 0 ? 'default' : 'outline'}>
            <Link href={totalSearches === 0 ? '/searches/new' : '/searches'}>
              {totalSearches === 0 ? <PlusIcon /> : <SearchIcon />}
              {totalSearches === 0
                ? t('searchProfiles.list.createButton')
                : t('dashboard.viewSearches')}
            </Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
