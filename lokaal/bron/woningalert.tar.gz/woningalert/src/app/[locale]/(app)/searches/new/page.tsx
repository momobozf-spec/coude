import type { Metadata } from 'next'
import { InfoIcon } from 'lucide-react'
import { getTranslations, setRequestLocale } from 'next-intl/server'

import {
  EMPTY_SEARCH_PROFILE,
  SearchProfileForm,
} from '@/components/search-profiles/search-profile-form'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Link } from '@/i18n/navigation'
import { defaultLocale, isLocale } from '@/i18n/routing'
import { requireUser } from '@/server/auth/guards'
import { getConfiguredChannels } from '@/server/search-profiles/channels'
import { getSearchProfileQuota } from '@/server/search-profiles/service'

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>
}): Promise<Metadata> {
  const { locale } = await params
  const t = await getTranslations({ locale, namespace: 'searchProfiles.form' })
  return { title: t('createTitle'), robots: { index: false, follow: false } }
}

export default async function NewSearchPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params
  setRequestLocale(locale)

  const user = await requireUser('/searches/new')
  const t = await getTranslations('searchProfiles')
  const quota = await getSearchProfileQuota(user.id)

  // The plan limit is enforced in the action too. Checking here as well means
  // the user sees why instead of filling in a long form and being refused at
  // the end.
  if (!quota.canCreate) {
    return (
      <div className="mx-auto w-full max-w-2xl px-4 py-8 sm:px-6 sm:py-10">
        <Alert>
          <InfoIcon />
          <AlertTitle>{t('list.quotaReached', { limit: quota.limit })}</AlertTitle>
          <AlertDescription>{t('list.upgradeHint')}</AlertDescription>
        </Alert>
        <Button asChild variant="outline" className="mt-4">
          <Link href="/searches">{t('form.cancel')}</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="mx-auto w-full max-w-2xl px-4 py-8 sm:px-6 sm:py-10">
      <Card>
        <CardHeader>
          <CardTitle>{t('form.createTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          <SearchProfileForm
            mode="create"
            values={EMPTY_SEARCH_PROFILE}
            locale={isLocale(locale) ? locale : defaultLocale}
            allowedChannels={quota.entitlements.allowedChannels}
            configuredChannels={getConfiguredChannels()}
          />
        </CardContent>
      </Card>
    </div>
  )
}
