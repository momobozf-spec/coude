import { getTranslations } from 'next-intl/server'

import { AppNav } from '@/components/app/app-nav'
import { requireUser } from '@/server/auth/guards'

/**
 * Shell for every signed-in page.
 *
 * The session check lives here rather than in `proxy.ts`: the proxy runs on the
 * edge runtime, and pulling Prisma and bcrypt into it would not build. A layout
 * runs on the server for every route beneath it, which is the right place for
 * an access check anyway — each page additionally guards its own data access.
 */
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser()
  const t = await getTranslations('nav')

  return (
    <div className="flex min-h-dvh flex-col">
      <AppNav
        userEmail={user.email}
        userName={user.name}
        isAdmin={user.role === 'ADMIN'}
        labels={{
          dashboard: t('dashboard'),
          searches: t('searches'),
          account: t('account'),
          admin: t('admin'),
          logout: t('logout'),
          menu: t('menu'),
        }}
      />
      <main className="flex-1">{children}</main>
    </div>
  )
}
