import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { getTranslations, setRequestLocale } from 'next-intl/server'

import {
  SearchProfileForm,
  type SearchProfileFormValues,
} from '@/components/search-profiles/search-profile-form'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { defaultLocale, isLocale } from '@/i18n/routing'
import { requireUser } from '@/server/auth/guards'
import { getEntitlements } from '@/server/entitlements'
import { getConfiguredChannels } from '@/server/search-profiles/channels'
import { getSearchProfile } from '@/server/search-profiles/service'

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string; id: string }>
}): Promise<Metadata> {
  const { locale } = await params
  const t = await getTranslations({ locale, namespace: 'searchProfiles.form' })
  return { title: t('editTitle'), robots: { index: false, follow: false } }
}

/** Turns a nullable number column into the string an input expects. */
function num(value: number | null): string {
  return value === null ? '' : String(value)
}

export default async function EditSearchPage({
  params,
}: {
  params: Promise<{ locale: string; id: string }>
}) {
  const { locale, id } = await params
  setRequestLocale(locale)

  const user = await requireUser(`/searches/${id}`)

  // `getSearchProfile` scopes by userId, so someone else's id is simply not
  // found — the same answer as an id that never existed.
  const profile = await getSearchProfile(user.id, id)
  if (!profile) notFound()

  const t = await getTranslations('searchProfiles.form')
  const entitlements = await getEntitlements(user.id)

  const values: SearchProfileFormValues = {
    id: profile.id,
    name: profile.name,
    isActive: profile.isActive,
    countries: profile.countries,
    provinces: profile.provinces,
    municipalities: profile.municipalities.join(', '),
    postalCodes: profile.postalCodes.join(', '),
    centerLat: profile.centerLat === null ? '' : String(profile.centerLat),
    centerLng: profile.centerLng === null ? '' : String(profile.centerLng),
    radiusKm: num(profile.radiusKm),
    listingType: profile.listingType,
    propertyTypes: profile.propertyTypes,
    minPrice: num(profile.minPrice),
    maxPrice: num(profile.maxPrice),
    minBedrooms: num(profile.minBedrooms),
    minBathrooms: num(profile.minBathrooms),
    minLivingArea: num(profile.minLivingArea),
    maxLivingArea: num(profile.maxLivingArea),
    requirements: {
      requireGarden: profile.requireGarden,
      requireTerrace: profile.requireTerrace,
      requireBalcony: profile.requireBalcony,
      requireParking: profile.requireParking,
      requireGarage: profile.requireGarage,
      requireFurnished: profile.requireFurnished,
      requirePetsAllowed: profile.requirePetsAllowed,
      requireLift: profile.requireLift,
    },
    minEnergyLabel: profile.minEnergyLabel ?? '',
    keywords: profile.keywords.join(', '),
    excludedKeywords: profile.excludedKeywords.join(', '),
    // <input type="date"> only accepts YYYY-MM-DD.
    availableFrom: profile.availableFrom ? profile.availableFrom.toISOString().slice(0, 10) : '',
    minConstructionYear: num(profile.minConstructionYear),
    notificationChannels: profile.notificationChannels,
    notifyOnPriceDrop: profile.notifyOnPriceDrop,
    notifyOnBackAvailable: profile.notifyOnBackAvailable,
    notifyOnAvailabilityChange: profile.notifyOnAvailabilityChange,
  }

  return (
    <div className="mx-auto w-full max-w-2xl px-4 py-8 sm:px-6 sm:py-10">
      <Card>
        <CardHeader>
          <CardTitle>{t('editTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          <SearchProfileForm
            mode="edit"
            values={values}
            locale={isLocale(locale) ? locale : defaultLocale}
            allowedChannels={entitlements.allowedChannels}
            configuredChannels={getConfiguredChannels()}
          />
        </CardContent>
      </Card>
    </div>
  )
}
