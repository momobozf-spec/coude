import type { Metadata } from 'next'
import { MonitorIcon, ShieldCheckIcon } from 'lucide-react'
import { notFound } from 'next/navigation'
import { getFormatter, getTranslations, setRequestLocale } from 'next-intl/server'

import { NotificationPreferencesForm } from '@/components/account/notification-preferences-form'
import { PasswordForm } from '@/components/account/password-form'
import { ProfileForm } from '@/components/account/profile-form'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { revokeOtherSessionsAction, revokeSessionAction } from '@/server/account/actions'
import {
  getAccountProfile,
  getNotificationPreferences,
} from '@/server/account/service'
import { getAuthenticatedContext } from '@/server/auth/guards'
import { listSessions } from '@/server/auth/session-registry'
import { getEntitlements } from '@/server/entitlements'
import { getConfiguredChannels } from '@/server/search-profiles/channels'

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>
}): Promise<Metadata> {
  const { locale } = await params
  const t = await getTranslations({ locale, namespace: 'nav' })
  return { title: t('account'), robots: { index: false, follow: false } }
}

/**
 * Turns a User-Agent string into something a person can recognise.
 *
 * Returns the parts rather than a sentence, so the joining word stays
 * translatable — "Chrome op Windows" is not "Chrome on Windows" with a
 * substitution.
 */
function describeDevice(userAgent: string | null): { browser: string; platform: string } | null {
  if (!userAgent) return null

  const browser = /Edg\//.test(userAgent)
    ? 'Edge'
    : /Chrome\//.test(userAgent) && !/Chromium/.test(userAgent)
      ? 'Chrome'
      : /Firefox\//.test(userAgent)
        ? 'Firefox'
        : /Safari\//.test(userAgent)
          ? 'Safari'
          : 'Browser'

  const platform = /Windows/.test(userAgent)
    ? 'Windows'
    : /Android/.test(userAgent)
      ? 'Android'
      : /iPhone|iPad|iOS/.test(userAgent)
        ? 'iOS'
        : /Mac OS X|Macintosh/.test(userAgent)
          ? 'macOS'
          : /Linux/.test(userAgent)
            ? 'Linux'
            : ''

  return { browser, platform }
}

export default async function AccountPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params
  setRequestLocale(locale)

  const context = await getAuthenticatedContext()
  if (!context) notFound()

  const t = await getTranslations('account')
  const format = await getFormatter()

  const [profile, preferences, sessions, entitlements] = await Promise.all([
    getAccountProfile(context.user.id),
    getNotificationPreferences(context.user.id),
    listSessions(context.user.id, context.sessionId),
    getEntitlements(context.user.id),
  ])

  if (!profile) notFound()

  const configuredChannels = getConfiguredChannels()
  const otherSessions = sessions.filter((session) => !session.isCurrent)

  return (
    <div className="mx-auto w-full max-w-2xl space-y-6 px-4 py-8 sm:px-6 sm:py-10">
      <h1 className="text-2xl font-bold tracking-tight">{t('title')}</h1>

      <Card>
        <CardHeader>
          <CardTitle>{t('profile.title')}</CardTitle>
        </CardHeader>
        <CardContent>
          <ProfileForm
            name={profile.name}
            email={profile.email}
            locale={profile.locale}
            phoneNumber={profile.phoneNumber}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('notifications.title')}</CardTitle>
          <CardDescription>{t('notifications.subtitle')}</CardDescription>
        </CardHeader>
        <CardContent>
          <NotificationPreferencesForm
            values={preferences}
            allowedChannels={entitlements.allowedChannels}
            configuredChannels={configuredChannels}
          />
        </CardContent>
      </Card>

      {profile.hasPassword ? (
        <Card>
          <CardHeader>
            <CardTitle>{t('password.title')}</CardTitle>
          </CardHeader>
          <CardContent>
            <PasswordForm />
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldCheckIcon className="size-4" />
            {t('sessions.title')}
          </CardTitle>
          <CardDescription>{t('sessions.subtitle')}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {sessions.map((session) => {
            const device = describeDevice(session.userAgent)
            const deviceLabel = !device
              ? t('sessions.unknownDevice')
              : device.platform
                ? t('sessions.deviceOn', { browser: device.browser, platform: device.platform })
                : device.browser

            return (
            <div
              key={session.id}
              className="border-border flex flex-wrap items-center justify-between gap-3 rounded-lg border p-3"
            >
              <div className="min-w-0">
                <p className="flex items-center gap-2 text-sm font-medium">
                  <MonitorIcon className="text-muted-foreground size-3.5" aria-hidden="true" />
                  {deviceLabel}
                  {session.isCurrent ? (
                    <Badge variant="success">{t('sessions.current')}</Badge>
                  ) : null}
                </p>
                <p className="text-muted-foreground mt-0.5 text-xs">
                  {session.ipAddress ? `${session.ipAddress} · ` : ''}
                  {format.dateTime(session.createdAt, { dateStyle: 'medium', timeStyle: 'short' })}
                </p>
              </div>

              {!session.isCurrent ? (
                <form action={revokeSessionAction}>
                  <input type="hidden" name="sessionId" value={session.id} />
                  <Button type="submit" variant="ghost" size="sm">
                    {t('sessions.revoke')}
                  </Button>
                </form>
              ) : null}
            </div>
            )
          })}

          {otherSessions.length > 0 ? (
            <form action={revokeOtherSessionsAction}>
              <Button type="submit" variant="outline" size="sm">
                {t('sessions.revokeAll')}
              </Button>
            </form>
          ) : (
            <p className="text-muted-foreground text-sm">{t('sessions.onlyThisDevice')}</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
