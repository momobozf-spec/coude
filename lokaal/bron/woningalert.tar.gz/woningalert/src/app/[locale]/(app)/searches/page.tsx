import type { Metadata } from 'next'
import { CheckCircle2Icon, InfoIcon, PlusIcon, SearchIcon } from 'lucide-react'
import { getTranslations, setRequestLocale } from 'next-intl/server'

import { SearchProfileCard } from '@/components/search-profiles/search-profile-card'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Link } from '@/i18n/navigation'
import { requireUser } from '@/server/auth/guards'
import { getSearchProfileQuota, listSearchProfiles } from '@/server/search-profiles/service'

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>
}): Promise<Metadata> {
  const { locale } = await params
  const t = await getTranslations({ locale, namespace: 'searchProfiles.list' })
  return { title: t('title'), robots: { index: false, follow: false } }
}

export default async function SearchesPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>
  searchParams: Promise<{ created?: string; updated?: string; deleted?: string }>
}) {
  const { locale } = await params
  setRequestLocale(locale)

  const user = await requireUser('/searches')
  const t = await getTranslations('searchProfiles')

  const [profiles, quota, flags] = await Promise.all([
    listSearchProfiles(user.id),
    getSearchProfileQuota(user.id),
    searchParams,
  ])

  const flash = flags.created ? 'created' : flags.updated ? 'updated' : flags.deleted ? 'deleted' : null

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-8 sm:px-6 sm:py-10">
      <header className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t('list.title')}</h1>
          <p className="text-muted-foreground mt-1 text-sm">{t('list.subtitle')}</p>
        </div>

        {quota.canCreate ? (
          <Button asChild>
            <Link href="/searches/new">
              <PlusIcon />
              {t('list.createButton')}
            </Link>
          </Button>
        ) : null}
      </header>

      {flash ? (
        <Alert variant="success" className="mb-6">
          <CheckCircle2Icon />
          <AlertDescription>{t(`messages.${flash}`)}</AlertDescription>
        </Alert>
      ) : null}

      <p className="text-muted-foreground mb-6 text-sm">
        {t('list.quotaUsed', { used: quota.used, limit: quota.limit })}
      </p>

      {!quota.canCreate && profiles.length > 0 ? (
        <Alert className="mb-6">
          <InfoIcon />
          <AlertTitle>{t('list.quotaReached', { limit: quota.limit })}</AlertTitle>
          <AlertDescription>{t('list.upgradeHint')}</AlertDescription>
        </Alert>
      ) : null}

      {profiles.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-4 py-10 text-center">
            <div className="bg-accent text-accent-foreground rounded-full p-3">
              <SearchIcon className="size-6" />
            </div>
            <div>
              <p className="font-medium">{t('list.empty')}</p>
              <p className="text-muted-foreground mx-auto mt-1 max-w-sm text-sm">
                {t('list.emptyBody')}
              </p>
            </div>
            <Button asChild>
              <Link href="/searches/new">
                <PlusIcon />
                {t('list.createButton')}
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {profiles.map((profile) => (
            <SearchProfileCard key={profile.id} profile={profile} />
          ))}
        </div>
      )}
    </div>
  )
}
