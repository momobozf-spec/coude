import { hostname } from 'node:os'
import { randomUUID } from 'node:crypto'

import { env } from '@/lib/env'
import { createLogger } from '@/lib/logger'
import { disconnectPrisma, prisma } from '@/server/db'
import { disconnectRedis, redis, redisKeys } from '@/server/redis'

/**
 * The always-on worker process (REQUIREMENTS §30).
 *
 * Deliberately a plain Node process, not a serverless function: a crawl can run
 * for a minute and a retry can be scheduled ten minutes out, neither of which
 * survives a request lifecycle.
 *
 * Phase 0 wires up the process lifecycle — identity, heartbeat, graceful
 * shutdown. The BullMQ queues and the source scheduler are registered here in
 * phase 3.
 */

const WORKER_ID = `${hostname()}-${process.pid}-${randomUUID().slice(0, 8)}`

const log = createLogger('worker', { workerId: WORKER_ID })

/**
 * Heartbeat interval is half the TTL so a single missed tick — a GC pause, a
 * brief Redis blip — does not make a healthy worker look dead.
 */
const HEARTBEAT_TTL_SECONDS = env.WORKER_HEARTBEAT_TTL_SECONDS
const HEARTBEAT_INTERVAL_MS = Math.floor((HEARTBEAT_TTL_SECONDS * 1000) / 2)

let heartbeatTimer: NodeJS.Timeout | undefined
let shuttingDown = false

async function writeHeartbeat(): Promise<void> {
  try {
    await redis.set(
      redisKeys.workerHeartbeat(WORKER_ID),
      JSON.stringify({ workerId: WORKER_ID, at: new Date().toISOString(), pid: process.pid }),
      'EX',
      HEARTBEAT_TTL_SECONDS,
    )
  } catch (error) {
    log.error({ err: error }, 'Failed to write worker heartbeat')
  }
}

async function verifyDependencies(): Promise<void> {
  await prisma.$queryRaw`SELECT 1`
  log.info('PostgreSQL reachable')

  const pong = await redis.ping()
  if (pong !== 'PONG') throw new Error(`Unexpected Redis PING reply: ${pong}`)
  log.info('Redis reachable')
}

async function shutdown(signal: string): Promise<void> {
  if (shuttingDown) return
  shuttingDown = true

  log.info({ signal }, 'Shutting down worker')

  if (heartbeatTimer) clearInterval(heartbeatTimer)

  try {
    await redis.del(redisKeys.workerHeartbeat(WORKER_ID))
  } catch {
    // The key expires on its own; failing to delete it is not worth blocking on.
  }

  try {
    await disconnectRedis()
    await disconnectPrisma()
  } catch (error) {
    log.error({ err: error }, 'Error during shutdown')
  }

  log.info('Worker stopped')
  process.exit(0)
}

async function main(): Promise<void> {
  log.info(
    { workerId: WORKER_ID, concurrency: env.WORKER_CONCURRENCY, nodeEnv: env.NODE_ENV },
    'Starting WoningAlert worker',
  )

  await verifyDependencies()

  await writeHeartbeat()
  heartbeatTimer = setInterval(() => {
    void writeHeartbeat()
  }, HEARTBEAT_INTERVAL_MS)
  heartbeatTimer.unref()

  log.info({ intervalMs: HEARTBEAT_INTERVAL_MS }, 'Heartbeat started')
  log.warn('No queues registered yet — source polling arrives in phase 3')

  for (const signal of ['SIGINT', 'SIGTERM'] as const) {
    process.on(signal, () => {
      void shutdown(signal)
    })
  }

  process.on('unhandledRejection', (reason) => {
    log.error({ err: reason }, 'Unhandled promise rejection')
  })

  process.on('uncaughtException', (error) => {
    log.fatal({ err: error }, 'Uncaught exception, shutting down')
    void shutdown('uncaughtException')
  })

  // Keep the event loop alive; the heartbeat timer is unref'd on purpose so it
  // alone would not hold the process open.
  await new Promise<void>(() => {})
}

main().catch((error: unknown) => {
  log.fatal({ err: error }, 'Worker failed to start')
  process.exit(1)
})
