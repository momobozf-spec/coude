'use server'

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

import { createLogger } from '@/lib/logger'
import { UnauthorizedError, requireUserOrThrow } from '@/server/auth/guards'
import { EntitlementError } from '@/server/entitlements'

import { searchProfileSchema } from './schemas'
import {
  createSearchProfile,
  deleteSearchProfile,
  setSearchProfileActive,
  updateSearchProfile,
} from './service'

/**
 * Server actions for the search profile forms (REQUIREMENTS §5).
 *
 * Every action re-reads the session itself rather than trusting anything in the
 * form: a server action is a public HTTP endpoint, and a hidden `userId` field
 * would be a straightforward way to edit someone else's profile.
 */

const log = createLogger('search-profile-actions')

export interface SearchProfileFormState {
  status: 'idle' | 'success' | 'error'
  /** Translation key under `searchProfiles.messages`. */
  message?: string
  /** Field name to translation keys under `searchProfiles.fieldErrors`. */
  fieldErrors?: Record<string, string[]>
  /** Extra detail for limit errors, so the message can name the number. */
  limit?: number
}

// ---------------------------------------------------------------------------
// FormData helpers
// ---------------------------------------------------------------------------

/**
 * An unchecked checkbox is absent from FormData; a checked one submits "on".
 * `z.coerce.boolean()` cannot be used directly here because `Boolean("false")`
 * is `true`, which would turn every explicit "false" into a yes.
 */
function readBoolean(formData: FormData, name: string): boolean {
  const value = formData.get(name)
  return value === 'on' || value === 'true'
}

function readStrings(formData: FormData, name: string): string[] {
  return formData
    .getAll(name)
    .filter((value): value is string => typeof value === 'string')
    .map((value) => value.trim())
    .filter((value) => value.length > 0)
}

/**
 * Keywords are typed as free text. People separate them with commas, newlines
 * or semicolons depending on habit, so all three are accepted.
 */
function readKeywords(formData: FormData, name: string): string[] {
  const raw = formData.get(name)
  if (typeof raw !== 'string' || raw.trim() === '') return []

  return [
    ...new Set(
      raw
        .split(/[,;\n]/)
        .map((value) => value.trim())
        .filter((value) => value.length > 0),
    ),
  ]
}

function readString(formData: FormData, name: string): string | undefined {
  const value = formData.get(name)
  if (typeof value !== 'string') return undefined
  const trimmed = value.trim()
  return trimmed === '' ? undefined : trimmed
}

function buildInput(formData: FormData): unknown {
  return {
    name: formData.get('name'),
    isActive: readBoolean(formData, 'isActive'),

    countries: readStrings(formData, 'countries'),
    provinces: readStrings(formData, 'provinces'),
    regions: readStrings(formData, 'regions'),
    municipalities: readKeywords(formData, 'municipalities'),
    postalCodes: readKeywords(formData, 'postalCodes'),

    centerLat: readString(formData, 'centerLat'),
    centerLng: readString(formData, 'centerLng'),
    radiusKm: readString(formData, 'radiusKm'),

    boundsNorth: readString(formData, 'boundsNorth'),
    boundsSouth: readString(formData, 'boundsSouth'),
    boundsEast: readString(formData, 'boundsEast'),
    boundsWest: readString(formData, 'boundsWest'),

    listingType: formData.get('listingType'),
    propertyTypes: readStrings(formData, 'propertyTypes'),

    minPrice: readString(formData, 'minPrice'),
    maxPrice: readString(formData, 'maxPrice'),

    minBedrooms: readString(formData, 'minBedrooms'),
    minBathrooms: readString(formData, 'minBathrooms'),
    minLivingArea: readString(formData, 'minLivingArea'),
    maxLivingArea: readString(formData, 'maxLivingArea'),

    requireGarden: readBoolean(formData, 'requireGarden'),
    requireTerrace: readBoolean(formData, 'requireTerrace'),
    requireBalcony: readBoolean(formData, 'requireBalcony'),
    requireParking: readBoolean(formData, 'requireParking'),
    requireGarage: readBoolean(formData, 'requireGarage'),
    requireFurnished: readBoolean(formData, 'requireFurnished'),
    requirePetsAllowed: readBoolean(formData, 'requirePetsAllowed'),
    requireLift: readBoolean(formData, 'requireLift'),

    minEnergyLabel: readString(formData, 'minEnergyLabel'),

    keywords: readKeywords(formData, 'keywords'),
    excludedKeywords: readKeywords(formData, 'excludedKeywords'),
    availableFrom: readString(formData, 'availableFrom'),
    minConstructionYear: readString(formData, 'minConstructionYear'),

    notificationChannels: readStrings(formData, 'notificationChannels'),
    notifyOnPriceDrop: readBoolean(formData, 'notifyOnPriceDrop'),
    notifyOnBackAvailable: readBoolean(formData, 'notifyOnBackAvailable'),
    notifyOnAvailabilityChange: readBoolean(formData, 'notifyOnAvailabilityChange'),
  }
}

function fieldErrorsFrom(error: {
  issues: ReadonlyArray<{ path: ReadonlyArray<PropertyKey>; message: string }>
}): Record<string, string[]> {
  const result: Record<string, string[]> = {}
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? 'form')
    const bucket = result[key]
    if (bucket) bucket.push(issue.message)
    else result[key] = [issue.message]
  }
  return result
}

function isNextRedirect(error: unknown): boolean {
  return (
    typeof error === 'object' &&
    error !== null &&
    'digest' in error &&
    typeof (error as { digest?: unknown }).digest === 'string' &&
    (error as { digest: string }).digest.startsWith('NEXT_REDIRECT')
  )
}

function handleKnownError(error: unknown): SearchProfileFormState {
  if (error instanceof EntitlementError) {
    return {
      status: 'error',
      message: error.code,
      ...(error.limit !== undefined ? { limit: error.limit } : {}),
    }
  }
  if (error instanceof UnauthorizedError) {
    return { status: 'error', message: 'unauthorized' }
  }
  log.error({ err: error }, 'Search profile action failed')
  return { status: 'error', message: 'unexpectedError' }
}

// ---------------------------------------------------------------------------
// Actions
// ---------------------------------------------------------------------------

export async function createSearchProfileAction(
  _previous: SearchProfileFormState,
  formData: FormData,
): Promise<SearchProfileFormState> {
  try {
    const user = await requireUserOrThrow()

    const parsed = searchProfileSchema.safeParse(buildInput(formData))
    if (!parsed.success) {
      return { status: 'error', fieldErrors: fieldErrorsFrom(parsed.error) }
    }

    await createSearchProfile(user.id, parsed.data)
  } catch (error) {
    if (isNextRedirect(error)) throw error
    return handleKnownError(error)
  }

  revalidatePath('/searches')
  revalidatePath('/dashboard')
  redirect('/searches?created=1')
}

export async function updateSearchProfileAction(
  _previous: SearchProfileFormState,
  formData: FormData,
): Promise<SearchProfileFormState> {
  const id = formData.get('id')
  if (typeof id !== 'string' || id === '') {
    return { status: 'error', message: 'notFound' }
  }

  try {
    const user = await requireUserOrThrow()

    const parsed = searchProfileSchema.safeParse(buildInput(formData))
    if (!parsed.success) {
      return { status: 'error', fieldErrors: fieldErrorsFrom(parsed.error) }
    }

    const result = await updateSearchProfile(user.id, id, parsed.data)
    if (!result.updated) {
      // Same answer for "does not exist" and "not yours", so profile ids cannot
      // be probed.
      return { status: 'error', message: 'notFound' }
    }
  } catch (error) {
    if (isNextRedirect(error)) throw error
    return handleKnownError(error)
  }

  revalidatePath('/searches')
  revalidatePath(`/searches/${id}`)
  revalidatePath('/dashboard')
  redirect('/searches?updated=1')
}

export async function deleteSearchProfileAction(formData: FormData): Promise<void> {
  const id = formData.get('id')
  if (typeof id !== 'string' || id === '') return

  const user = await requireUserOrThrow()
  await deleteSearchProfile(user.id, id)

  revalidatePath('/searches')
  revalidatePath('/dashboard')
  redirect('/searches?deleted=1')
}

export async function toggleSearchProfileAction(formData: FormData): Promise<void> {
  const id = formData.get('id')
  const nextActive = formData.get('isActive') === 'true'

  if (typeof id !== 'string' || id === '') return

  const user = await requireUserOrThrow()
  await setSearchProfileActive(user.id, id, nextActive)

  revalidatePath('/searches')
  revalidatePath('/dashboard')
}
