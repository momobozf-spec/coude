import { z } from 'zod'

import {
  Country,
  EnergyLabel,
  ListingType,
  NotificationChannel,
  PropertyType,
} from '@/generated/prisma/enums'

/**
 * Search profile validation (REQUIREMENTS §5, §24).
 *
 * Every message is a translation key, resolved in the UI. The schema is the
 * only definition of what a valid profile is: the service layer, the server
 * action and the TypeScript types all derive from it, so they cannot drift.
 */

/** Turns "" and null into undefined, so an untouched form field is simply absent. */
const blankToUndefined = (value: unknown) =>
  value === '' || value === null || value === undefined ? undefined : value

const optionalPositiveInt = (max: number) =>
  z.preprocess(blankToUndefined, z.coerce.number().int().min(0).max(max).optional())

/** Prices are whole euros; property listings never quote cents. */
const priceField = optionalPositiveInt(50_000_000)

const areaField = optionalPositiveInt(100_000)

/**
 * Belgian postcodes are four digits. Dutch ones are four digits plus two
 * letters, but people routinely type only the digits when they mean a whole
 * area, so both forms are accepted and normalised to upper case without spaces.
 */
const postalCode = z
  .string()
  .trim()
  .toUpperCase()
  .regex(/^\d{4}\s?[A-Z]{0,2}$/, 'postalCodeInvalid')
  .transform((value) => value.replace(/\s+/g, ''))

const keyword = z.string().trim().min(1).max(40)

const stringList = (max: number) =>
  z
    .array(z.string().trim().min(1).max(80))
    .max(max, 'tooManyValues')
    .default([])
    // The same municipality submitted twice would widen nothing and only slow
    // the matcher down.
    .transform((values) => [...new Set(values)])

export const searchProfileSchema = z
  .object({
    name: z.string().trim().min(1, 'nameRequired').max(80, 'nameTooLong'),
    isActive: z.coerce.boolean().default(true),

    // --- Location ---
    countries: z.array(z.enum(Country)).min(1, 'countryRequired').max(2),
    provinces: stringList(20),
    regions: stringList(20),
    municipalities: stringList(50),
    postalCodes: z.array(postalCode).max(100, 'tooManyValues').default([]),

    centerLat: z.preprocess(blankToUndefined, z.coerce.number().min(-90).max(90).optional()),
    centerLng: z.preprocess(blankToUndefined, z.coerce.number().min(-180).max(180).optional()),
    radiusKm: z.preprocess(blankToUndefined, z.coerce.number().int().min(1).max(200).optional()),

    boundsNorth: z.preprocess(blankToUndefined, z.coerce.number().min(-90).max(90).optional()),
    boundsSouth: z.preprocess(blankToUndefined, z.coerce.number().min(-90).max(90).optional()),
    boundsEast: z.preprocess(blankToUndefined, z.coerce.number().min(-180).max(180).optional()),
    boundsWest: z.preprocess(blankToUndefined, z.coerce.number().min(-180).max(180).optional()),

    // --- Type ---
    listingType: z.enum(ListingType, { message: 'listingTypeRequired' }),
    propertyTypes: z.array(z.enum(PropertyType)).max(7).default([]),

    // --- Budget ---
    minPrice: priceField,
    maxPrice: priceField,

    // --- Features ---
    minBedrooms: optionalPositiveInt(20),
    minBathrooms: optionalPositiveInt(10),
    minLivingArea: areaField,
    maxLivingArea: areaField,

    requireGarden: z.coerce.boolean().default(false),
    requireTerrace: z.coerce.boolean().default(false),
    requireBalcony: z.coerce.boolean().default(false),
    requireParking: z.coerce.boolean().default(false),
    requireGarage: z.coerce.boolean().default(false),
    requireFurnished: z.coerce.boolean().default(false),
    requirePetsAllowed: z.coerce.boolean().default(false),
    requireLift: z.coerce.boolean().default(false),

    minEnergyLabel: z.preprocess(blankToUndefined, z.enum(EnergyLabel).optional()),

    // --- Extra ---
    keywords: z.array(keyword).max(20, 'tooManyValues').default([]),
    excludedKeywords: z.array(keyword).max(20, 'tooManyValues').default([]),
    availableFrom: z.preprocess(
      blankToUndefined,
      z.coerce.date().min(new Date('2000-01-01'), 'dateOutOfRange').optional(),
    ),
    minConstructionYear: z.preprocess(
      blankToUndefined,
      z.coerce.number().int().min(1500).max(new Date().getFullYear() + 10).optional(),
    ),

    // --- Notifications ---
    notificationChannels: z
      .array(z.enum(NotificationChannel))
      .min(1, 'channelRequired')
      .max(4),
    notifyOnPriceDrop: z.coerce.boolean().default(false),
    notifyOnBackAvailable: z.coerce.boolean().default(false),
    notifyOnAvailabilityChange: z.coerce.boolean().default(false),
  })
  .superRefine((data, ctx) => {
    if (data.minPrice !== undefined && data.maxPrice !== undefined && data.minPrice > data.maxPrice) {
      ctx.addIssue({ code: 'custom', message: 'maxPriceBelowMin', path: ['maxPrice'] })
    }

    if (
      data.minLivingArea !== undefined &&
      data.maxLivingArea !== undefined &&
      data.minLivingArea > data.maxLivingArea
    ) {
      ctx.addIssue({ code: 'custom', message: 'maxAreaBelowMin', path: ['maxLivingArea'] })
    }

    // A radius without a centre point matches nothing, and a centre point
    // without a radius is ignored. Both are almost certainly a half-filled form
    // rather than an intention.
    const radiusParts = [data.centerLat, data.centerLng, data.radiusKm]
    const radiusFilled = radiusParts.filter((part) => part !== undefined).length
    if (radiusFilled > 0 && radiusFilled < 3) {
      ctx.addIssue({ code: 'custom', message: 'radiusIncomplete', path: ['radiusKm'] })
    }

    const boundsParts = [data.boundsNorth, data.boundsSouth, data.boundsEast, data.boundsWest]
    const boundsFilled = boundsParts.filter((part) => part !== undefined).length
    if (boundsFilled > 0 && boundsFilled < 4) {
      ctx.addIssue({ code: 'custom', message: 'boundsIncomplete', path: ['boundsNorth'] })
    }

    if (
      data.boundsNorth !== undefined &&
      data.boundsSouth !== undefined &&
      data.boundsNorth <= data.boundsSouth
    ) {
      ctx.addIssue({ code: 'custom', message: 'boundsInverted', path: ['boundsNorth'] })
    }

    // A keyword in both lists can never match: the exclusion always wins, so the
    // profile would silently reject everything the user asked for.
    const overlap = data.keywords.filter((word) =>
      data.excludedKeywords.some((excluded) => excluded.toLowerCase() === word.toLowerCase()),
    )
    if (overlap.length > 0) {
      ctx.addIssue({ code: 'custom', message: 'keywordConflict', path: ['excludedKeywords'] })
    }
  })

export type SearchProfileInput = z.infer<typeof searchProfileSchema>

export const searchProfileIdSchema = z.object({
  id: z.string().min(1, 'idRequired').max(64),
})

export const toggleSearchProfileSchema = z.object({
  id: z.string().min(1, 'idRequired').max(64),
  isActive: z.coerce.boolean(),
})
