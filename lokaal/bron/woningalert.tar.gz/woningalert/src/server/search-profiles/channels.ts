import { NotificationChannel } from '@/generated/prisma/enums'
import { integrations } from '@/lib/env'

/**
 * Which channels have a working provider behind them right now (REQUIREMENTS §39).
 *
 * This is separate from what a *plan* allows: a Premium user may be entitled to
 * SMS while Twilio is not configured. Offering the checkbox in that case would
 * be a promise the system cannot keep, so the UI shows it disabled with the
 * real reason.
 *
 * E-mail is listed even when Resend is missing, because it is the fallback
 * channel every profile needs at least one of — the send itself is then
 * recorded as FAILED rather than silently swallowed.
 */
export function getConfiguredChannels(): NotificationChannel[] {
  const channels: NotificationChannel[] = [NotificationChannel.EMAIL]

  if (integrations.whatsapp) channels.push(NotificationChannel.WHATSAPP)
  if (integrations.sms) channels.push(NotificationChannel.SMS)

  // Web push is not implemented yet (§1 lists it as "if feasible"), so it is
  // never offered.
  return channels
}
