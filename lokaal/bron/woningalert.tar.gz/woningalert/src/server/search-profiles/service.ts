import { createLogger } from '@/lib/logger'
import { prisma } from '@/server/db'
import {
  assertCanCreateSearchProfile,
  assertChannelsAllowed,
  filterAllowedChannels,
  getEntitlements,
  type Entitlements,
} from '@/server/entitlements'

import type { SearchProfileInput } from './schemas'

/**
 * Search profile CRUD (REQUIREMENTS §5, §18).
 *
 * Two rules run through every function here:
 *
 *  1. **Ownership lives in the WHERE clause**, never in an `if` after the
 *     fetch. `where: { id, userId }` cannot be forgotten the way a follow-up
 *     check can, and it makes the "not found" and "not yours" cases identical —
 *     so a stranger cannot probe which profile ids exist.
 *
 *  2. **Entitlements are checked server-side**, on every mutation, against a
 *     count read inside the same call. The UI hiding the button is not part of
 *     the protection.
 */

const log = createLogger('search-profiles')

export interface SearchProfileSummary {
  id: string
  name: string
  isActive: boolean
  listingType: string
  matchCount: number
  lastMatchedAt: Date | null
  createdAt: Date
  notificationChannels: string[]
  municipalities: string[]
  postalCodes: string[]
  countries: string[]
  minPrice: number | null
  maxPrice: number | null
}

export async function listSearchProfiles(userId: string): Promise<SearchProfileSummary[]> {
  const profiles = await prisma.searchProfile.findMany({
    where: { userId },
    orderBy: [{ isActive: 'desc' }, { createdAt: 'desc' }],
    select: {
      id: true,
      name: true,
      isActive: true,
      listingType: true,
      matchCount: true,
      lastMatchedAt: true,
      createdAt: true,
      notificationChannels: true,
      municipalities: true,
      postalCodes: true,
      countries: true,
      minPrice: true,
      maxPrice: true,
    },
  })

  return profiles
}

/** Returns null when the profile does not exist *or* belongs to someone else. */
export async function getSearchProfile(userId: string, id: string) {
  return prisma.searchProfile.findFirst({ where: { id, userId } })
}

export async function countSearchProfiles(userId: string): Promise<number> {
  return prisma.searchProfile.count({ where: { userId } })
}

export interface SearchProfileQuota {
  used: number
  limit: number
  canCreate: boolean
  entitlements: Entitlements
}

export async function getSearchProfileQuota(userId: string): Promise<SearchProfileQuota> {
  const [entitlements, used] = await Promise.all([
    getEntitlements(userId),
    countSearchProfiles(userId),
  ])

  return {
    used,
    limit: entitlements.maxSearchProfiles,
    canCreate: used < entitlements.maxSearchProfiles,
    entitlements,
  }
}

function toPersistable(input: SearchProfileInput) {
  return {
    name: input.name,
    isActive: input.isActive,
    countries: input.countries,
    provinces: input.provinces,
    regions: input.regions,
    municipalities: input.municipalities,
    postalCodes: input.postalCodes,
    centerLat: input.centerLat ?? null,
    centerLng: input.centerLng ?? null,
    radiusKm: input.radiusKm ?? null,
    boundsNorth: input.boundsNorth ?? null,
    boundsSouth: input.boundsSouth ?? null,
    boundsEast: input.boundsEast ?? null,
    boundsWest: input.boundsWest ?? null,
    listingType: input.listingType,
    propertyTypes: input.propertyTypes,
    minPrice: input.minPrice ?? null,
    maxPrice: input.maxPrice ?? null,
    minBedrooms: input.minBedrooms ?? null,
    minBathrooms: input.minBathrooms ?? null,
    minLivingArea: input.minLivingArea ?? null,
    maxLivingArea: input.maxLivingArea ?? null,
    requireGarden: input.requireGarden,
    requireTerrace: input.requireTerrace,
    requireBalcony: input.requireBalcony,
    requireParking: input.requireParking,
    requireGarage: input.requireGarage,
    requireFurnished: input.requireFurnished,
    requirePetsAllowed: input.requirePetsAllowed,
    requireLift: input.requireLift,
    minEnergyLabel: input.minEnergyLabel ?? null,
    keywords: input.keywords,
    excludedKeywords: input.excludedKeywords,
    availableFrom: input.availableFrom ?? null,
    minConstructionYear: input.minConstructionYear ?? null,
    notifyOnPriceDrop: input.notifyOnPriceDrop,
    notifyOnBackAvailable: input.notifyOnBackAvailable,
    notifyOnAvailabilityChange: input.notifyOnAvailabilityChange,
  }
}

export async function createSearchProfile(
  userId: string,
  input: SearchProfileInput,
): Promise<{ id: string }> {
  // Throws EntitlementError when the plan limit is reached.
  await assertCanCreateSearchProfile(userId)
  await assertChannelsAllowed(userId, input.notificationChannels)

  const profile = await prisma.$transaction(async (tx) => {
    const created = await tx.searchProfile.create({
      data: {
        userId,
        ...toPersistable(input),
        notificationChannels: input.notificationChannels,
      },
      select: { id: true },
    })

    await tx.auditLog.create({
      data: {
        actorUserId: userId,
        actorType: 'USER',
        action: 'search_profile.created',
        entityType: 'SearchProfile',
        entityId: created.id,
        changes: { name: input.name, listingType: input.listingType },
      },
    })

    return created
  })

  log.info({ userId, searchProfileId: profile.id }, 'Search profile created')
  return profile
}

export async function updateSearchProfile(
  userId: string,
  id: string,
  input: SearchProfileInput,
): Promise<{ updated: boolean }> {
  // A downgrade can leave a stored channel outside the current plan. Refusing
  // the save would leave the user unable to edit anything, so the selection is
  // narrowed instead and the UI shows what remains.
  const entitlements = await getEntitlements(userId)
  const channels = filterAllowedChannels(input.notificationChannels, entitlements.allowedChannels)

  const result = await prisma.searchProfile.updateMany({
    where: { id, userId },
    data: { ...toPersistable(input), notificationChannels: channels },
  })

  if (result.count === 0) return { updated: false }

  await prisma.auditLog.create({
    data: {
      actorUserId: userId,
      actorType: 'USER',
      action: 'search_profile.updated',
      entityType: 'SearchProfile',
      entityId: id,
      changes: { name: input.name, listingType: input.listingType },
    },
  })

  log.info({ userId, searchProfileId: id }, 'Search profile updated')
  return { updated: true }
}

export async function deleteSearchProfile(
  userId: string,
  id: string,
): Promise<{ deleted: boolean }> {
  const result = await prisma.searchProfile.deleteMany({ where: { id, userId } })

  if (result.count === 0) return { deleted: false }

  await prisma.auditLog.create({
    data: {
      actorUserId: userId,
      actorType: 'USER',
      action: 'search_profile.deleted',
      entityType: 'SearchProfile',
      entityId: id,
    },
  })

  log.info({ userId, searchProfileId: id }, 'Search profile deleted')
  return { deleted: true }
}

export async function setSearchProfileActive(
  userId: string,
  id: string,
  isActive: boolean,
): Promise<{ updated: boolean }> {
  const result = await prisma.searchProfile.updateMany({
    where: { id, userId },
    data: { isActive },
  })

  if (result.count === 0) return { updated: false }

  log.info({ userId, searchProfileId: id, isActive }, 'Search profile toggled')
  return { updated: true }
}
