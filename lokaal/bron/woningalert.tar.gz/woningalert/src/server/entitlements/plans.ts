import { NotificationChannel, SubscriptionPlan } from '@/generated/prisma/enums'

/**
 * Plan definitions (REQUIREMENTS §17, §18).
 *
 * These are the **defaults in code**. The admin can override price, limits and
 * channels per plan in the `PlanConfig` table; `resolvePlans()` merges the two.
 * Having defaults here means a fresh database — or a `PlanConfig` row someone
 * deleted — degrades to a working free tier instead of locking everyone out.
 *
 * Prices are in euro cents. Storing €9.99 as a float and multiplying it by a
 * VAT rate is how you end up invoicing €9.989999999999999.
 */

export interface PlanDefinition {
  plan: SubscriptionPlan
  displayName: string
  /** In cents. 999 = EUR 9,99. */
  priceCents: number
  currency: string
  intervalMonths: number
  maxSearchProfiles: number
  allowedChannels: NotificationChannel[]
  /** Lower sorts earlier in the poll scheduler, so paying users are served first. */
  pollPriority: number
  matchHistoryDays: number
  /** Alert immediately rather than in a batched digest. */
  instantAlerts: boolean
  sortOrder: number
}

export const PLAN_DEFAULTS: Record<SubscriptionPlan, PlanDefinition> = {
  [SubscriptionPlan.FREE]: {
    plan: SubscriptionPlan.FREE,
    displayName: 'Gratis',
    priceCents: 0,
    currency: 'EUR',
    intervalMonths: 0,
    maxSearchProfiles: 1,
    allowedChannels: [NotificationChannel.EMAIL],
    pollPriority: 100,
    matchHistoryDays: 30,
    instantAlerts: false,
    sortOrder: 0,
  },
  [SubscriptionPlan.PREMIUM_MONTHLY]: {
    plan: SubscriptionPlan.PREMIUM_MONTHLY,
    displayName: 'Premium maandelijks',
    priceCents: 999,
    currency: 'EUR',
    intervalMonths: 1,
    maxSearchProfiles: 10,
    allowedChannels: [
      NotificationChannel.EMAIL,
      NotificationChannel.WHATSAPP,
      NotificationChannel.SMS,
    ],
    pollPriority: 10,
    matchHistoryDays: 365,
    instantAlerts: true,
    sortOrder: 1,
  },
  [SubscriptionPlan.PREMIUM_3_MONTH]: {
    plan: SubscriptionPlan.PREMIUM_3_MONTH,
    displayName: 'Premium 3 maanden',
    priceCents: 2500,
    currency: 'EUR',
    intervalMonths: 3,
    maxSearchProfiles: 10,
    allowedChannels: [
      NotificationChannel.EMAIL,
      NotificationChannel.WHATSAPP,
      NotificationChannel.SMS,
    ],
    pollPriority: 10,
    matchHistoryDays: 365,
    instantAlerts: true,
    sortOrder: 2,
  },
}

export const DEFAULT_PLAN: SubscriptionPlan = SubscriptionPlan.FREE

/** Formats cents for display, e.g. 999 -> "9,99". */
export function formatPriceCents(cents: number, locale = 'nl-BE', currency = 'EUR'): string {
  return new Intl.NumberFormat(locale, { style: 'currency', currency }).format(cents / 100)
}

/**
 * Narrows a channel selection to what a plan permits.
 *
 * Used when saving after a downgrade: the stored selection may now exceed the
 * plan, and refusing the save would leave the user unable to edit anything at
 * all. Dropping the extras is the kinder behaviour, and the UI shows what
 * remains.
 *
 * Never returns an empty list. A profile with no channel would match listings
 * and then have no way to tell anyone, which looks exactly like a broken alert.
 */
export function filterAllowedChannels(
  channels: NotificationChannel[],
  allowedChannels: NotificationChannel[],
): NotificationChannel[] {
  const allowed = channels.filter((channel) => allowedChannels.includes(channel))
  return allowed.length > 0 ? allowed : [NotificationChannel.EMAIL]
}
