import {
  NotificationChannel,
  SubscriptionPlan,
  SubscriptionStatus,
} from '@/generated/prisma/enums'
import { createLogger } from '@/lib/logger'
import { prisma } from '@/server/db'

import { DEFAULT_PLAN, PLAN_DEFAULTS, type PlanDefinition } from './plans'

/**
 * Server-side entitlement enforcement (REQUIREMENTS §18).
 *
 * The rule this module exists to enforce: **the UI hides what a user may not
 * do; the server refuses it.** Every mutation that a plan limits calls
 * `assertEntitlement` or one of the specific guards below. A hidden button is
 * presentation, not access control — anyone can post the form anyway.
 */

const log = createLogger('entitlements')

export interface Entitlements {
  plan: SubscriptionPlan
  status: SubscriptionStatus
  maxSearchProfiles: number
  allowedChannels: NotificationChannel[]
  pollPriority: number
  matchHistoryDays: number
  instantAlerts: boolean
  /** True while a paid plan is actually paid for. */
  isPremium: boolean
}

export class EntitlementError extends Error {
  readonly code: EntitlementCode
  readonly limit: number | undefined
  readonly current: number | undefined

  constructor(code: EntitlementCode, options: { limit?: number; current?: number } = {}) {
    super(code)
    this.name = 'EntitlementError'
    this.code = code
    this.limit = options.limit
    this.current = options.current
  }
}

export type EntitlementCode =
  | 'SEARCH_PROFILE_LIMIT_REACHED'
  | 'CHANNEL_NOT_ALLOWED'
  | 'PREMIUM_REQUIRED'

/**
 * Merges the code defaults with any admin overrides in `PlanConfig`.
 *
 * A missing or unreadable `PlanConfig` falls back to the defaults rather than
 * failing: a configuration table that is empty should degrade to a working free
 * tier, not to a site where nobody can do anything.
 */
export async function resolvePlan(plan: SubscriptionPlan): Promise<PlanDefinition> {
  const fallback = PLAN_DEFAULTS[plan]

  try {
    const config = await prisma.planConfig.findUnique({ where: { plan } })
    if (!config || !config.isActive) return fallback

    return {
      plan,
      displayName: config.displayName,
      priceCents: Math.round(Number(config.priceAmount) * 100),
      currency: config.currency,
      intervalMonths: config.intervalMonths,
      maxSearchProfiles: config.maxSearchProfiles,
      allowedChannels:
        config.allowedChannels.length > 0 ? config.allowedChannels : fallback.allowedChannels,
      pollPriority: config.pollPriority,
      matchHistoryDays: config.matchHistoryDays,
      instantAlerts: config.instantAlerts,
      sortOrder: config.sortOrder,
    }
  } catch (error) {
    log.error({ err: error, plan }, 'Could not read PlanConfig, using code defaults')
    return fallback
  }
}

export async function resolveAllPlans(): Promise<PlanDefinition[]> {
  const plans = await Promise.all(
    (Object.keys(PLAN_DEFAULTS) as SubscriptionPlan[]).map((plan) => resolvePlan(plan)),
  )
  return plans.sort((a, b) => a.sortOrder - b.sortOrder)
}

/**
 * The subscription that currently grants access.
 *
 * `PAST_DUE` deliberately still counts as entitled: a failed renewal should not
 * cut someone off mid-search while the payment provider retries. `EXPIRED` and
 * `CANCELLED` do not.
 */
const ENTITLING_STATUSES: SubscriptionStatus[] = [
  SubscriptionStatus.ACTIVE,
  SubscriptionStatus.TRIALING,
  SubscriptionStatus.PAST_DUE,
]

export async function getEntitlements(userId: string): Promise<Entitlements> {
  const subscription = await prisma.subscription.findFirst({
    where: { userId, status: { in: ENTITLING_STATUSES } },
    orderBy: [{ createdAt: 'desc' }],
    select: { plan: true, status: true, currentPeriodEnd: true },
  })

  // No subscription at all, or a paid period that has quietly run out without a
  // webhook arriving: fall back to free rather than keeping premium open.
  const periodExpired =
    subscription?.currentPeriodEnd != null &&
    subscription.currentPeriodEnd.getTime() < Date.now() &&
    subscription.plan !== SubscriptionPlan.FREE

  const effectivePlan = !subscription || periodExpired ? DEFAULT_PLAN : subscription.plan
  const definition = await resolvePlan(effectivePlan)

  return {
    plan: effectivePlan,
    status: subscription?.status ?? SubscriptionStatus.ACTIVE,
    maxSearchProfiles: definition.maxSearchProfiles,
    allowedChannels: definition.allowedChannels,
    pollPriority: definition.pollPriority,
    matchHistoryDays: definition.matchHistoryDays,
    instantAlerts: definition.instantAlerts,
    isPremium: effectivePlan !== SubscriptionPlan.FREE,
  }
}

// ---------------------------------------------------------------------------
// Guards
// ---------------------------------------------------------------------------

/**
 * Throws when the user is already at their search-profile limit.
 *
 * The count is read inside the same call rather than passed in, so a caller
 * cannot accidentally check a stale number.
 */
export async function assertCanCreateSearchProfile(userId: string): Promise<Entitlements> {
  const [entitlements, current] = await Promise.all([
    getEntitlements(userId),
    prisma.searchProfile.count({ where: { userId } }),
  ])

  if (current >= entitlements.maxSearchProfiles) {
    throw new EntitlementError('SEARCH_PROFILE_LIMIT_REACHED', {
      limit: entitlements.maxSearchProfiles,
      current,
    })
  }

  return entitlements
}

/** Throws when a requested notification channel is not in the user's plan. */
export async function assertChannelsAllowed(
  userId: string,
  channels: NotificationChannel[],
): Promise<Entitlements> {
  const entitlements = await getEntitlements(userId)

  const forbidden = channels.filter((channel) => !entitlements.allowedChannels.includes(channel))

  if (forbidden.length > 0) {
    throw new EntitlementError('CHANNEL_NOT_ALLOWED')
  }

  return entitlements
}

export { PLAN_DEFAULTS, type PlanDefinition } from './plans'
export { formatPriceCents, filterAllowedChannels } from './plans'
