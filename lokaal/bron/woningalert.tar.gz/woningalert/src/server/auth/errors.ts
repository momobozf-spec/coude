import { CredentialsSignin } from 'next-auth'

/**
 * Sign-in failure codes.
 *
 * Auth.js collapses every `authorize()` rejection into one generic error unless
 * you subclass `CredentialsSignin` and set a `code`. Without these, a locked
 * account and a typo'd password are indistinguishable to the UI, and the user
 * gets told to check their password while the real problem is a 15-minute
 * lockout.
 */
export type AuthErrorCode =
  | 'INVALID_CREDENTIALS'
  | 'EMAIL_NOT_VERIFIED'
  | 'ACCOUNT_LOCKED'
  | 'RATE_LIMITED'
  | 'OAUTH_ONLY_ACCOUNT'
  | 'ACCOUNT_DELETED'

export class SignInError extends CredentialsSignin {
  override code: AuthErrorCode

  constructor(code: AuthErrorCode) {
    super(code)
    this.code = code
  }
}

/**
 * Deliberately vague towards the user.
 *
 * `INVALID_CREDENTIALS` is returned both for an unknown e-mail address and for
 * a wrong password. Telling them apart would turn the login form into an
 * account-enumeration oracle.
 */
export const GENERIC_SIGN_IN_ERROR: AuthErrorCode = 'INVALID_CREDENTIALS'

const KNOWN_CODES: readonly AuthErrorCode[] = [
  'INVALID_CREDENTIALS',
  'EMAIL_NOT_VERIFIED',
  'ACCOUNT_LOCKED',
  'RATE_LIMITED',
  'OAUTH_ONLY_ACCOUNT',
  'ACCOUNT_DELETED',
]

/** Maps whatever Auth.js threw back to a code the UI can translate. */
export function toAuthErrorCode(error: unknown): AuthErrorCode {
  if (error instanceof SignInError) return error.code

  const candidate = (error as { code?: unknown } | null)?.code
  if (typeof candidate === 'string' && (KNOWN_CODES as readonly string[]).includes(candidate)) {
    return candidate as AuthErrorCode
  }

  return GENERIC_SIGN_IN_ERROR
}
