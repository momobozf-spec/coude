import { randomUUID } from 'node:crypto'

import { NotificationKind, UserRole } from '@/generated/prisma/enums'
import { env } from '@/lib/env'
import { createLogger } from '@/lib/logger'
import {
  accountUrl,
  dashboardUrl,
  notificationPreferencesUrl,
  passwordResetUrl,
  verificationUrl,
} from '@/lib/urls'
import { defaultLocale, isLocale, type Locale } from '@/i18n/routing'
import { prisma } from '@/server/db'
import { resolveEmailLocale } from '@/server/email/i18n'
import { sendEmail } from '@/server/email/send'
import {
  renderPasswordChangedEmail,
  renderPasswordResetEmail,
  renderVerificationEmail,
  renderWelcomeEmail,
} from '@/server/email/templates'

import { hashPassword } from './password'
import {
  EMAIL_VERIFICATION_TTL_MS,
  PASSWORD_RESET_TTL_MS,
  generateToken,
  hashToken,
  isExpired,
} from './tokens'
import { revokeAllSessions } from './session-registry'

/**
 * Account lifecycle (REQUIREMENTS §4).
 *
 * Every function here is written so its result cannot be used to work out
 * whether an e-mail address has an account. Registration, password reset and
 * resend all return the same outcome regardless — the difference is only in
 * which e-mail gets sent, which is visible to the address owner alone.
 */

const log = createLogger('auth-service')

export interface RegisterInput {
  email: string
  password: string
  name?: string
  locale?: string
  acceptedTerms: boolean
  marketingConsent: boolean
  ipAddress?: string | null
}

export type RegisterResult =
  | { status: 'pending-verification' }
  | { status: 'terms-required' }

export async function registerUser(input: RegisterInput): Promise<RegisterResult> {
  if (!input.acceptedTerms) return { status: 'terms-required' }

  const email = input.email.trim().toLowerCase()
  const locale: Locale = input.locale && isLocale(input.locale) ? input.locale : defaultLocale

  const existing = await prisma.user.findUnique({
    where: { email },
    select: { id: true, emailVerified: true, locale: true },
  })

  if (existing) {
    // The address is taken. Rather than say so — which would turn the form into
    // an account-enumeration oracle — the same outcome is returned and the
    // address owner receives a mail explaining what happened.
    if (existing.emailVerified) {
      log.info({ email }, 'Registration attempted for an existing verified account')
      // A verified account already knows how to sign in; sending another
      // verification link would be a way to spam them on request. Nothing is
      // sent, and the UI still says "check your e-mail".
    } else {
      await issueVerificationEmail(existing.id, email, resolveLocale(existing.locale, locale))
    }
    return { status: 'pending-verification' }
  }

  const passwordHash = await hashPassword(input.password)

  // The first account matching ADMIN_BOOTSTRAP_EMAIL becomes admin, so there is
  // a way into the admin UI on a fresh installation without a manual SQL step.
  const isBootstrapAdmin =
    Boolean(env.ADMIN_BOOTSTRAP_EMAIL) &&
    env.ADMIN_BOOTSTRAP_EMAIL!.trim().toLowerCase() === email

  const now = new Date()

  const user = await prisma.$transaction(async (tx) => {
    const created = await tx.user.create({
      data: {
        email,
        passwordHash,
        name: input.name?.trim() || null,
        locale,
        role: isBootstrapAdmin ? UserRole.ADMIN : UserRole.USER,
        termsAcceptedAt: now,
        privacyAcceptedAt: now,
        marketingConsentAt: input.marketingConsent ? now : null,
      },
      select: { id: true },
    })

    // Created in the same transaction so a user can never exist without them.
    await tx.notificationPreference.create({
      data: { userId: created.id, emailEnabled: true, marketingEmailEnabled: input.marketingConsent },
    })

    await tx.subscription.create({
      data: { userId: created.id, plan: 'FREE', status: 'ACTIVE' },
    })

    await tx.auditLog.create({
      data: {
        actorUserId: created.id,
        actorType: 'USER',
        action: 'user.registered',
        entityType: 'User',
        entityId: created.id,
        ipAddress: input.ipAddress ?? null,
      },
    })

    return created
  })

  if (isBootstrapAdmin) {
    log.warn({ email }, 'Registered ADMIN_BOOTSTRAP_EMAIL account with ADMIN role')
  }

  await issueVerificationEmail(user.id, email, locale)

  return { status: 'pending-verification' }
}

// ---------------------------------------------------------------------------
// E-mail verification
// ---------------------------------------------------------------------------

/**
 * Issues a verification token and mails it.
 *
 * Returns the raw token. The token is stored only as a hash, so this is the one
 * moment it exists outside the e-mail — callers that do not need it (every web
 * flow) simply ignore the return value, while tests and future admin tooling
 * have a seam that does not require weakening the hashing.
 */
export async function issueVerificationEmail(
  userId: string,
  email: string,
  locale: Locale,
): Promise<string> {
  const { token, tokenHash, expiresAt } = generateToken(EMAIL_VERIFICATION_TTL_MS)

  // Older unused tokens are dropped: a verification link that was mailed and
  // then superseded should stop working.
  await prisma.$transaction([
    prisma.emailVerificationToken.deleteMany({ where: { userId, usedAt: null } }),
    prisma.emailVerificationToken.create({ data: { userId, email, tokenHash, expiresAt } }),
  ])

  const url = verificationUrl(token, locale)

  await sendEmail({
    userId,
    kind: NotificationKind.ACCOUNT_VERIFICATION,
    to: email,
    locale: resolveEmailLocale(locale),
    rendered: renderVerificationEmail({
      locale: resolveEmailLocale(locale),
      appUrl: env.APP_URL,
      verifyUrl: url,
    }),
    // A nonce, because a user may legitimately request several verification
    // mails. The dedupe guarantee in §12 is about property alerts, not this.
    dedupeKey: `verify:${userId}:${randomUUID()}`,
    previewUrl: url,
  })

  return token
}

export type VerifyEmailResult =
  | { status: 'verified'; locale: Locale }
  | { status: 'already-verified'; locale: Locale }
  | { status: 'invalid' }
  | { status: 'expired' }

export async function verifyEmailToken(token: string): Promise<VerifyEmailResult> {
  const tokenHash = hashToken(token)

  const record = await prisma.emailVerificationToken.findUnique({
    where: { tokenHash },
    select: {
      id: true,
      userId: true,
      email: true,
      expiresAt: true,
      usedAt: true,
      user: { select: { emailVerified: true, locale: true, name: true } },
    },
  })

  if (!record) return { status: 'invalid' }

  const locale = resolveLocale(record.user.locale, defaultLocale)

  if (record.user.emailVerified) return { status: 'already-verified', locale }
  if (record.usedAt) return { status: 'invalid' }
  if (isExpired(record.expiresAt)) return { status: 'expired' }

  await prisma.$transaction([
    prisma.emailVerificationToken.update({
      where: { id: record.id },
      data: { usedAt: new Date() },
    }),
    prisma.user.update({
      where: { id: record.userId },
      data: { emailVerified: new Date() },
    }),
    prisma.auditLog.create({
      data: {
        actorUserId: record.userId,
        actorType: 'USER',
        action: 'user.email_verified',
        entityType: 'User',
        entityId: record.userId,
      },
    }),
  ])

  await sendWelcomeEmail(record.userId, record.email, locale)

  return { status: 'verified', locale }
}

async function sendWelcomeEmail(userId: string, email: string, locale: Locale): Promise<void> {
  // REQUIREMENTS §3: the welcome mail must not promise listings that cannot
  // arrive, so it states plainly when no source is active yet.
  const activeSources = await prisma.propertySource.count({ where: { isEnabled: true } })

  await sendEmail({
    userId,
    kind: NotificationKind.ACCOUNT_WELCOME,
    to: email,
    locale: resolveEmailLocale(locale),
    rendered: renderWelcomeEmail({
      locale: resolveEmailLocale(locale),
      appUrl: env.APP_URL,
      dashboardUrl: dashboardUrl(locale),
      preferencesUrl: notificationPreferencesUrl(locale),
      hasActiveSources: activeSources > 0,
    }),
    dedupeKey: `welcome:${userId}`,
  })
}

export async function resendVerificationEmail(email: string): Promise<void> {
  const normalised = email.trim().toLowerCase()

  const user = await prisma.user.findUnique({
    where: { email: normalised },
    select: { id: true, emailVerified: true, locale: true },
  })

  // Silent when the account does not exist or is already verified: the caller
  // shows the same message either way.
  if (!user || user.emailVerified) return

  await issueVerificationEmail(user.id, normalised, resolveLocale(user.locale, defaultLocale))
}

// ---------------------------------------------------------------------------
// Password reset
// ---------------------------------------------------------------------------

/**
 * Issues a reset token and mails it. Returns the raw token, for the same reason
 * `issueVerificationEmail` does.
 *
 * This is the primitive; `requestPasswordReset` is the public entry point and
 * deliberately returns nothing, so no caller can accidentally turn its result
 * into an answer to "does this address have an account?".
 */
export async function issuePasswordResetToken(
  userId: string,
  email: string,
  locale: Locale,
  ipAddress?: string | null,
): Promise<string> {
  const { token, tokenHash, expiresAt } = generateToken(PASSWORD_RESET_TTL_MS)

  await prisma.$transaction([
    prisma.passwordResetToken.deleteMany({ where: { userId, usedAt: null } }),
    prisma.passwordResetToken.create({
      data: { userId, tokenHash, expiresAt, requestIp: ipAddress ?? null },
    }),
  ])

  const url = passwordResetUrl(token, locale)

  await sendEmail({
    userId,
    kind: NotificationKind.PASSWORD_RESET,
    to: email,
    locale: resolveEmailLocale(locale),
    rendered: renderPasswordResetEmail({
      locale: resolveEmailLocale(locale),
      appUrl: env.APP_URL,
      resetUrl: url,
    }),
    dedupeKey: `reset:${userId}:${randomUUID()}`,
    previewUrl: url,
  })

  return token
}

export async function requestPasswordReset(
  email: string,
  ipAddress?: string | null,
): Promise<void> {
  const normalised = email.trim().toLowerCase()

  const user = await prisma.user.findUnique({
    where: { email: normalised },
    select: { id: true, locale: true, passwordHash: true, deletionRequestedAt: true },
  })

  if (!user || user.deletionRequestedAt) return

  // OAuth-only accounts have no password to reset. Sending a reset link would
  // create one out of thin air for someone who never chose to have one.
  if (!user.passwordHash) {
    log.info({ email: normalised }, 'Password reset requested for an OAuth-only account')
    return
  }

  await issuePasswordResetToken(
    user.id,
    normalised,
    resolveLocale(user.locale, defaultLocale),
    ipAddress,
  )
}

export type ResetPasswordResult =
  | { status: 'reset' }
  | { status: 'invalid' }
  | { status: 'expired' }

export async function resetPassword(
  token: string,
  newPassword: string,
): Promise<ResetPasswordResult> {
  const tokenHash = hashToken(token)

  const record = await prisma.passwordResetToken.findUnique({
    where: { tokenHash },
    select: {
      id: true,
      userId: true,
      expiresAt: true,
      usedAt: true,
      user: { select: { email: true, locale: true } },
    },
  })

  if (!record || record.usedAt) return { status: 'invalid' }
  if (isExpired(record.expiresAt)) return { status: 'expired' }

  const passwordHash = await hashPassword(newPassword)

  await prisma.$transaction([
    prisma.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
    prisma.user.update({
      where: { id: record.userId },
      data: {
        passwordHash,
        // A successful reset also clears a lockout: the person proved control
        // of the mailbox, which is a stronger signal than the failed attempts.
        failedLoginAttempts: 0,
        lockedUntil: null,
        // A password reset is also the recovery path for an unverified account
        // whose owner never clicked the first link.
        emailVerified: new Date(),
      },
    }),
    prisma.auditLog.create({
      data: {
        actorUserId: record.userId,
        actorType: 'USER',
        action: 'user.password_reset',
        entityType: 'User',
        entityId: record.userId,
      },
    }),
  ])

  // Anyone holding a session from before the reset loses it. If the reset was
  // triggered because the account was compromised, this is the step that
  // actually evicts the attacker.
  const revoked = await revokeAllSessions(record.userId)
  log.info({ userId: record.userId, revoked }, 'Password reset, all sessions revoked')

  const locale = resolveLocale(record.user.locale, defaultLocale)

  await sendEmail({
    userId: record.userId,
    kind: NotificationKind.PASSWORD_RESET,
    to: record.user.email,
    locale: resolveEmailLocale(locale),
    rendered: renderPasswordChangedEmail({
      locale: resolveEmailLocale(locale),
      appUrl: env.APP_URL,
      accountUrl: accountUrl(locale),
    }),
    dedupeKey: `password-changed:${record.userId}:${randomUUID()}`,
  })

  return { status: 'reset' }
}

// ---------------------------------------------------------------------------

function resolveLocale(value: string | null | undefined, fallback: Locale): Locale {
  return value && isLocale(value) ? value : fallback
}
