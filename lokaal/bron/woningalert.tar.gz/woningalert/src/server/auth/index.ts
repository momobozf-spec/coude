import NextAuth from 'next-auth'

import { authConfig } from './config'

/**
 * The single Auth.js instance.
 *
 * `auth()` is the server-side session reader used by layouts, server components
 * and server actions. Route protection lives there rather than in `proxy.ts`:
 * the proxy runs on the edge runtime, and pulling bcrypt and Prisma into it
 * would fail to build.
 */
export const { handlers, auth, signIn, signOut } = NextAuth(authConfig)
