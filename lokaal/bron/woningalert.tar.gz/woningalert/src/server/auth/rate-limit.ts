import { createLogger } from '@/lib/logger'
import { redis, redisKeys } from '@/server/redis'

/**
 * Redis-backed rate limiting (REQUIREMENTS §4, §24).
 *
 * A fixed window implemented as INCR plus EXPIRE-on-first-hit, run as one Lua
 * script so the two commands cannot interleave. Doing it in two round trips
 * risks a key that gets incremented but never expires — which silently locks a
 * user out forever once the counter passes the limit.
 *
 * Fixed window over sliding window on purpose: at the burst sizes that matter
 * here (5 logins a minute, not 5000 requests a second) the boundary effect is
 * irrelevant, and the implementation is small enough to be obviously correct.
 */

const log = createLogger('rate-limit')

/**
 * KEYS[1] = counter key, ARGV[1] = window in seconds.
 * Returns { count, ttl }.
 */
const CONSUME_SCRIPT = `
local current = redis.call('INCR', KEYS[1])
if current == 1 then
  redis.call('EXPIRE', KEYS[1], ARGV[1])
end
local ttl = redis.call('TTL', KEYS[1])
return { current, ttl }
`

export interface RateLimitRule {
  /** Identifies the bucket, e.g. "login-ip". */
  bucket: string
  limit: number
  windowSeconds: number
}

export interface RateLimitResult {
  allowed: boolean
  remaining: number
  limit: number
  /** Seconds until the window resets. */
  retryAfterSeconds: number
}

/**
 * Rules live here rather than at call sites so the whole rate-limiting posture
 * of the application is readable in one place.
 */
export const RATE_LIMITS = {
  /** Per IP. Generous enough for a shared office, tight enough to stop scripts. */
  loginByIp: { bucket: 'login-ip', limit: 20, windowSeconds: 300 },
  /** Per e-mail address, regardless of source IP. Stops distributed guessing. */
  loginByEmail: { bucket: 'login-email', limit: 8, windowSeconds: 300 },
  registerByIp: { bucket: 'register-ip', limit: 5, windowSeconds: 3600 },
  passwordResetByIp: { bucket: 'reset-ip', limit: 5, windowSeconds: 3600 },
  passwordResetByEmail: { bucket: 'reset-email', limit: 3, windowSeconds: 3600 },
  verificationResendByEmail: { bucket: 'verify-resend', limit: 3, windowSeconds: 3600 },
} as const satisfies Record<string, RateLimitRule>

export async function consumeRateLimit(
  rule: RateLimitRule,
  identifier: string,
): Promise<RateLimitResult> {
  const key = redisKeys.rateLimit(rule.bucket, identifier)

  try {
    const raw = (await redis.eval(
      CONSUME_SCRIPT,
      1,
      key,
      String(rule.windowSeconds),
    )) as [number, number]

    const count = Number(raw[0])
    const ttl = Number(raw[1])

    return {
      allowed: count <= rule.limit,
      remaining: Math.max(0, rule.limit - count),
      limit: rule.limit,
      retryAfterSeconds: ttl > 0 ? ttl : rule.windowSeconds,
    }
  } catch (error) {
    // Redis being down must not take authentication down with it. Failing open
    // is the deliberate choice: the account-level lockout in the database still
    // applies, so brute force is still bounded even without Redis.
    log.error({ err: error, bucket: rule.bucket }, 'Rate limit check failed, allowing request')
    return {
      allowed: true,
      remaining: rule.limit,
      limit: rule.limit,
      retryAfterSeconds: 0,
    }
  }
}

/** Clears a bucket after a successful action, so one success forgives earlier typos. */
export async function resetRateLimit(rule: RateLimitRule, identifier: string): Promise<void> {
  try {
    await redis.del(redisKeys.rateLimit(rule.bucket, identifier))
  } catch (error) {
    log.warn({ err: error, bucket: rule.bucket }, 'Failed to reset rate limit')
  }
}

// ---------------------------------------------------------------------------
// Account lockout
// ---------------------------------------------------------------------------

/**
 * After this many consecutive failures the account locks. This is the
 * database-backed half of §4's brute-force protection: it survives a Redis
 * restart and follows the account rather than the connection.
 */
export const MAX_FAILED_LOGIN_ATTEMPTS = 10

/**
 * Lockout duration grows with the number of failures, so a user who mistypes
 * twice is not punished like a script that has tried forty times.
 */
export function lockoutDurationMs(failedAttempts: number): number {
  if (failedAttempts < MAX_FAILED_LOGIN_ATTEMPTS) return 0
  const over = failedAttempts - MAX_FAILED_LOGIN_ATTEMPTS
  const minutes = Math.min(15 * 2 ** over, 24 * 60)
  return minutes * 60 * 1000
}
