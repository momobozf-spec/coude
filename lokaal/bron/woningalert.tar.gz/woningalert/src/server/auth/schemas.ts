import { z } from 'zod'

import { locales } from '@/i18n/routing'

import { PASSWORD_MIN_LENGTH } from './password'

/**
 * Input schemas for every auth form (REQUIREMENTS §24: Zod validation on all
 * input). The schema is the single source of truth — the TypeScript types are
 * inferred from it rather than declared alongside, so the two cannot drift.
 *
 * Messages are translation keys, resolved in the UI. Returning Dutch strings
 * from the server would break FR and EN.
 */

const email = z
  .string()
  .trim()
  .min(1, 'emailRequired')
  .max(254, 'emailTooLong')
  .toLowerCase()
  .pipe(z.email({ message: 'emailInvalid' }))

const password = z
  .string()
  .min(PASSWORD_MIN_LENGTH, 'passwordTooShort')
  .max(200, 'passwordTooLong')

/** Login accepts any non-empty password: the policy applies when setting one. */
const loginPassword = z.string().min(1, 'passwordRequired').max(200, 'passwordTooLong')

const localeField = z.enum(locales).optional()

export const registerSchema = z
  .object({
    email,
    password,
    passwordConfirm: z.string(),
    name: z.string().trim().max(120, 'nameTooLong').optional(),
    locale: localeField,
    acceptTerms: z.coerce.boolean().refine((value) => value, { message: 'termsRequired' }),
    marketingConsent: z.coerce.boolean().default(false),
  })
  .refine((data) => data.password === data.passwordConfirm, {
    message: 'passwordsDoNotMatch',
    path: ['passwordConfirm'],
  })

export type RegisterInputSchema = z.infer<typeof registerSchema>

export const loginSchema = z.object({
  email,
  password: loginPassword,
  callbackUrl: z.string().optional(),
})

export type LoginInputSchema = z.infer<typeof loginSchema>

export const forgotPasswordSchema = z.object({
  email,
  locale: localeField,
})

export const resetPasswordSchema = z
  .object({
    token: z.string().min(1, 'tokenRequired'),
    password,
    passwordConfirm: z.string(),
  })
  .refine((data) => data.password === data.passwordConfirm, {
    message: 'passwordsDoNotMatch',
    path: ['passwordConfirm'],
  })

export const resendVerificationSchema = z.object({
  email,
})

/**
 * Only same-origin relative paths are accepted as a post-login destination.
 *
 * Without this check, `/login?callbackUrl=https://evil.example` turns the login
 * form into an open redirect — a phishing primitive that looks like it comes
 * from our own domain.
 */
export function safeCallbackUrl(value: string | null | undefined, fallback = '/dashboard'): string {
  if (!value) return fallback
  if (!value.startsWith('/')) return fallback
  // `//evil.example` is protocol-relative and would leave the site.
  if (value.startsWith('//')) return fallback
  if (value.includes('\\')) return fallback
  return value
}
