import { prisma } from '@/server/db'
import { createLogger } from '@/lib/logger'

import { generateSessionToken } from './tokens'

/**
 * A server-side registry of live sessions.
 *
 * REQUIREMENTS §4 asks for session management: seeing where you are signed in
 * and being able to sign a device out. A pure JWT cannot do that — once issued
 * it is valid until it expires, wherever it is.
 *
 * Auth.js forces the JWT strategy as soon as a Credentials provider is used, so
 * the two are combined: the JWT carries a `sid` that points at a row here, and
 * every session read checks that the row still exists. Revoking is deleting the
 * row, and it takes effect on the next request.
 *
 * The cost is one indexed lookup per session read. That is the price of being
 * able to sign out a stolen laptop, and it is worth paying.
 */

const log = createLogger('session-registry')

export const SESSION_MAX_AGE_SECONDS = 30 * 24 * 60 * 60 // 30 days

export interface SessionContext {
  userAgent?: string | null
  ipAddress?: string | null
}

export async function createSession(userId: string, context: SessionContext = {}): Promise<string> {
  const sessionToken = generateSessionToken()

  await prisma.session.create({
    data: {
      sessionToken,
      userId,
      expires: new Date(Date.now() + SESSION_MAX_AGE_SECONDS * 1000),
      userAgent: truncate(context.userAgent, 400),
      ipAddress: truncate(context.ipAddress, 64),
    },
  })

  return sessionToken
}

/** Returns false when the session was revoked or has expired. */
export async function isSessionValid(sessionToken: string): Promise<boolean> {
  try {
    const session = await prisma.session.findUnique({
      where: { sessionToken },
      select: { expires: true },
    })

    if (!session) return false
    return session.expires.getTime() > Date.now()
  } catch (error) {
    // A database blip must not sign everyone out. Failing open here is safe:
    // the JWT itself is still signed and unexpired, so the worst case is that a
    // revocation takes effect a moment later than intended.
    log.error({ err: error }, 'Session validity check failed, treating session as valid')
    return true
  }
}

export async function revokeSession(sessionToken: string): Promise<void> {
  await prisma.session.deleteMany({ where: { sessionToken } })
}

/** Used after a password change and by "sign out everywhere" (§4). */
export async function revokeAllSessions(
  userId: string,
  options: { exceptSessionToken?: string } = {},
): Promise<number> {
  const result = await prisma.session.deleteMany({
    where: {
      userId,
      ...(options.exceptSessionToken ? { sessionToken: { not: options.exceptSessionToken } } : {}),
    },
  })
  return result.count
}

export interface ListedSession {
  id: string
  isCurrent: boolean
  userAgent: string | null
  ipAddress: string | null
  createdAt: Date
  expires: Date
}

export async function listSessions(
  userId: string,
  currentSessionToken?: string,
): Promise<ListedSession[]> {
  const sessions = await prisma.session.findMany({
    where: { userId, expires: { gt: new Date() } },
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      sessionToken: true,
      userAgent: true,
      ipAddress: true,
      createdAt: true,
      expires: true,
    },
  })

  return sessions.map((session) => ({
    id: session.id,
    isCurrent: currentSessionToken !== undefined && session.sessionToken === currentSessionToken,
    userAgent: session.userAgent,
    ipAddress: session.ipAddress,
    createdAt: session.createdAt,
    expires: session.expires,
  }))
}

/** Deletes one session by row id, but only if it belongs to this user. */
export async function revokeSessionById(userId: string, sessionId: string): Promise<boolean> {
  const result = await prisma.session.deleteMany({ where: { id: sessionId, userId } })
  return result.count > 0
}

/** Housekeeping for the nightly maintenance job. */
export async function deleteExpiredSessions(): Promise<number> {
  const result = await prisma.session.deleteMany({ where: { expires: { lte: new Date() } } })
  return result.count
}

function truncate(value: string | null | undefined, max: number): string | null {
  if (!value) return null
  return value.length > max ? value.slice(0, max) : value
}
