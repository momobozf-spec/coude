import { redirect } from 'next/navigation'

import { UserRole } from '@/generated/prisma/enums'

import { auth } from './index'

/**
 * Session helpers for server components and server actions.
 *
 * Every protected page and every mutating action calls one of these. Hiding a
 * button in the UI is presentation; these functions are the actual access
 * control (REQUIREMENTS §18, §24).
 */

export interface AuthenticatedUser {
  id: string
  email: string
  name: string | null
  image: string | null
  role: UserRole
  locale: string
  emailVerified: boolean
}

export interface AuthenticatedContext {
  user: AuthenticatedUser
  sessionId: string | undefined
}

/** Returns the current user, or null when signed out. Never redirects. */
export async function getCurrentUser(): Promise<AuthenticatedUser | null> {
  const session = await auth()
  if (!session?.user?.id) return null

  return {
    id: session.user.id,
    email: session.user.email,
    name: session.user.name ?? null,
    image: session.user.image ?? null,
    role: session.user.role,
    locale: session.user.locale,
    emailVerified: session.user.isEmailVerified,
  }
}

export async function getAuthenticatedContext(): Promise<AuthenticatedContext | null> {
  const session = await auth()
  if (!session?.user?.id) return null

  return {
    user: {
      id: session.user.id,
      email: session.user.email,
      name: session.user.name ?? null,
      image: session.user.image ?? null,
      role: session.user.role,
      locale: session.user.locale,
      emailVerified: session.user.isEmailVerified,
    },
    sessionId: session.sessionId,
  }
}

/** For pages: sends signed-out visitors to the login form. */
export async function requireUser(returnTo?: string): Promise<AuthenticatedUser> {
  const user = await getCurrentUser()
  if (!user) {
    const target = returnTo ? `/login?callbackUrl=${encodeURIComponent(returnTo)}` : '/login'
    redirect(target)
  }
  return user
}

export async function requireAdmin(): Promise<AuthenticatedUser> {
  const user = await requireUser('/admin')
  if (user.role !== UserRole.ADMIN) {
    // Not a 403 page: an unauthorised visitor should not learn that /admin
    // exists at all.
    redirect('/dashboard')
  }
  return user
}

/**
 * For server actions: throws instead of redirecting, so the caller can return a
 * form error rather than a navigation.
 */
export class UnauthorizedError extends Error {
  constructor(message = 'Not authenticated') {
    super(message)
    this.name = 'UnauthorizedError'
  }
}

export async function requireUserOrThrow(): Promise<AuthenticatedUser> {
  const user = await getCurrentUser()
  if (!user) throw new UnauthorizedError()
  return user
}

export async function requireAdminOrThrow(): Promise<AuthenticatedUser> {
  const user = await requireUserOrThrow()
  if (user.role !== UserRole.ADMIN) throw new UnauthorizedError('Admin role required')
  return user
}
