'use server'

import { headers } from 'next/headers'
import { redirect } from 'next/navigation'

import { createLogger } from '@/lib/logger'
import { defaultLocale, isLocale, type Locale } from '@/i18n/routing'

import { toAuthErrorCode } from './errors'
import { signIn, signOut } from './index'
import { checkPasswordPolicy } from './password'
import { RATE_LIMITS, consumeRateLimit } from './rate-limit'
import {
  forgotPasswordSchema,
  loginSchema,
  registerSchema,
  resendVerificationSchema,
  resetPasswordSchema,
  safeCallbackUrl,
} from './schemas'
import {
  registerUser,
  requestPasswordReset,
  resendVerificationEmail,
  resetPassword,
} from './service'

/**
 * Server actions for the auth forms.
 *
 * Next.js protects server actions against cross-site invocation out of the box,
 * so there is no hand-rolled CSRF token here (REQUIREMENTS §24).
 *
 * Every message is a translation key. The server never returns a display string
 * because it does not reliably know the reader's language at this point.
 */

const log = createLogger('auth-actions')

export interface AuthFormState {
  status: 'idle' | 'success' | 'error'
  /** Translation key under `auth.messages`. */
  message?: string
  /** Field name to translation keys under `auth.fieldErrors`. */
  fieldErrors?: Record<string, string[]>
}

async function requestIp(): Promise<string> {
  try {
    const headerList = await headers()
    const forwarded = headerList.get('x-forwarded-for')
    return forwarded?.split(',')[0]?.trim() ?? headerList.get('x-real-ip') ?? 'unknown'
  } catch {
    return 'unknown'
  }
}

function fieldErrorsFrom(error: {
  issues: ReadonlyArray<{ path: ReadonlyArray<PropertyKey>; message: string }>
}): Record<string, string[]> {
  const result: Record<string, string[]> = {}
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? 'form')
    const bucket = result[key]
    if (bucket) bucket.push(issue.message)
    else result[key] = [issue.message]
  }
  return result
}

function localeFrom(value: FormDataEntryValue | null): Locale {
  const raw = typeof value === 'string' ? value : ''
  return isLocale(raw) ? raw : defaultLocale
}

/**
 * `redirect()` signals navigation by throwing. Catching that as an error would
 * turn every successful login into "something went wrong", so it is detected
 * and rethrown.
 */
function isNextRedirect(error: unknown): boolean {
  return (
    typeof error === 'object' &&
    error !== null &&
    'digest' in error &&
    typeof (error as { digest?: unknown }).digest === 'string' &&
    (error as { digest: string }).digest.startsWith('NEXT_REDIRECT')
  )
}

// ---------------------------------------------------------------------------
// Register
// ---------------------------------------------------------------------------

export async function registerAction(
  _previous: AuthFormState,
  formData: FormData,
): Promise<AuthFormState> {
  const parsed = registerSchema.safeParse({
    email: formData.get('email'),
    password: formData.get('password'),
    passwordConfirm: formData.get('passwordConfirm'),
    name: formData.get('name') ?? undefined,
    locale: formData.get('locale') ?? undefined,
    acceptTerms: formData.get('acceptTerms') === 'on' || formData.get('acceptTerms') === 'true',
    marketingConsent:
      formData.get('marketingConsent') === 'on' || formData.get('marketingConsent') === 'true',
  })

  if (!parsed.success) {
    return { status: 'error', fieldErrors: fieldErrorsFrom(parsed.error) }
  }

  const policy = checkPasswordPolicy(parsed.data.password, { email: parsed.data.email })
  if (!policy.ok) {
    return { status: 'error', fieldErrors: { password: policy.problems } }
  }

  const ip = await requestIp()
  const limit = await consumeRateLimit(RATE_LIMITS.registerByIp, ip)
  if (!limit.allowed) {
    return { status: 'error', message: 'rateLimited' }
  }

  try {
    const result = await registerUser({
      email: parsed.data.email,
      password: parsed.data.password,
      ...(parsed.data.name ? { name: parsed.data.name } : {}),
      ...(parsed.data.locale ? { locale: parsed.data.locale } : {}),
      acceptedTerms: parsed.data.acceptTerms,
      marketingConsent: parsed.data.marketingConsent,
      ipAddress: ip,
    })

    if (result.status === 'terms-required') {
      return { status: 'error', fieldErrors: { acceptTerms: ['termsRequired'] } }
    }

    return { status: 'success', message: 'verificationSent' }
  } catch (error) {
    log.error({ err: error }, 'Registration failed')
    return { status: 'error', message: 'unexpectedError' }
  }
}

// ---------------------------------------------------------------------------
// Login
// ---------------------------------------------------------------------------

export async function loginAction(
  _previous: AuthFormState,
  formData: FormData,
): Promise<AuthFormState> {
  const parsed = loginSchema.safeParse({
    email: formData.get('email'),
    password: formData.get('password'),
    callbackUrl: formData.get('callbackUrl') ?? undefined,
  })

  if (!parsed.success) {
    return { status: 'error', fieldErrors: fieldErrorsFrom(parsed.error) }
  }

  const destination = safeCallbackUrl(parsed.data.callbackUrl)

  try {
    // `redirect: false` keeps control here so a failure renders inside the form
    // instead of bouncing to Auth.js's own error page.
    await signIn('credentials', {
      email: parsed.data.email,
      password: parsed.data.password,
      redirect: false,
    })
  } catch (error) {
    if (isNextRedirect(error)) throw error

    const code = toAuthErrorCode(error)
    log.info({ code, email: parsed.data.email }, 'Sign-in refused')
    return { status: 'error', message: code }
  }

  redirect(destination)
}

// ---------------------------------------------------------------------------
// Logout
// ---------------------------------------------------------------------------

export async function logoutAction(): Promise<void> {
  // The `signOut` event in the auth config deletes the session-registry row, so
  // the token cannot be replayed after this.
  await signOut({ redirectTo: '/' })
}

// ---------------------------------------------------------------------------
// Forgot password
// ---------------------------------------------------------------------------

export async function forgotPasswordAction(
  _previous: AuthFormState,
  formData: FormData,
): Promise<AuthFormState> {
  const parsed = forgotPasswordSchema.safeParse({
    email: formData.get('email'),
    locale: formData.get('locale') ?? undefined,
  })

  if (!parsed.success) {
    return { status: 'error', fieldErrors: fieldErrorsFrom(parsed.error) }
  }

  const ip = await requestIp()

  const [byIp, byEmail] = await Promise.all([
    consumeRateLimit(RATE_LIMITS.passwordResetByIp, ip),
    consumeRateLimit(RATE_LIMITS.passwordResetByEmail, parsed.data.email),
  ])

  // Rate limited: still report success. Saying "too many requests for this
  // address" would confirm the address exists.
  if (byIp.allowed && byEmail.allowed) {
    try {
      await requestPasswordReset(parsed.data.email, ip)
    } catch (error) {
      log.error({ err: error }, 'Password reset request failed')
    }
  }

  return { status: 'success', message: 'resetLinkSent' }
}

// ---------------------------------------------------------------------------
// Reset password
// ---------------------------------------------------------------------------

export async function resetPasswordAction(
  _previous: AuthFormState,
  formData: FormData,
): Promise<AuthFormState> {
  const parsed = resetPasswordSchema.safeParse({
    token: formData.get('token'),
    password: formData.get('password'),
    passwordConfirm: formData.get('passwordConfirm'),
  })

  if (!parsed.success) {
    return { status: 'error', fieldErrors: fieldErrorsFrom(parsed.error) }
  }

  const policy = checkPasswordPolicy(parsed.data.password)
  if (!policy.ok) {
    return { status: 'error', fieldErrors: { password: policy.problems } }
  }

  try {
    const result = await resetPassword(parsed.data.token, parsed.data.password)

    if (result.status === 'expired') return { status: 'error', message: 'resetTokenExpired' }
    if (result.status === 'invalid') return { status: 'error', message: 'resetTokenInvalid' }

    return { status: 'success', message: 'passwordReset' }
  } catch (error) {
    log.error({ err: error }, 'Password reset failed')
    return { status: 'error', message: 'unexpectedError' }
  }
}

// ---------------------------------------------------------------------------
// Resend verification
// ---------------------------------------------------------------------------

export async function resendVerificationAction(
  _previous: AuthFormState,
  formData: FormData,
): Promise<AuthFormState> {
  const parsed = resendVerificationSchema.safeParse({ email: formData.get('email') })

  if (!parsed.success) {
    return { status: 'error', fieldErrors: fieldErrorsFrom(parsed.error) }
  }

  const limit = await consumeRateLimit(RATE_LIMITS.verificationResendByEmail, parsed.data.email)

  if (limit.allowed) {
    try {
      await resendVerificationEmail(parsed.data.email)
    } catch (error) {
      log.error({ err: error }, 'Resending verification failed')
    }
  }

  // Same answer either way, for the same anti-enumeration reason as above.
  return { status: 'success', message: 'verificationSent' }
}

/** Typed reader for the hidden locale field the auth forms submit. */
export async function resolveFormLocale(formData: FormData): Promise<Locale> {
  return localeFrom(formData.get('locale'))
}

// ---------------------------------------------------------------------------
// Google OAuth
// ---------------------------------------------------------------------------

/**
 * Starts the Google flow. Auth.js performs the redirect by throwing, which is
 * why nothing follows this call.
 */
export async function googleSignInAction(formData: FormData): Promise<void> {
  const callbackUrl = formData.get('callbackUrl')
  const destination = safeCallbackUrl(typeof callbackUrl === 'string' ? callbackUrl : null)
  await signIn('google', { redirectTo: destination })
}
