import { PrismaAdapter } from '@auth/prisma-adapter'
import type { NextAuthConfig } from 'next-auth'
import Credentials from 'next-auth/providers/credentials'
import Google from 'next-auth/providers/google'
import { headers } from 'next/headers'
import { z } from 'zod'

import { UserRole } from '@/generated/prisma/enums'
import { env, integrations, isProduction } from '@/lib/env'
import { createLogger } from '@/lib/logger'
import { prisma } from '@/server/db'

import { SignInError } from './errors'
import { DUMMY_PASSWORD_HASH, equalizeTiming, verifyPassword } from './password'
import {
  MAX_FAILED_LOGIN_ATTEMPTS,
  RATE_LIMITS,
  consumeRateLimit,
  lockoutDurationMs,
  resetRateLimit,
} from './rate-limit'
import {
  SESSION_MAX_AGE_SECONDS,
  createSession,
  isSessionValid,
  revokeSession,
} from './session-registry'

const log = createLogger('auth')

const credentialsSchema = z.object({
  email: z.string().trim().toLowerCase().pipe(z.email()),
  password: z.string().min(1).max(200),
})

/**
 * Best-effort request context for the session registry. Auth.js does not pass
 * the request into callbacks, but `headers()` is available inside the route
 * handler that invokes them.
 */
async function readRequestContext(): Promise<{ userAgent: string | null; ipAddress: string | null }> {
  try {
    const headerList = await headers()
    const forwarded = headerList.get('x-forwarded-for')
    return {
      userAgent: headerList.get('user-agent'),
      // The left-most entry is the client; the rest are proxies.
      ipAddress: forwarded?.split(',')[0]?.trim() ?? headerList.get('x-real-ip'),
    }
  } catch {
    return { userAgent: null, ipAddress: null }
  }
}

async function clientIp(): Promise<string> {
  const { ipAddress } = await readRequestContext()
  return ipAddress ?? 'unknown'
}

export const authConfig: NextAuthConfig = {
  adapter: PrismaAdapter(prisma),

  /**
   * JWT rather than database sessions, because Auth.js requires it as soon as a
   * Credentials provider is present. Revocability is restored by the session
   * registry: the token carries a `sid` that is checked on every read.
   */
  session: {
    strategy: 'jwt',
    maxAge: SESSION_MAX_AGE_SECONDS,
  },

  // Behind a proxy the deployment host is not the request host; without this,
  // callback URLs are built wrong on every non-Vercel platform.
  trustHost: true,

  pages: {
    signIn: '/login',
    error: '/login',
    verifyRequest: '/verify-email',
  },

  cookies: {
    sessionToken: {
      name: isProduction ? '__Secure-woningalert.session' : 'woningalert.session',
      options: {
        httpOnly: true,
        sameSite: 'lax',
        path: '/',
        secure: isProduction,
      },
    },
  },

  providers: [
    Credentials({
      id: 'credentials',
      name: 'E-mail',
      credentials: {
        email: { label: 'E-mail', type: 'email' },
        password: { label: 'Wachtwoord', type: 'password' },
      },
      async authorize(rawCredentials) {
        const parsed = credentialsSchema.safeParse(rawCredentials)
        if (!parsed.success) throw new SignInError('INVALID_CREDENTIALS')

        const { email, password } = parsed.data
        const ip = await clientIp()

        const [byIp, byEmail] = await Promise.all([
          consumeRateLimit(RATE_LIMITS.loginByIp, ip),
          consumeRateLimit(RATE_LIMITS.loginByEmail, email),
        ])

        if (!byIp.allowed || !byEmail.allowed) {
          log.warn({ email, ip }, 'Login rate limited')
          throw new SignInError('RATE_LIMITED')
        }

        const user = await prisma.user.findUnique({
          where: { email },
          select: {
            id: true,
            email: true,
            name: true,
            image: true,
            role: true,
            locale: true,
            passwordHash: true,
            emailVerified: true,
            failedLoginAttempts: true,
            lockedUntil: true,
            deletionRequestedAt: true,
          },
        })

        // Unknown address: still pay the bcrypt cost, so response time does not
        // reveal whether the account exists.
        if (!user) {
          await equalizeTiming()
          throw new SignInError('INVALID_CREDENTIALS')
        }

        if (user.deletionRequestedAt) {
          await equalizeTiming()
          throw new SignInError('ACCOUNT_DELETED')
        }

        if (user.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
          await equalizeTiming()
          throw new SignInError('ACCOUNT_LOCKED')
        }

        // Registered through Google only: there is no password to check.
        if (!user.passwordHash) {
          await verifyPassword(password, DUMMY_PASSWORD_HASH)
          throw new SignInError('OAUTH_ONLY_ACCOUNT')
        }

        const passwordMatches = await verifyPassword(password, user.passwordHash)

        if (!passwordMatches) {
          await registerFailedAttempt(user.id, user.failedLoginAttempts)
          throw new SignInError('INVALID_CREDENTIALS')
        }

        if (!user.emailVerified) {
          throw new SignInError('EMAIL_NOT_VERIFIED')
        }

        await prisma.user.update({
          where: { id: user.id },
          data: { failedLoginAttempts: 0, lockedUntil: null, lastLoginAt: new Date() },
        })

        await Promise.all([
          resetRateLimit(RATE_LIMITS.loginByEmail, email),
          resetRateLimit(RATE_LIMITS.loginByIp, ip),
        ])

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          image: user.image,
          role: user.role,
          locale: user.locale,
        }
      },
    }),

    // Only registered when configured, so the UI never shows a Google button
    // that cannot work (§39).
    ...(integrations.googleOAuth
      ? [
          Google({
            clientId: env.GOOGLE_CLIENT_ID!,
            clientSecret: env.GOOGLE_CLIENT_SECRET!,
            /**
             * Links a Google sign-in to an existing password account with the
             * same address. Auth.js calls this "dangerous" because a provider
             * that does not verify e-mail addresses would let an attacker claim
             * someone else's account. The `signIn` callback below therefore
             * rejects any Google profile whose `email_verified` is not true,
             * which removes exactly that risk.
             */
            allowDangerousEmailAccountLinking: true,
            authorization: {
              params: { prompt: 'consent', access_type: 'offline', response_type: 'code' },
            },
          }),
        ]
      : []),
  ],

  callbacks: {
    async signIn({ account, profile }) {
      if (account?.provider === 'google') {
        if (profile?.email_verified !== true) {
          log.warn({ email: profile?.email }, 'Rejected Google sign-in with unverified e-mail')
          return false
        }
      }
      return true
    },

    async jwt({ token, user, trigger }) {
      // Fresh sign-in: register a revocable session and remember who this is.
      if (user?.id) {
        const context = await readRequestContext()
        const sid = await createSession(user.id, context)

        const dbUser = await prisma.user.findUnique({
          where: { id: user.id },
          select: { role: true, locale: true, emailVerified: true },
        })

        token.sid = sid
        token.userId = user.id
        token.role = dbUser?.role ?? UserRole.USER
        token.locale = dbUser?.locale ?? 'nl'
        token.isEmailVerified = Boolean(dbUser?.emailVerified)
        return token
      }

      if (!token.sid) return token

      // Revoked or expired server-side: returning null ends the session.
      if (!(await isSessionValid(token.sid))) {
        return null
      }

      // `update()` from the client asks for fresh claims, e.g. after changing
      // the interface language or verifying an e-mail address.
      if (trigger === 'update' && token.userId) {
        const dbUser = await prisma.user.findUnique({
          where: { id: token.userId },
          select: { role: true, locale: true, emailVerified: true },
        })
        if (dbUser) {
          token.role = dbUser.role
          token.locale = dbUser.locale
          token.isEmailVerified = Boolean(dbUser.emailVerified)
        }
      }

      return token
    },

    async session({ session, token }) {
      // Fields are assigned rather than the object replaced: Auth.js types
      // `session.user` as its own AdapterUser, which carries members we neither
      // set nor need. Overwriting the object wholesale would drop them.
      if (token.userId && session.user) {
        session.user.id = token.userId
        session.user.role = token.role ?? UserRole.USER
        session.user.locale = token.locale ?? 'nl'
        session.user.isEmailVerified = token.isEmailVerified ?? false
      }
      if (token.sid) {
        session.sessionId = token.sid
      }
      return session
    },
  },

  events: {
    async signOut(message) {
      // Delete the registry row so the token cannot be replayed.
      const sid = 'token' in message ? message.token?.sid : undefined
      if (sid) await revokeSession(sid)
    },
  },

  logger: {
    error(error) {
      log.error({ err: error }, 'Auth.js error')
    },
    warn(code) {
      log.warn({ code }, 'Auth.js warning')
    },
  },

  secret: env.AUTH_SECRET,
  debug: false,
}

/**
 * Counts a failed attempt and locks the account once the threshold is passed.
 * This is the durable half of brute-force protection; the Redis limiter is the
 * fast half.
 */
async function registerFailedAttempt(userId: string, currentAttempts: number): Promise<void> {
  const attempts = currentAttempts + 1
  const lockMs = lockoutDurationMs(attempts)

  await prisma.user.update({
    where: { id: userId },
    data: {
      failedLoginAttempts: attempts,
      ...(lockMs > 0 ? { lockedUntil: new Date(Date.now() + lockMs) } : {}),
    },
  })

  if (attempts >= MAX_FAILED_LOGIN_ATTEMPTS) {
    log.warn({ userId, attempts, lockMinutes: lockMs / 60000 }, 'Account locked after failed logins')
  }
}
