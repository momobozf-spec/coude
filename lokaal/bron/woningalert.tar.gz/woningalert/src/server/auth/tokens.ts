import { createHash, randomBytes, timingSafeEqual } from 'node:crypto'

/**
 * One-time tokens for e-mail verification and password reset (REQUIREMENTS §4).
 *
 * The database stores only a SHA-256 hash of the token. Someone with read
 * access to the database therefore cannot verify an account or take one over —
 * they would need the original token, which exists only in the e-mail.
 *
 * SHA-256 rather than bcrypt is correct here, and the reason matters: these
 * tokens are 256 bits of `randomBytes`, not user-chosen. There is nothing to
 * brute-force, so a slow hash would only add latency. Passwords are the
 * opposite case and use bcrypt.
 */

const TOKEN_BYTES = 32

export const EMAIL_VERIFICATION_TTL_MS = 24 * 60 * 60 * 1000 // 24 hours
export const PASSWORD_RESET_TTL_MS = 60 * 60 * 1000 // 1 hour

export interface GeneratedToken {
  /** Goes in the e-mail link. Never stored. */
  token: string
  /** Goes in the database. */
  tokenHash: string
  expiresAt: Date
}

export function generateToken(ttlMs: number): GeneratedToken {
  const token = randomBytes(TOKEN_BYTES).toString('base64url')
  return {
    token,
    tokenHash: hashToken(token),
    expiresAt: new Date(Date.now() + ttlMs),
  }
}

export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex')
}

/**
 * Constant-time comparison of two token hashes.
 *
 * Lookups happen by indexed hash, so this is belt-and-braces — but comparing
 * secrets with `===` is a habit worth not having.
 */
export function tokenHashEquals(a: string, b: string): boolean {
  const bufferA = Buffer.from(a, 'utf8')
  const bufferB = Buffer.from(b, 'utf8')
  if (bufferA.length !== bufferB.length) return false
  return timingSafeEqual(bufferA, bufferB)
}

export function isExpired(expiresAt: Date, now: Date = new Date()): boolean {
  return expiresAt.getTime() <= now.getTime()
}

/** Opaque session token for the server-side session registry. */
export function generateSessionToken(): string {
  return randomBytes(TOKEN_BYTES).toString('base64url')
}
