import bcrypt from 'bcryptjs'

/**
 * Password hashing and policy (REQUIREMENTS §4, §24).
 *
 * bcryptjs rather than argon2 or @node-rs/argon2: those are native modules that
 * need a compiler on every platform the project is built on, including the
 * Alpine container and a Windows dev machine. bcrypt at cost 12 is still the
 * industry baseline for password storage, and a pure-JS implementation removes
 * an entire class of "works on my machine" build failures.
 */

/**
 * Cost 12 is roughly 250 ms on current hardware. High enough to make offline
 * cracking expensive, low enough that a login does not feel slow.
 */
const BCRYPT_COST = 12

/** bcrypt silently truncates at 72 bytes, so longer input is rejected outright. */
const MAX_PASSWORD_BYTES = 72

export const PASSWORD_MIN_LENGTH = 10

export async function hashPassword(plain: string): Promise<string> {
  assertHashable(plain)
  return bcrypt.hash(plain, BCRYPT_COST)
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  if (Buffer.byteLength(plain, 'utf8') > MAX_PASSWORD_BYTES) return false
  return bcrypt.compare(plain, hash)
}

function assertHashable(plain: string): void {
  if (Buffer.byteLength(plain, 'utf8') > MAX_PASSWORD_BYTES) {
    throw new Error(`Password exceeds ${MAX_PASSWORD_BYTES} bytes, which bcrypt would truncate.`)
  }
}

/**
 * A dummy hash used to keep login timing constant for unknown e-mail addresses.
 *
 * Without this, "unknown user" returns in ~1 ms while "wrong password" takes
 * ~250 ms, and that difference alone tells an attacker which addresses have an
 * account. Verifying against this hash makes both paths cost the same.
 *
 * The value is a real bcrypt hash of a random string; nothing can match it.
 */
export const DUMMY_PASSWORD_HASH =
  '$2b$12$bHb0rpFqd42tJCSEgKDu.OkhVBvIAcSCeF309Zx4HFBaHIewWlfum'

export async function equalizeTiming(): Promise<void> {
  await bcrypt.compare('timing-equalizer', DUMMY_PASSWORD_HASH)
}

export interface PasswordPolicyResult {
  ok: boolean
  /** Translation keys, resolved by the caller so messages stay localised. */
  problems: string[]
}

/**
 * Length-first policy.
 *
 * Deliberately no "must contain a symbol" rule: those push people towards
 * `Password1!` and are worse than a long passphrase. Length plus a check
 * against the most obvious choices catches far more real-world weakness.
 */
export function checkPasswordPolicy(password: string, context: { email?: string } = {}): PasswordPolicyResult {
  const problems: string[] = []

  if (password.length < PASSWORD_MIN_LENGTH) {
    problems.push('tooShort')
  }

  if (Buffer.byteLength(password, 'utf8') > MAX_PASSWORD_BYTES) {
    problems.push('tooLong')
  }

  if (/^(.)\1+$/.test(password)) {
    problems.push('repeatedCharacter')
  }

  const lowered = password.toLowerCase()

  if (COMMON_PASSWORDS.has(lowered)) {
    problems.push('tooCommon')
  }

  const localPart = context.email?.split('@')[0]?.toLowerCase()
  if (localPart && localPart.length >= 3 && lowered.includes(localPart)) {
    problems.push('containsEmail')
  }

  return { ok: problems.length === 0, problems }
}

/**
 * The handful of passwords that survive a 10-character minimum and still show
 * up constantly. Not a substitute for a breach corpus, but it costs nothing and
 * catches the obvious cases.
 */
const COMMON_PASSWORDS = new Set([
  'password12',
  'password123',
  'password1234',
  'wachtwoord1',
  'wachtwoord12',
  'wachtwoord123',
  'welkom12345',
  'welcome1234',
  'qwertyuiop',
  '1234567890',
  '0123456789',
  'azertyuiop',
  'motdepasse1',
  'iloveyou123',
  'letmein1234',
  'adminadmin1',
])
