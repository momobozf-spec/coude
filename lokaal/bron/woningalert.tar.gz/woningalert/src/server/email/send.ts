import { Resend } from 'resend'

import { env, integrations, isDevelopment, isProduction } from '@/lib/env'
import { createLogger } from '@/lib/logger'
import { prisma } from '@/server/db'
import { NotificationKind, NotificationStatus } from '@/generated/prisma/enums'

import type { EmailLocale } from './i18n'
import type { RenderedEmail } from './templates'

/**
 * Sending transactional e-mail through Resend (REQUIREMENTS §11, §12).
 *
 * Every send is recorded: a `Notification` row for the outcome and a
 * `NotificationAttempt` row per try. Nothing is ever logged as "sent" that the
 * provider did not accept — §11 is explicit that console.log is not a
 * notification channel.
 */

const log = createLogger('email')

/** Resend rejects requests without a key, so the client is only built when configured. */
let client: Resend | null = null

function getClient(): Resend | null {
  if (!integrations.email) return null
  if (!client) client = new Resend(env.RESEND_API_KEY)
  return client
}

/** Two tries: one retry covers a transient blip without making a user wait. */
const MAX_ATTEMPTS = 2
const RETRY_DELAY_MS = 750

export interface SendEmailInput {
  userId: string
  kind: NotificationKind
  to: string
  locale: EmailLocale
  rendered: RenderedEmail
  /**
   * Guarantees a user is not mailed twice about the same thing (§12). For
   * account mails that legitimately repeat (a second reset request) the caller
   * adds a nonce.
   */
  dedupeKey: string
  searchProfileId?: string
  propertyId?: string
  propertyMatchId?: string
  /** Shown in the development log when e-mail is not configured. */
  previewUrl?: string
}

export type SendEmailResult =
  | { status: 'sent'; notificationId: string; providerMessageId: string | null }
  | { status: 'duplicate'; notificationId: string }
  | { status: 'failed'; notificationId: string; errorCode: string; errorMessage: string }
  | { status: 'not-configured'; notificationId: string }

export async function sendEmail(input: SendEmailInput): Promise<SendEmailResult> {
  const notification = await createNotificationRecord(input)

  if (notification.deduplicated) {
    log.debug({ dedupeKey: input.dedupeKey }, 'Skipping duplicate e-mail')
    return { status: 'duplicate', notificationId: notification.id }
  }

  const resend = getClient()

  if (!resend) {
    return handleUnconfigured(notification.id, input)
  }

  return attemptSend(notification.id, input, resend)
}

// ---------------------------------------------------------------------------

async function createNotificationRecord(
  input: SendEmailInput,
): Promise<{ id: string; deduplicated: boolean }> {
  const existing = await prisma.notification.findUnique({
    where: { dedupeKey: input.dedupeKey },
    select: { id: true },
  })

  if (existing) return { id: existing.id, deduplicated: true }

  try {
    const created = await prisma.notification.create({
      data: {
        userId: input.userId,
        kind: input.kind,
        channel: 'EMAIL',
        status: NotificationStatus.QUEUED,
        recipient: input.to,
        locale: input.locale,
        provider: 'resend',
        subject: input.rendered.subject,
        bodyPreview: input.rendered.text.slice(0, 240),
        dedupeKey: input.dedupeKey,
        ...(input.searchProfileId ? { searchProfileId: input.searchProfileId } : {}),
        ...(input.propertyId ? { propertyId: input.propertyId } : {}),
        ...(input.propertyMatchId ? { propertyMatchId: input.propertyMatchId } : {}),
      },
      select: { id: true },
    })
    return { id: created.id, deduplicated: false }
  } catch (error) {
    // Two concurrent sends raced on the unique dedupeKey. The other one wins;
    // this is the constraint doing exactly what it is there for.
    const existingAfterRace = await prisma.notification.findUnique({
      where: { dedupeKey: input.dedupeKey },
      select: { id: true },
    })
    if (existingAfterRace) return { id: existingAfterRace.id, deduplicated: true }
    throw error
  }
}

/**
 * What happens when RESEND_API_KEY is missing.
 *
 * Production: a hard failure, recorded as FAILED. The account still exists and
 * the user can request a new verification mail once e-mail is configured.
 *
 * Development: the same FAILED record — nothing pretends to have been sent —
 * plus the link written to the log, so a fresh clone can complete a signup
 * without a Resend account. This is a development affordance, not a mock: the
 * database still says the mail failed.
 */
async function handleUnconfigured(
  notificationId: string,
  input: SendEmailInput,
): Promise<SendEmailResult> {
  await prisma.notification.update({
    where: { id: notificationId },
    data: {
      status: NotificationStatus.FAILED,
      failedAt: new Date(),
      errorCode: 'EMAIL_NOT_CONFIGURED',
      errorMessage: 'RESEND_API_KEY and EMAIL_FROM are not set. See INTEGRATIONS.md.',
      attemptCount: 0,
    },
  })

  if (isProduction) {
    log.error(
      { kind: input.kind, notificationId },
      'E-mail not configured in production; message was NOT sent',
    )
  } else {
    log.warn(
      { kind: input.kind, to: input.to, notificationId },
      'E-mail not configured - message was NOT sent. Set RESEND_API_KEY and EMAIL_FROM (see INTEGRATIONS.md).',
    )
    if (isDevelopment && input.previewUrl) {
      log.warn({ url: input.previewUrl }, 'DEVELOPMENT ONLY - open this link manually')
    }
  }

  return { status: 'not-configured', notificationId }
}

async function attemptSend(
  notificationId: string,
  input: SendEmailInput,
  resend: Resend,
): Promise<SendEmailResult> {
  let lastError = { code: 'UNKNOWN', message: 'No attempt was made' }

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
    const startedAt = new Date()

    await prisma.notification.update({
      where: { id: notificationId },
      data: { status: NotificationStatus.SENDING, attemptCount: attempt },
    })

    try {
      const response = await resend.emails.send({
        from: env.EMAIL_FROM!,
        to: input.to,
        subject: input.rendered.subject,
        html: input.rendered.html,
        text: input.rendered.text,
        ...(env.EMAIL_REPLY_TO ? { replyTo: env.EMAIL_REPLY_TO } : {}),
      })

      if (response.error) {
        lastError = { code: response.error.name ?? 'RESEND_ERROR', message: response.error.message }

        await recordAttempt(notificationId, attempt, startedAt, NotificationStatus.FAILED, {
          errorCode: lastError.code,
          errorMessage: lastError.message,
        })

        if (!isRetryable(lastError.code) || attempt === MAX_ATTEMPTS) break
        await delay(RETRY_DELAY_MS * attempt)
        continue
      }

      const providerMessageId = response.data?.id ?? null

      await recordAttempt(notificationId, attempt, startedAt, NotificationStatus.SENT, {
        providerMessageId,
      })

      await prisma.notification.update({
        where: { id: notificationId },
        data: {
          status: NotificationStatus.SENT,
          sentAt: new Date(),
          providerMessageId,
          errorCode: null,
          errorMessage: null,
        },
      })

      log.info({ notificationId, kind: input.kind, providerMessageId }, 'E-mail sent')
      return { status: 'sent', notificationId, providerMessageId }
    } catch (error) {
      lastError = {
        code: 'NETWORK_ERROR',
        message: error instanceof Error ? error.message : String(error),
      }

      await recordAttempt(notificationId, attempt, startedAt, NotificationStatus.FAILED, {
        errorCode: lastError.code,
        errorMessage: lastError.message,
      })

      if (attempt === MAX_ATTEMPTS) break
      await delay(RETRY_DELAY_MS * attempt)
    }
  }

  await prisma.notification.update({
    where: { id: notificationId },
    data: {
      status: NotificationStatus.FAILED,
      failedAt: new Date(),
      errorCode: lastError.code,
      errorMessage: lastError.message.slice(0, 500),
    },
  })

  log.error({ notificationId, kind: input.kind, ...lastError }, 'E-mail failed after all attempts')

  return {
    status: 'failed',
    notificationId,
    errorCode: lastError.code,
    errorMessage: lastError.message,
  }
}

async function recordAttempt(
  notificationId: string,
  attemptNumber: number,
  startedAt: Date,
  status: NotificationStatus,
  extra: { providerMessageId?: string | null; errorCode?: string; errorMessage?: string },
): Promise<void> {
  await prisma.notificationAttempt.create({
    data: {
      notificationId,
      attemptNumber,
      status,
      provider: 'resend',
      startedAt,
      finishedAt: new Date(),
      ...(extra.providerMessageId ? { providerMessageId: extra.providerMessageId } : {}),
      ...(extra.errorCode ? { errorCode: extra.errorCode } : {}),
      ...(extra.errorMessage ? { errorMessage: extra.errorMessage.slice(0, 500) } : {}),
    },
  })
}

/**
 * A rejected address or an unverified domain will be rejected again in 750 ms.
 * Only transient conditions are worth a second try.
 */
function isRetryable(errorCode: string): boolean {
  return ['rate_limit_exceeded', 'internal_server_error', 'application_error', 'NETWORK_ERROR'].includes(
    errorCode,
  )
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}
