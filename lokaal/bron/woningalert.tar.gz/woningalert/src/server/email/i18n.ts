import en from './messages/en.json'
import fr from './messages/fr.json'
import nl from './messages/nl.json'

/**
 * A deliberately tiny translator for e-mail copy.
 *
 * next-intl is not used here on purpose: its server APIs need a Next.js request
 * context, and property alerts are rendered by the standalone worker, which has
 * none. Rather than bend next-intl into a non-Next process, e-mail copy lives in
 * its own bundles with a dozen lines of lookup.
 *
 * The bundles are kept in sync by tests/unit/i18n-messages.test.ts, the same
 * test that guards the UI bundles.
 */

export const emailLocales = ['nl', 'fr', 'en'] as const
export type EmailLocale = (typeof emailLocales)[number]

export const defaultEmailLocale: EmailLocale = 'nl'

type MessageTree = { [key: string]: string | MessageTree }

const bundles: Record<EmailLocale, MessageTree> = { nl, fr, en }

export function resolveEmailLocale(locale: string | null | undefined): EmailLocale {
  if (locale && (emailLocales as readonly string[]).includes(locale)) {
    return locale as EmailLocale
  }
  return defaultEmailLocale
}

/**
 * Looks up `namespace.key` and substitutes `{placeholders}`.
 *
 * Falls back to the default locale before falling back to the key itself, so a
 * missing French string ships as Dutch rather than as `verification.heading`.
 */
export function emailTranslate(
  locale: EmailLocale,
  path: string,
  values: Record<string, string | number> = {},
): string {
  const message = lookup(bundles[locale], path) ?? lookup(bundles[defaultEmailLocale], path)

  if (message === undefined) return path

  return message.replace(/\{(\w+)\}/g, (match, name: string) => {
    const value = values[name]
    return value === undefined ? match : String(value)
  })
}

function lookup(tree: MessageTree, path: string): string | undefined {
  const value = path.split('.').reduce<string | MessageTree | undefined>((node, segment) => {
    if (node === undefined || typeof node === 'string') return undefined
    return node[segment]
  }, tree)

  return typeof value === 'string' ? value : undefined
}

/** Bound translator, so templates read as `t('verification.heading')`. */
export function createEmailTranslator(locale: EmailLocale) {
  return (path: string, values?: Record<string, string | number>): string =>
    emailTranslate(locale, path, values)
}

export const emailBundles = bundles
