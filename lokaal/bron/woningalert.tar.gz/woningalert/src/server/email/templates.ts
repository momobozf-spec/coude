import { createEmailTranslator, type EmailLocale } from './i18n'
import {
  mutedParagraph,
  noticeBox,
  paragraph,
  renderEmailLayout,
  renderEmailText,
} from './layout'

/**
 * Transactional e-mail templates (REQUIREMENTS §26).
 *
 * Each builder returns subject, HTML and plain text together. Keeping the three
 * in one function is what stops them drifting apart — a subject that promises
 * something the body no longer says is the classic failure here.
 */

export interface RenderedEmail {
  subject: string
  html: string
  text: string
}

interface BaseParams {
  locale: EmailLocale
  appUrl: string
}

// ---------------------------------------------------------------------------
// E-mail verification
// ---------------------------------------------------------------------------

export function renderVerificationEmail(
  params: BaseParams & { verifyUrl: string },
): RenderedEmail {
  const t = createEmailTranslator(params.locale)

  const paragraphs = [t('verification.intro'), t('verification.expiry'), t('verification.ignore')]

  return {
    subject: t('verification.subject'),
    html: renderEmailLayout({
      locale: params.locale,
      appUrl: params.appUrl,
      preheader: t('verification.preheader'),
      heading: t('verification.heading'),
      bodyHtml: paragraph(paragraphs[0]!) + mutedParagraph(paragraphs[1]!) + mutedParagraph(paragraphs[2]!),
      cta: { label: t('verification.cta'), url: params.verifyUrl },
      fallbackUrl: params.verifyUrl,
    }),
    text: renderEmailText({
      locale: params.locale,
      heading: t('verification.heading'),
      paragraphs,
      cta: { label: t('verification.cta'), url: params.verifyUrl },
    }),
  }
}

// ---------------------------------------------------------------------------
// Welcome
// ---------------------------------------------------------------------------

export function renderWelcomeEmail(
  params: BaseParams & { dashboardUrl: string; preferencesUrl: string; hasActiveSources: boolean },
): RenderedEmail {
  const t = createEmailTranslator(params.locale)

  // REQUIREMENTS §3: never imply that listings are flowing when no source is
  // configured. The welcome mail says so plainly instead.
  const paragraphs = [t('welcome.intro')]
  let bodyHtml = paragraph(t('welcome.intro'))

  if (!params.hasActiveSources) {
    paragraphs.push(t('welcome.noSourcesNotice'))
    bodyHtml += noticeBox(t('welcome.noSourcesNotice'))
  }

  return {
    subject: t('welcome.subject'),
    html: renderEmailLayout({
      locale: params.locale,
      appUrl: params.appUrl,
      preheader: t('welcome.preheader'),
      heading: t('welcome.heading'),
      bodyHtml,
      cta: { label: t('welcome.cta'), url: params.dashboardUrl },
      preferencesUrl: params.preferencesUrl,
    }),
    text: renderEmailText({
      locale: params.locale,
      heading: t('welcome.heading'),
      paragraphs,
      cta: { label: t('welcome.cta'), url: params.dashboardUrl },
    }),
  }
}

// ---------------------------------------------------------------------------
// Password reset
// ---------------------------------------------------------------------------

export function renderPasswordResetEmail(
  params: BaseParams & { resetUrl: string },
): RenderedEmail {
  const t = createEmailTranslator(params.locale)

  const paragraphs = [
    t('passwordReset.intro'),
    t('passwordReset.expiry'),
    t('passwordReset.ignore'),
  ]

  return {
    subject: t('passwordReset.subject'),
    html: renderEmailLayout({
      locale: params.locale,
      appUrl: params.appUrl,
      preheader: t('passwordReset.preheader'),
      heading: t('passwordReset.heading'),
      bodyHtml:
        paragraph(paragraphs[0]!) + mutedParagraph(paragraphs[1]!) + mutedParagraph(paragraphs[2]!),
      cta: { label: t('passwordReset.cta'), url: params.resetUrl },
      fallbackUrl: params.resetUrl,
      // No preferences link on a security mail: it is one more clickable thing
      // on a page an attacker may have driven the user to.
    }),
    text: renderEmailText({
      locale: params.locale,
      heading: t('passwordReset.heading'),
      paragraphs,
      cta: { label: t('passwordReset.cta'), url: params.resetUrl },
    }),
  }
}

// ---------------------------------------------------------------------------
// Password changed (security notice)
// ---------------------------------------------------------------------------

export function renderPasswordChangedEmail(
  params: BaseParams & { accountUrl: string },
): RenderedEmail {
  const t = createEmailTranslator(params.locale)

  const paragraphs = [t('passwordChanged.intro'), t('passwordChanged.warning')]

  return {
    subject: t('passwordChanged.subject'),
    html: renderEmailLayout({
      locale: params.locale,
      appUrl: params.appUrl,
      preheader: t('passwordChanged.preheader'),
      heading: t('passwordChanged.heading'),
      bodyHtml: paragraph(paragraphs[0]!) + noticeBox(paragraphs[1]!),
      cta: { label: t('passwordChanged.cta'), url: params.accountUrl },
    }),
    text: renderEmailText({
      locale: params.locale,
      heading: t('passwordChanged.heading'),
      paragraphs,
      cta: { label: t('passwordChanged.cta'), url: params.accountUrl },
    }),
  }
}
