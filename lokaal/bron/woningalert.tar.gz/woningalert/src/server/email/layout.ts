import { createEmailTranslator, type EmailLocale } from './i18n'

/**
 * HTML shell for every transactional e-mail.
 *
 * Written as a table-based layout with inline styles because that is what
 * Outlook and Gmail actually render. Flexbox, grid, external stylesheets and
 * `<style>` blocks are unreliable across clients; a table with inline styles is
 * not elegant, but it looks the same everywhere.
 *
 * A React-based e-mail library was considered and skipped: it would add a
 * dependency and a build step to produce the same markup we can write directly,
 * and it would drag React into the worker process.
 */

export interface EmailLayoutOptions {
  locale: EmailLocale
  preheader: string
  heading: string
  /** Already-escaped HTML paragraphs and blocks. */
  bodyHtml: string
  cta?: { label: string; url: string }
  /** Shown small, under the CTA, for people whose client eats buttons. */
  fallbackUrl?: string
  appUrl: string
  /** Link to notification preferences; omitted for security-critical mails. */
  preferencesUrl?: string
}

const BRAND = '#1f6b73'
const TEXT = '#1b2b2e'
const MUTED = '#5c6f72'
const BORDER = '#dfe6e6'
const BACKGROUND = '#f4f7f7'

/** Escapes text destined for HTML. Every interpolated value must go through this. */
export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

export function paragraph(text: string): string {
  return `<p style="margin:0 0 16px;font-size:16px;line-height:1.6;color:${TEXT};">${escapeHtml(text)}</p>`
}

export function mutedParagraph(text: string): string {
  return `<p style="margin:0 0 12px;font-size:14px;line-height:1.6;color:${MUTED};">${escapeHtml(text)}</p>`
}

export function noticeBox(text: string): string {
  return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 20px;">
    <tr><td style="background:#fff7e6;border:1px solid #f0d9a8;border-radius:8px;padding:14px 16px;font-size:14px;line-height:1.6;color:#6b4e0f;">${escapeHtml(text)}</td></tr>
  </table>`
}

export function renderEmailLayout(options: EmailLayoutOptions): string {
  const t = createEmailTranslator(options.locale)

  const cta = options.cta
    ? `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:8px 0 24px;">
        <tr>
          <td style="border-radius:8px;background:${BRAND};">
            <a href="${escapeHtml(options.cta!.url)}"
               style="display:inline-block;padding:14px 28px;font-size:16px;font-weight:600;color:#ffffff;text-decoration:none;border-radius:8px;">
              ${escapeHtml(options.cta!.label)}
            </a>
          </td>
        </tr>
      </table>`
    : ''

  const fallback = options.fallbackUrl
    ? `<p style="margin:0 0 8px;font-size:13px;line-height:1.5;color:${MUTED};">${escapeHtml(t('layout.footerAddressFallback'))}</p>
       <p style="margin:0 0 24px;font-size:13px;line-height:1.5;word-break:break-all;">
         <a href="${escapeHtml(options.fallbackUrl)}" style="color:${BRAND};">${escapeHtml(options.fallbackUrl)}</a>
       </p>`
    : ''

  const preferences = options.preferencesUrl
    ? ` &middot; <a href="${escapeHtml(options.preferencesUrl)}" style="color:${MUTED};text-decoration:underline;">${escapeHtml(t('layout.footerUnsubscribe'))}</a>`
    : ''

  return `<!doctype html>
<html lang="${options.locale}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light">
<title>${escapeHtml(options.heading)}</title>
</head>
<body style="margin:0;padding:0;background:${BACKGROUND};-webkit-font-smoothing:antialiased;">
<div style="display:none;font-size:1px;color:${BACKGROUND};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">${escapeHtml(options.preheader)}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${BACKGROUND};padding:32px 16px;">
  <tr>
    <td align="center">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border:1px solid ${BORDER};border-radius:12px;overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
        <tr>
          <td style="padding:28px 32px 0;">
            <span style="font-size:15px;font-weight:700;letter-spacing:.02em;color:${BRAND};">WoningAlert</span>
          </td>
        </tr>
        <tr>
          <td style="padding:16px 32px 8px;">
            <h1 style="margin:0 0 16px;font-size:22px;line-height:1.3;font-weight:700;color:${TEXT};">${escapeHtml(options.heading)}</h1>
            ${options.bodyHtml}
            ${cta}
            ${fallback}
          </td>
        </tr>
        <tr>
          <td style="padding:8px 32px 28px;border-top:1px solid ${BORDER};">
            <p style="margin:16px 0 4px;font-size:12px;line-height:1.6;color:${MUTED};">
              WoningAlert &middot; ${escapeHtml(t('layout.footerTagline'))}
            </p>
            <p style="margin:0;font-size:12px;line-height:1.6;color:${MUTED};">
              ${escapeHtml(t('layout.footerReason'))}${preferences}
            </p>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>`
}

/**
 * Plain-text alternative.
 *
 * Not optional: a message with only an HTML part scores markedly worse with
 * spam filters, and some clients still render text only.
 */
export function renderEmailText(options: {
  locale: EmailLocale
  heading: string
  paragraphs: string[]
  cta?: { label: string; url: string }
}): string {
  const t = createEmailTranslator(options.locale)
  const lines: string[] = [options.heading, '']

  for (const text of options.paragraphs) {
    lines.push(text, '')
  }

  if (options.cta) {
    lines.push(`${options.cta.label}: ${options.cta.url}`, '')
  }

  lines.push('---', `WoningAlert - ${t('layout.footerTagline')}`, t('layout.footerReason'))

  return lines.join('\n')
}
