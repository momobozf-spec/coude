import Redis, { type RedisOptions } from 'ioredis'

import { env, isDevelopment } from '@/lib/env'
import { createLogger } from '@/lib/logger'

/**
 * Redis connections.
 *
 * Two flavours, because BullMQ and everything else want opposite settings:
 *
 *   - `redis` (shared): used for locks, rate-limit buckets and the worker
 *     heartbeat. It retries a fixed number of times and then fails the command,
 *     so a request cannot hang forever on a dead Redis.
 *   - `createQueueConnection()`: BullMQ requires `maxRetriesPerRequest: null`
 *     and `enableReadyCheck: false` on its blocking connections. Passing the
 *     shared client instead would make BullMQ throw on startup.
 */

const log = createLogger('redis')

const KEY_PREFIX = 'wa:'

const baseOptions: RedisOptions = {
  // Connect on first command, not on import. Next.js imports route modules
  // while collecting page data during `next build`, and an eager connect there
  // would try to reach Redis on a build machine that has none.
  lazyConnect: true,
  enableOfflineQueue: true,
  connectTimeout: 10_000,
  retryStrategy(times) {
    // Exponential with a ceiling; returning null would stop retrying entirely.
    const delay = Math.min(times * 200, 5_000)
    return delay
  },
}

const globalForRedis = globalThis as unknown as {
  redis: Redis | undefined
}

function createSharedClient(): Redis {
  const client = new Redis(env.REDIS_URL, {
    ...baseOptions,
    maxRetriesPerRequest: 3,
    keyPrefix: KEY_PREFIX,
  })

  client.on('error', (error: Error) => {
    log.error({ err: error }, 'Redis connection error')
  })

  return client
}

export const redis: Redis = globalForRedis.redis ?? createSharedClient()

if (isDevelopment) {
  globalForRedis.redis = redis
}

/**
 * A dedicated connection for BullMQ. Every Queue/Worker gets its own, because
 * blocking commands monopolise a connection.
 */
export function createQueueConnection(): Redis {
  const client = new Redis(env.REDIS_URL, {
    ...baseOptions,
    maxRetriesPerRequest: null,
    enableReadyCheck: false,
  })

  client.on('error', (error: Error) => {
    log.error({ err: error }, 'Redis queue connection error')
  })

  return client
}

/** Key helper so prefixes are never hand-written at call sites. */
export const redisKeys = {
  sourceLock: (sourceId: string) => `lock:source:${sourceId}`,
  workerHeartbeat: (workerId: string) => `worker:heartbeat:${workerId}`,
  workerHeartbeatPattern: () => `${KEY_PREFIX}worker:heartbeat:*`,
  rateLimit: (bucket: string, identifier: string) => `ratelimit:${bucket}:${identifier}`,
} as const

export async function disconnectRedis(): Promise<void> {
  await redis.quit()
}
