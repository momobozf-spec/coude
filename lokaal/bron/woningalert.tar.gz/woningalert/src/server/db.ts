import { PrismaPg } from '@prisma/adapter-pg'

import { PrismaClient } from '@/generated/prisma/client'
import { env, isDevelopment } from '@/lib/env'

/**
 * The only place a PrismaClient is constructed.
 *
 * Prisma 7 takes a driver adapter instead of a connection URL in the schema, so
 * the pool is configured here. The client is cached on `globalThis` because
 * Next.js reloads modules on every edit in development; without the cache each
 * save would open a fresh pool and exhaust the database's connection limit
 * within a few minutes.
 */

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

function createPrismaClient(): PrismaClient {
  const adapter = new PrismaPg({ connectionString: env.DATABASE_URL })

  return new PrismaClient({
    adapter,
    log: isDevelopment ? ['warn', 'error'] : ['error'],
  })
}

export const prisma: PrismaClient = globalForPrisma.prisma ?? createPrismaClient()

if (isDevelopment) {
  globalForPrisma.prisma = prisma
}

export async function disconnectPrisma(): Promise<void> {
  await prisma.$disconnect()
}
