'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'

import { NotificationChannel } from '@/generated/prisma/enums'
import { locales } from '@/i18n/routing'
import { createLogger } from '@/lib/logger'
import { getAuthenticatedContext, requireUserOrThrow } from '@/server/auth/guards'
import { checkPasswordPolicy, PASSWORD_MIN_LENGTH } from '@/server/auth/password'
import { revokeAllSessions, revokeSessionById } from '@/server/auth/session-registry'
import { getEntitlements } from '@/server/entitlements'

import {
  changePassword,
  updateNotificationPreferences,
  updateProfile,
} from './service'

/**
 * Account server actions (REQUIREMENTS §4).
 *
 * Every one re-reads the session rather than trusting a user id from the form:
 * a server action is a public endpoint.
 */

const log = createLogger('account-actions')

export interface AccountFormState {
  status: 'idle' | 'success' | 'error'
  /** Translation key under `account.messages`. */
  message?: string
  fieldErrors?: Record<string, string[]>
}

function fieldErrorsFrom(error: {
  issues: ReadonlyArray<{ path: ReadonlyArray<PropertyKey>; message: string }>
}): Record<string, string[]> {
  const result: Record<string, string[]> = {}
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? 'form')
    const bucket = result[key]
    if (bucket) bucket.push(issue.message)
    else result[key] = [issue.message]
  }
  return result
}

function readBoolean(formData: FormData, name: string): boolean {
  const value = formData.get(name)
  return value === 'on' || value === 'true'
}

function readOptionalString(formData: FormData, name: string): string | undefined {
  const value = formData.get(name)
  if (typeof value !== 'string') return undefined
  const trimmed = value.trim()
  return trimmed === '' ? undefined : trimmed
}

// ---------------------------------------------------------------------------
// Profile
// ---------------------------------------------------------------------------

/**
 * E.164 is what Twilio and the WhatsApp Cloud API both require. Accepting
 * "0470 12 34 56" here would only fail later, at send time, where the user
 * cannot see it.
 */
const phoneNumber = z
  .string()
  .trim()
  .regex(/^\+[1-9]\d{7,14}$/, 'phoneInvalid')

const profileSchema = z.object({
  name: z.string().trim().max(120, 'nameTooLong').optional(),
  locale: z.enum(locales),
  phoneNumber: phoneNumber.optional(),
})

export async function updateProfileAction(
  _previous: AccountFormState,
  formData: FormData,
): Promise<AccountFormState> {
  try {
    const user = await requireUserOrThrow()

    const parsed = profileSchema.safeParse({
      name: readOptionalString(formData, 'name'),
      locale: formData.get('locale'),
      phoneNumber: readOptionalString(formData, 'phoneNumber'),
    })

    if (!parsed.success) {
      return { status: 'error', fieldErrors: fieldErrorsFrom(parsed.error) }
    }

    await updateProfile(user.id, {
      name: parsed.data.name ?? null,
      locale: parsed.data.locale,
      phoneNumber: parsed.data.phoneNumber ?? null,
    })
  } catch (error) {
    log.error({ err: error }, 'Profile update failed')
    return { status: 'error', message: 'unexpectedError' }
  }

  revalidatePath('/account')
  return { status: 'success', message: 'profileUpdated' }
}

// ---------------------------------------------------------------------------
// Password
// ---------------------------------------------------------------------------

const passwordSchema = z
  .object({
    currentPassword: z.string().min(1, 'currentPasswordRequired').max(200),
    newPassword: z.string().min(PASSWORD_MIN_LENGTH, 'passwordTooShort').max(200, 'passwordTooLong'),
    newPasswordConfirm: z.string(),
  })
  .refine((data) => data.newPassword === data.newPasswordConfirm, {
    message: 'passwordsDoNotMatch',
    path: ['newPasswordConfirm'],
  })

export async function changePasswordAction(
  _previous: AccountFormState,
  formData: FormData,
): Promise<AccountFormState> {
  try {
    const context = await getAuthenticatedContext()
    if (!context) return { status: 'error', message: 'unauthorized' }

    const parsed = passwordSchema.safeParse({
      currentPassword: formData.get('currentPassword'),
      newPassword: formData.get('newPassword'),
      newPasswordConfirm: formData.get('newPasswordConfirm'),
    })

    if (!parsed.success) {
      return { status: 'error', fieldErrors: fieldErrorsFrom(parsed.error) }
    }

    const policy = checkPasswordPolicy(parsed.data.newPassword, { email: context.user.email })
    if (!policy.ok) {
      return { status: 'error', fieldErrors: { newPassword: policy.problems } }
    }

    const result = await changePassword(
      context.user.id,
      parsed.data.currentPassword,
      parsed.data.newPassword,
      { ...(context.sessionId ? { keepSessionToken: context.sessionId } : {}) },
    )

    if (result.status === 'wrong-password') {
      return { status: 'error', fieldErrors: { currentPassword: ['currentPasswordWrong'] } }
    }
    if (result.status === 'no-password') {
      return { status: 'error', message: 'noPasswordSet' }
    }
  } catch (error) {
    log.error({ err: error }, 'Password change failed')
    return { status: 'error', message: 'unexpectedError' }
  }

  revalidatePath('/account')
  return { status: 'success', message: 'passwordChanged' }
}

// ---------------------------------------------------------------------------
// Notification preferences
// ---------------------------------------------------------------------------

const hourField = z.preprocess(
  (value) => (value === '' || value === null || value === undefined ? undefined : value),
  z.coerce.number().int().min(0).max(23).optional(),
)

const preferencesSchema = z
  .object({
    emailEnabled: z.boolean(),
    whatsappEnabled: z.boolean(),
    smsEnabled: z.boolean(),
    marketingEmailEnabled: z.boolean(),
    quietHoursStart: hourField,
    quietHoursEnd: hourField,
    maxAlertsPerDay: z.preprocess(
      (value) => (value === '' || value === null || value === undefined ? undefined : value),
      z.coerce.number().int().min(1).max(500).optional(),
    ),
    digestMode: z.boolean(),
  })
  .superRefine((data, ctx) => {
    // One without the other is a half-filled form: a start with no end would
    // silence alerts forever.
    const filled = [data.quietHoursStart, data.quietHoursEnd].filter(
      (value) => value !== undefined,
    ).length
    if (filled === 1) {
      ctx.addIssue({ code: 'custom', message: 'quietHoursIncomplete', path: ['quietHoursStart'] })
    }
  })

export async function updateNotificationPreferencesAction(
  _previous: AccountFormState,
  formData: FormData,
): Promise<AccountFormState> {
  try {
    const user = await requireUserOrThrow()

    const parsed = preferencesSchema.safeParse({
      emailEnabled: readBoolean(formData, 'emailEnabled'),
      whatsappEnabled: readBoolean(formData, 'whatsappEnabled'),
      smsEnabled: readBoolean(formData, 'smsEnabled'),
      marketingEmailEnabled: readBoolean(formData, 'marketingEmailEnabled'),
      quietHoursStart: readOptionalString(formData, 'quietHoursStart'),
      quietHoursEnd: readOptionalString(formData, 'quietHoursEnd'),
      maxAlertsPerDay: readOptionalString(formData, 'maxAlertsPerDay'),
      digestMode: readBoolean(formData, 'digestMode'),
    })

    if (!parsed.success) {
      return { status: 'error', fieldErrors: fieldErrorsFrom(parsed.error) }
    }

    const entitlements = await getEntitlements(user.id)

    await updateNotificationPreferences(
      user.id,
      {
        emailEnabled: parsed.data.emailEnabled,
        whatsappEnabled: parsed.data.whatsappEnabled,
        smsEnabled: parsed.data.smsEnabled,
        marketingEmailEnabled: parsed.data.marketingEmailEnabled,
        quietHoursStart: parsed.data.quietHoursStart ?? null,
        quietHoursEnd: parsed.data.quietHoursEnd ?? null,
        maxAlertsPerDay: parsed.data.maxAlertsPerDay ?? null,
        digestMode: parsed.data.digestMode,
      },
      entitlements.allowedChannels as NotificationChannel[],
    )
  } catch (error) {
    log.error({ err: error }, 'Notification preferences update failed')
    return { status: 'error', message: 'unexpectedError' }
  }

  revalidatePath('/account')
  return { status: 'success', message: 'preferencesUpdated' }
}

// ---------------------------------------------------------------------------
// Sessions
// ---------------------------------------------------------------------------

export async function revokeSessionAction(formData: FormData): Promise<void> {
  const sessionId = formData.get('sessionId')
  if (typeof sessionId !== 'string' || sessionId === '') return

  const user = await requireUserOrThrow()
  // Scoped by userId, so one user cannot end another's session.
  await revokeSessionById(user.id, sessionId)

  revalidatePath('/account')
}

export async function revokeOtherSessionsAction(): Promise<void> {
  const context = await getAuthenticatedContext()
  if (!context) return

  const revoked = await revokeAllSessions(context.user.id, {
    ...(context.sessionId ? { exceptSessionToken: context.sessionId } : {}),
  })

  log.info({ userId: context.user.id, revoked }, 'User revoked other sessions')
  revalidatePath('/account')
}
