import { NotificationChannel } from '@/generated/prisma/enums'
import { createLogger } from '@/lib/logger'
import { accountUrl } from '@/lib/urls'
import { defaultLocale, isLocale, type Locale } from '@/i18n/routing'
import { hashPassword, verifyPassword } from '@/server/auth/password'
import { revokeAllSessions } from '@/server/auth/session-registry'
import { prisma } from '@/server/db'
import { env } from '@/lib/env'
import { resolveEmailLocale } from '@/server/email/i18n'
import { sendEmail } from '@/server/email/send'
import { renderPasswordChangedEmail } from '@/server/email/templates'
import { randomUUID } from 'node:crypto'

/**
 * Account self-service (REQUIREMENTS §4, §25).
 */

const log = createLogger('account')

// ---------------------------------------------------------------------------
// Profile
// ---------------------------------------------------------------------------

export interface AccountProfile {
  name: string | null
  email: string
  locale: Locale
  phoneNumber: string | null
  marketingConsent: boolean
  createdAt: Date
  hasPassword: boolean
}

export async function getAccountProfile(userId: string): Promise<AccountProfile | null> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      name: true,
      email: true,
      locale: true,
      phoneNumber: true,
      marketingConsentAt: true,
      createdAt: true,
      passwordHash: true,
    },
  })

  if (!user) return null

  return {
    name: user.name,
    email: user.email,
    locale: isLocale(user.locale) ? user.locale : defaultLocale,
    phoneNumber: user.phoneNumber,
    marketingConsent: user.marketingConsentAt !== null,
    createdAt: user.createdAt,
    // OAuth-only accounts have nothing to change, so the password form is hidden.
    hasPassword: user.passwordHash !== null,
  }
}

export async function updateProfile(
  userId: string,
  input: { name: string | null; locale: Locale; phoneNumber: string | null },
): Promise<void> {
  await prisma.user.update({
    where: { id: userId },
    data: {
      name: input.name,
      locale: input.locale,
      phoneNumber: input.phoneNumber,
      // Changing the number invalidates any earlier verification of it.
      ...(input.phoneNumber === null ? { phoneVerified: null } : {}),
    },
  })

  await prisma.auditLog.create({
    data: {
      actorUserId: userId,
      actorType: 'USER',
      action: 'user.profile_updated',
      entityType: 'User',
      entityId: userId,
    },
  })
}

// ---------------------------------------------------------------------------
// Password
// ---------------------------------------------------------------------------

export type ChangePasswordResult =
  | { status: 'changed' }
  | { status: 'wrong-password' }
  | { status: 'no-password' }

export async function changePassword(
  userId: string,
  currentPassword: string,
  newPassword: string,
  options: { keepSessionToken?: string } = {},
): Promise<ChangePasswordResult> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { passwordHash: true, email: true, locale: true },
  })

  if (!user) return { status: 'wrong-password' }
  if (!user.passwordHash) return { status: 'no-password' }

  if (!(await verifyPassword(currentPassword, user.passwordHash))) {
    return { status: 'wrong-password' }
  }

  await prisma.user.update({
    where: { id: userId },
    data: { passwordHash: await hashPassword(newPassword) },
  })

  // Every other device is signed out. The current session is kept, so changing
  // your password does not bounce you to the login screen on the device you
  // just used.
  const revoked = await revokeAllSessions(userId, {
    ...(options.keepSessionToken ? { exceptSessionToken: options.keepSessionToken } : {}),
  })

  await prisma.auditLog.create({
    data: {
      actorUserId: userId,
      actorType: 'USER',
      action: 'user.password_changed',
      entityType: 'User',
      entityId: userId,
      changes: { revokedSessions: revoked },
    },
  })

  const locale = isLocale(user.locale) ? user.locale : defaultLocale

  await sendEmail({
    userId,
    kind: 'PASSWORD_RESET',
    to: user.email,
    locale: resolveEmailLocale(locale),
    rendered: renderPasswordChangedEmail({
      locale: resolveEmailLocale(locale),
      appUrl: env.APP_URL,
      accountUrl: accountUrl(locale),
    }),
    dedupeKey: `password-changed:${userId}:${randomUUID()}`,
  })

  log.info({ userId, revoked }, 'Password changed, other sessions revoked')
  return { status: 'changed' }
}

// ---------------------------------------------------------------------------
// Notification preferences
// ---------------------------------------------------------------------------

export interface NotificationPreferences {
  emailEnabled: boolean
  whatsappEnabled: boolean
  smsEnabled: boolean
  marketingEmailEnabled: boolean
  quietHoursStart: number | null
  quietHoursEnd: number | null
  maxAlertsPerDay: number | null
  digestMode: boolean
  whatsappOptInAt: Date | null
  smsOptInAt: Date | null
  unsubscribedAllAt: Date | null
}

export async function getNotificationPreferences(
  userId: string,
): Promise<NotificationPreferences> {
  // Created during registration, but an account that predates that (or an OAuth
  // signup handled by the adapter) should still get sane defaults rather than a
  // crash.
  const preference = await prisma.notificationPreference.upsert({
    where: { userId },
    create: { userId },
    update: {},
  })

  return {
    emailEnabled: preference.emailEnabled,
    whatsappEnabled: preference.whatsappEnabled,
    smsEnabled: preference.smsEnabled,
    marketingEmailEnabled: preference.marketingEmailEnabled,
    quietHoursStart: preference.quietHoursStart,
    quietHoursEnd: preference.quietHoursEnd,
    maxAlertsPerDay: preference.maxAlertsPerDay,
    digestMode: preference.digestMode,
    whatsappOptInAt: preference.whatsappOptInAt,
    smsOptInAt: preference.smsOptInAt,
    unsubscribedAllAt: preference.unsubscribedAllAt,
  }
}

export interface NotificationPreferenceInput {
  emailEnabled: boolean
  whatsappEnabled: boolean
  smsEnabled: boolean
  marketingEmailEnabled: boolean
  quietHoursStart: number | null
  quietHoursEnd: number | null
  maxAlertsPerDay: number | null
  digestMode: boolean
}

export async function updateNotificationPreferences(
  userId: string,
  input: NotificationPreferenceInput,
  allowedChannels: NotificationChannel[],
): Promise<void> {
  const existing = await prisma.notificationPreference.findUnique({
    where: { userId },
    select: { whatsappOptInAt: true, smsOptInAt: true, marketingEmailEnabled: true },
  })

  // A plan that does not include a channel cannot have it switched on, whatever
  // the form said (§18).
  const whatsappEnabled =
    input.whatsappEnabled && allowedChannels.includes(NotificationChannel.WHATSAPP)
  const smsEnabled = input.smsEnabled && allowedChannels.includes(NotificationChannel.SMS)

  const now = new Date()

  await prisma.notificationPreference.upsert({
    where: { userId },
    create: {
      userId,
      ...input,
      whatsappEnabled,
      smsEnabled,
      // GDPR §25: the moment of opt-in is the evidence, so it is stamped the
      // first time the channel is switched on and cleared when it is switched
      // off.
      whatsappOptInAt: whatsappEnabled ? now : null,
      smsOptInAt: smsEnabled ? now : null,
    },
    update: {
      ...input,
      whatsappEnabled,
      smsEnabled,
      whatsappOptInAt: whatsappEnabled ? (existing?.whatsappOptInAt ?? now) : null,
      smsOptInAt: smsEnabled ? (existing?.smsOptInAt ?? now) : null,
      unsubscribedAllAt: null,
    },
  })

  // Marketing consent lives on the user as well, because that is where the rest
  // of the consent trail is.
  if (existing && existing.marketingEmailEnabled !== input.marketingEmailEnabled) {
    await prisma.user.update({
      where: { id: userId },
      data: { marketingConsentAt: input.marketingEmailEnabled ? now : null },
    })
  }

  await prisma.auditLog.create({
    data: {
      actorUserId: userId,
      actorType: 'USER',
      action: 'user.notification_preferences_updated',
      entityType: 'NotificationPreference',
      entityId: userId,
    },
  })
}

/** The unsubscribe link in every alert e-mail lands here. */
export async function unsubscribeAll(userId: string): Promise<void> {
  await prisma.notificationPreference.upsert({
    where: { userId },
    create: {
      userId,
      emailEnabled: false,
      whatsappEnabled: false,
      smsEnabled: false,
      marketingEmailEnabled: false,
      unsubscribedAllAt: new Date(),
    },
    update: {
      emailEnabled: false,
      whatsappEnabled: false,
      smsEnabled: false,
      marketingEmailEnabled: false,
      unsubscribedAllAt: new Date(),
    },
  })

  await prisma.user.update({ where: { id: userId }, data: { marketingConsentAt: null } })

  log.info({ userId }, 'User unsubscribed from all notifications')
}
