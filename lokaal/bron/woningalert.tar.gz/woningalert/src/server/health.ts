import { env } from '@/lib/env'
import { createLogger } from '@/lib/logger'

import { prisma } from './db'
import { redis, redisKeys } from './redis'

/**
 * Health checks for /api/health (REQUIREMENTS §21).
 *
 * Every check is independent and time-boxed: one dead dependency must not make
 * the endpoint itself hang, or the load balancer learns nothing. No check ever
 * returns a connection string, credential or stack trace.
 */

export type HealthStatus = 'ok' | 'degraded' | 'down'

export interface ComponentHealth {
  name: string
  status: HealthStatus
  latencyMs: number | null
  detail?: string
}

export interface HealthReport {
  status: HealthStatus
  checkedAt: string
  uptimeSeconds: number
  version: string
  components: ComponentHealth[]
}

const CHECK_TIMEOUT_MS = 5_000

const log = createLogger('health')

async function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  let timer: NodeJS.Timeout | undefined
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => reject(new Error(`timed out after ${ms}ms`)), ms)
      }),
    ])
  } finally {
    if (timer) clearTimeout(timer)
  }
}

async function timed(
  name: string,
  check: () => Promise<string | undefined>,
): Promise<ComponentHealth> {
  const started = performance.now()
  try {
    const detail = await withTimeout(check(), CHECK_TIMEOUT_MS)
    return {
      name,
      status: 'ok',
      latencyMs: Math.round(performance.now() - started),
      ...(detail ? { detail } : {}),
    }
  } catch (error) {
    // The message is logged in full but only a short, non-sensitive summary is
    // returned to the caller.
    log.warn({ err: error, component: name }, 'Health check failed')
    return {
      name,
      status: 'down',
      latencyMs: Math.round(performance.now() - started),
      detail: error instanceof Error ? error.message.slice(0, 120) : 'unknown error',
    }
  }
}

async function checkDatabase(): Promise<string | undefined> {
  await prisma.$queryRaw`SELECT 1`
  return undefined
}

async function checkRedis(): Promise<string | undefined> {
  const pong = await redis.ping()
  if (pong !== 'PONG') throw new Error(`unexpected PING reply: ${pong}`)
  return undefined
}

/**
 * Workers write a heartbeat key with a TTL. If no key survives, either no
 * worker is running or every worker is wedged — both mean no crawling is
 * happening, which is the thing operators actually need to know about.
 */
async function checkWorkers(): Promise<string | undefined> {
  const keys = await redis.keys(redisKeys.workerHeartbeatPattern())
  if (keys.length === 0) {
    throw new Error(
      `no worker heartbeat within ${env.WORKER_HEARTBEAT_TTL_SECONDS}s (is \`npm run worker\` running?)`,
    )
  }
  return `${keys.length} worker(s) alive`
}

function rollUp(components: ComponentHealth[]): HealthStatus {
  if (components.some((component) => component.status === 'down')) return 'down'
  if (components.some((component) => component.status === 'degraded')) return 'degraded'
  return 'ok'
}

export async function getHealthReport(): Promise<HealthReport> {
  const components = await Promise.all([
    timed('database', checkDatabase),
    timed('redis', checkRedis),
    timed('worker', checkWorkers),
  ])

  return {
    status: rollUp(components),
    checkedAt: new Date().toISOString(),
    uptimeSeconds: Math.round(process.uptime()),
    version: process.env.npm_package_version ?? '0.0.0',
    components,
  }
}
