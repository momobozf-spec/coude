import { AsyncLocalStorage } from 'node:async_hooks'
import { randomUUID } from 'node:crypto'
import pino, { type Logger } from 'pino'

import { env, isDevelopment, isTest } from './env'

/**
 * Structured logging with correlation IDs (REQUIREMENTS §21).
 *
 * Redaction is configured here, once, rather than at every call site. A field
 * that is never allowed to reach the logs cannot be leaked by someone forgetting
 * to strip it before logging.
 */

const REDACTED_PATHS = [
  'password',
  'passwordHash',
  'token',
  'accessToken',
  'refreshToken',
  'apiKey',
  'secret',
  'authorization',
  'cookie',
  '*.password',
  '*.passwordHash',
  '*.token',
  '*.accessToken',
  '*.refreshToken',
  '*.apiKey',
  '*.secret',
  '*.authorization',
  '*.cookie',
  'req.headers.authorization',
  'req.headers.cookie',
  'headers.authorization',
  'headers.cookie',
]

export interface RequestContext {
  correlationId: string
  userId?: string
  route?: string
}

const contextStorage = new AsyncLocalStorage<RequestContext>()

const baseLogger: Logger = pino({
  level: isTest ? 'silent' : env.LOG_LEVEL,
  redact: { paths: REDACTED_PATHS, censor: '[redacted]' },
  base: { service: 'woningalert', env: env.NODE_ENV },
  timestamp: pino.stdTimeFunctions.isoTime,
  formatters: {
    level: (label) => ({ level: label }),
  },
  // Pretty output locally; newline-delimited JSON everywhere else so log
  // aggregators can parse it.
  ...(isDevelopment
    ? {
        transport: {
          target: 'pino-pretty',
          options: { colorize: true, translateTime: 'HH:MM:ss.l', ignore: 'pid,hostname,service,env' },
        },
      }
    : {}),
  mixin() {
    const ctx = contextStorage.getStore()
    if (!ctx) return {}
    return {
      correlationId: ctx.correlationId,
      ...(ctx.userId ? { userId: ctx.userId } : {}),
      ...(ctx.route ? { route: ctx.route } : {}),
    }
  },
})

export const logger = baseLogger

/** Child logger tagged with a component name, e.g. `worker:source-poll`. */
export function createLogger(component: string, bindings: Record<string, unknown> = {}): Logger {
  return baseLogger.child({ component, ...bindings })
}

/** Runs `fn` with a correlation context that every log line inside inherits. */
export function withRequestContext<T>(
  context: Partial<RequestContext> & { correlationId?: string },
  fn: () => T,
): T {
  return contextStorage.run(
    {
      correlationId: context.correlationId ?? randomUUID(),
      ...(context.userId !== undefined ? { userId: context.userId } : {}),
      ...(context.route !== undefined ? { route: context.route } : {}),
    },
    fn,
  )
}

export function getCorrelationId(): string | undefined {
  return contextStorage.getStore()?.correlationId
}

export function newCorrelationId(): string {
  return randomUUID()
}
