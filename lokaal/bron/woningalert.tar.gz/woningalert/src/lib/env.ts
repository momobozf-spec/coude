import { z } from 'zod'

/**
 * Server-side environment configuration.
 *
 * This module is imported by both the Next.js server and the standalone worker,
 * so it deliberately does NOT import `server-only`: that package throws outside
 * a React server context and would break `npm run worker`.
 *
 * Validation runs once at module load. A missing required variable is a boot
 * failure, not a runtime surprise three hours into a crawl.
 */

const optionalString = z
  .string()
  .trim()
  .min(1)
  .optional()
  .catch(undefined)

/** Treats an empty env var the same as an unset one. */
const emptyToUndefined = (value: unknown) =>
  typeof value === 'string' && value.trim() === '' ? undefined : value

const schema = z.object({
  // --- Core -----------------------------------------------------------------
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  APP_URL: z.preprocess(emptyToUndefined, z.url().default('http://localhost:3000')),
  PORT: z.preprocess(emptyToUndefined, z.coerce.number().int().positive().default(3000)),

  // --- Data stores ----------------------------------------------------------
  DATABASE_URL: z.string().trim().min(1, 'DATABASE_URL is required'),
  DIRECT_DATABASE_URL: z.preprocess(emptyToUndefined, optionalString),
  REDIS_URL: z.preprocess(emptyToUndefined, z.string().trim().min(1).default('redis://localhost:6379')),

  // --- Auth -----------------------------------------------------------------
  AUTH_SECRET: z.preprocess(emptyToUndefined, optionalString),
  AUTH_URL: z.preprocess(emptyToUndefined, optionalString),
  GOOGLE_CLIENT_ID: z.preprocess(emptyToUndefined, optionalString),
  GOOGLE_CLIENT_SECRET: z.preprocess(emptyToUndefined, optionalString),
  ADMIN_BOOTSTRAP_EMAIL: z.preprocess(emptyToUndefined, optionalString),

  // --- E-mail ---------------------------------------------------------------
  RESEND_API_KEY: z.preprocess(emptyToUndefined, optionalString),
  EMAIL_FROM: z.preprocess(emptyToUndefined, optionalString),
  EMAIL_REPLY_TO: z.preprocess(emptyToUndefined, optionalString),
  RESEND_WEBHOOK_SECRET: z.preprocess(emptyToUndefined, optionalString),

  // --- Payments -------------------------------------------------------------
  MOLLIE_API_KEY: z.preprocess(emptyToUndefined, optionalString),
  MOLLIE_WEBHOOK_TOKEN: z.preprocess(emptyToUndefined, optionalString),
  MOLLIE_PROFILE_ID: z.preprocess(emptyToUndefined, optionalString),

  // --- SMS / WhatsApp -------------------------------------------------------
  WHATSAPP_PROVIDER: z.preprocess(
    emptyToUndefined,
    z.enum(['none', 'twilio', 'meta']).default('none'),
  ),
  TWILIO_ACCOUNT_SID: z.preprocess(emptyToUndefined, optionalString),
  TWILIO_AUTH_TOKEN: z.preprocess(emptyToUndefined, optionalString),
  TWILIO_PHONE_NUMBER: z.preprocess(emptyToUndefined, optionalString),
  TWILIO_MESSAGING_SERVICE_SID: z.preprocess(emptyToUndefined, optionalString),
  TWILIO_WHATSAPP_FROM: z.preprocess(emptyToUndefined, optionalString),
  TWILIO_WHATSAPP_TEMPLATE_SID: z.preprocess(emptyToUndefined, optionalString),
  TWILIO_STATUS_CALLBACK_URL: z.preprocess(emptyToUndefined, optionalString),
  WHATSAPP_CLOUD_PHONE_NUMBER_ID: z.preprocess(emptyToUndefined, optionalString),
  WHATSAPP_CLOUD_ACCESS_TOKEN: z.preprocess(emptyToUndefined, optionalString),
  WHATSAPP_CLOUD_BUSINESS_ACCOUNT_ID: z.preprocess(emptyToUndefined, optionalString),
  WHATSAPP_CLOUD_TEMPLATE_NAME: z.preprocess(emptyToUndefined, optionalString),
  WHATSAPP_CLOUD_TEMPLATE_LANGUAGE: z.preprocess(
    emptyToUndefined,
    z.string().trim().min(2).default('nl'),
  ),
  WHATSAPP_CLOUD_VERIFY_TOKEN: z.preprocess(emptyToUndefined, optionalString),
  WHATSAPP_CLOUD_APP_SECRET: z.preprocess(emptyToUndefined, optionalString),

  // --- Observability --------------------------------------------------------
  SENTRY_DSN: z.preprocess(emptyToUndefined, optionalString),
  SENTRY_ENVIRONMENT: z.preprocess(emptyToUndefined, optionalString),
  LOG_LEVEL: z.preprocess(
    emptyToUndefined,
    z.enum(['trace', 'debug', 'info', 'warn', 'error', 'fatal']).default('info'),
  ),

  // --- Worker ---------------------------------------------------------------
  WORKER_CONCURRENCY: z.preprocess(
    emptyToUndefined,
    z.coerce.number().int().min(1).max(100).default(5),
  ),
  WORKER_HEARTBEAT_TTL_SECONDS: z.preprocess(
    emptyToUndefined,
    z.coerce.number().int().min(10).max(3600).default(90),
  ),
})

export type ServerEnv = z.infer<typeof schema>

function parseEnv(source: NodeJS.ProcessEnv): ServerEnv {
  const result = schema.safeParse(source)

  if (!result.success) {
    const details = result.error.issues
      .map((issue) => `  - ${issue.path.join('.') || '(root)'}: ${issue.message}`)
      .join('\n')
    throw new Error(
      `Invalid environment configuration:\n${details}\n\n` +
        'See .env.example for every variable and INTEGRATIONS.md for where to obtain it.',
    )
  }

  const parsed = result.data

  // Production refuses to start without a session secret. In development a
  // missing secret is tolerated so a fresh clone boots, but Auth.js is told
  // about it explicitly rather than silently signing with a default.
  if (parsed.NODE_ENV === 'production' && (!parsed.AUTH_SECRET || parsed.AUTH_SECRET.length < 32)) {
    throw new Error(
      'AUTH_SECRET must be set to at least 32 characters in production. ' +
        'Generate one with: openssl rand -base64 32',
    )
  }

  return parsed
}

export const env: ServerEnv = parseEnv(process.env)

export const isProduction = env.NODE_ENV === 'production'
export const isTest = env.NODE_ENV === 'test'
export const isDevelopment = env.NODE_ENV === 'development'

/**
 * Which optional integrations are actually configured.
 *
 * The UI and /api/health use this to report LIVE vs CONFIGURATION REQUIRED
 * honestly, instead of showing a feature that would fail on first use.
 */
export const integrations = {
  googleOAuth: Boolean(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET),
  email: Boolean(env.RESEND_API_KEY && env.EMAIL_FROM),
  payments: Boolean(env.MOLLIE_API_KEY && env.MOLLIE_WEBHOOK_TOKEN),
  sms: Boolean(
    env.TWILIO_ACCOUNT_SID &&
      env.TWILIO_AUTH_TOKEN &&
      (env.TWILIO_PHONE_NUMBER || env.TWILIO_MESSAGING_SERVICE_SID),
  ),
  whatsapp:
    env.WHATSAPP_PROVIDER === 'twilio'
      ? Boolean(env.TWILIO_ACCOUNT_SID && env.TWILIO_AUTH_TOKEN && env.TWILIO_WHATSAPP_FROM)
      : env.WHATSAPP_PROVIDER === 'meta'
        ? Boolean(env.WHATSAPP_CLOUD_PHONE_NUMBER_ID && env.WHATSAPP_CLOUD_ACCESS_TOKEN)
        : false,
  sentry: Boolean(env.SENTRY_DSN),
} as const

export type IntegrationName = keyof typeof integrations
