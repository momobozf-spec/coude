import type { Country } from '@/generated/prisma/enums'

/**
 * Provinces of Belgium and the Netherlands (REQUIREMENTS §5).
 *
 * Stored as plain strings on `SearchProfile.provinces` rather than as an enum,
 * because the values also have to line up with whatever a source feed calls
 * them. Normalising a feed's spelling onto this list is the connector's job
 * (phase 3); an enum would force a migration every time a feed spells something
 * differently.
 *
 * Brussels is included under Belgium: it is a Region, not a province, but for
 * someone searching for a home it belongs in exactly the same picker.
 */
export interface ProvinceOption {
  value: string
  country: Country
  /** Names differ per language; Dutch is the stored canonical value. */
  labels: { nl: string; fr: string; en: string }
}

export const PROVINCES: ProvinceOption[] = [
  // --- België ---
  { value: 'Antwerpen', country: 'BE', labels: { nl: 'Antwerpen', fr: 'Anvers', en: 'Antwerp' } },
  {
    value: 'Brussel',
    country: 'BE',
    labels: { nl: 'Brussel', fr: 'Bruxelles', en: 'Brussels' },
  },
  {
    value: 'Henegouwen',
    country: 'BE',
    labels: { nl: 'Henegouwen', fr: 'Hainaut', en: 'Hainaut' },
  },
  { value: 'Limburg', country: 'BE', labels: { nl: 'Limburg', fr: 'Limbourg', en: 'Limburg' } },
  { value: 'Luik', country: 'BE', labels: { nl: 'Luik', fr: 'Liège', en: 'Liège' } },
  {
    value: 'Luxemburg',
    country: 'BE',
    labels: { nl: 'Luxemburg', fr: 'Luxembourg', en: 'Luxembourg' },
  },
  { value: 'Namen', country: 'BE', labels: { nl: 'Namen', fr: 'Namur', en: 'Namur' } },
  {
    value: 'Oost-Vlaanderen',
    country: 'BE',
    labels: { nl: 'Oost-Vlaanderen', fr: 'Flandre-Orientale', en: 'East Flanders' },
  },
  {
    value: 'Vlaams-Brabant',
    country: 'BE',
    labels: { nl: 'Vlaams-Brabant', fr: 'Brabant flamand', en: 'Flemish Brabant' },
  },
  {
    value: 'Waals-Brabant',
    country: 'BE',
    labels: { nl: 'Waals-Brabant', fr: 'Brabant wallon', en: 'Walloon Brabant' },
  },
  {
    value: 'West-Vlaanderen',
    country: 'BE',
    labels: { nl: 'West-Vlaanderen', fr: 'Flandre-Occidentale', en: 'West Flanders' },
  },

  // --- Nederland ---
  { value: 'Drenthe', country: 'NL', labels: { nl: 'Drenthe', fr: 'Drenthe', en: 'Drenthe' } },
  {
    value: 'Flevoland',
    country: 'NL',
    labels: { nl: 'Flevoland', fr: 'Flevoland', en: 'Flevoland' },
  },
  { value: 'Friesland', country: 'NL', labels: { nl: 'Friesland', fr: 'Frise', en: 'Friesland' } },
  {
    value: 'Gelderland',
    country: 'NL',
    labels: { nl: 'Gelderland', fr: 'Gueldre', en: 'Gelderland' },
  },
  {
    value: 'Groningen',
    country: 'NL',
    labels: { nl: 'Groningen', fr: 'Groningue', en: 'Groningen' },
  },
  { value: 'Limburg (NL)', country: 'NL', labels: { nl: 'Limburg', fr: 'Limbourg', en: 'Limburg' } },
  {
    value: 'Noord-Brabant',
    country: 'NL',
    labels: { nl: 'Noord-Brabant', fr: 'Brabant-Septentrional', en: 'North Brabant' },
  },
  {
    value: 'Noord-Holland',
    country: 'NL',
    labels: { nl: 'Noord-Holland', fr: 'Hollande-Septentrionale', en: 'North Holland' },
  },
  {
    value: 'Overijssel',
    country: 'NL',
    labels: { nl: 'Overijssel', fr: 'Overijssel', en: 'Overijssel' },
  },
  { value: 'Utrecht', country: 'NL', labels: { nl: 'Utrecht', fr: 'Utrecht', en: 'Utrecht' } },
  { value: 'Zeeland', country: 'NL', labels: { nl: 'Zeeland', fr: 'Zélande', en: 'Zeeland' } },
  {
    value: 'Zuid-Holland',
    country: 'NL',
    labels: { nl: 'Zuid-Holland', fr: 'Hollande-Méridionale', en: 'South Holland' },
  },
]

export function provincesFor(country: Country): ProvinceOption[] {
  return PROVINCES.filter((province) => province.country === country)
}
