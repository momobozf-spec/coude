import { env } from './env'
import { defaultLocale, type Locale } from '@/i18n/routing'

/**
 * Absolute URLs for e-mails and redirects.
 *
 * Routing uses `localePrefix: 'as-needed'`, so Dutch URLs carry no prefix. A
 * link built by hand as `${APP_URL}/nl/...` would redirect, and a redirect in
 * an e-mail link is exactly where tracking-blockers and mail clients start
 * mangling things.
 */
export function absoluteUrl(path: string, locale: Locale = defaultLocale): string {
  const normalised = path.startsWith('/') ? path : `/${path}`
  const prefix = locale === defaultLocale ? '' : `/${locale}`
  return `${env.APP_URL}${prefix}${normalised}`
}

export function verificationUrl(token: string, locale: Locale = defaultLocale): string {
  return absoluteUrl(`/verify-email?token=${encodeURIComponent(token)}`, locale)
}

export function passwordResetUrl(token: string, locale: Locale = defaultLocale): string {
  return absoluteUrl(`/reset-password?token=${encodeURIComponent(token)}`, locale)
}

export function dashboardUrl(locale: Locale = defaultLocale): string {
  return absoluteUrl('/dashboard', locale)
}

export function notificationPreferencesUrl(locale: Locale = defaultLocale): string {
  return absoluteUrl('/account/notifications', locale)
}

export function accountUrl(locale: Locale = defaultLocale): string {
  return absoluteUrl('/account', locale)
}

export function loginUrl(locale: Locale = defaultLocale): string {
  return absoluteUrl('/login', locale)
}
