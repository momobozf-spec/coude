import { defineRouting } from 'next-intl/routing'

export const locales = ['nl', 'fr', 'en'] as const
export type Locale = (typeof locales)[number]

export const defaultLocale: Locale = 'nl'

export const localeLabels: Record<Locale, string> = {
  nl: 'Nederlands',
  fr: 'Français',
  en: 'English',
}

export const routing = defineRouting({
  locales,
  defaultLocale,
  // The default locale is served without a prefix (/ instead of /nl), which
  // keeps the Dutch URLs — the primary market — clean.
  localePrefix: 'as-needed',
})

export function isLocale(value: string): value is Locale {
  return (locales as readonly string[]).includes(value)
}
