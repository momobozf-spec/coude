import type { UserRole } from '@/generated/prisma/enums'
import 'next-auth'
import 'next-auth/jwt'

declare module 'next-auth' {
  interface Session {
    user: {
      id: string
      email: string
      name?: string | null
      image?: string | null
      role: UserRole
      locale: string
      /**
       * Not `emailVerified`: Auth.js declares that as a `Date` on its own user
       * type, and augmenting it with a boolean intersects into an impossible
       * type. Our own `AuthenticatedUser` in guards.ts exposes it as
       * `emailVerified` again, so call sites stay readable.
       */
      isEmailVerified: boolean
    }
    /** Id of the revocable server-side session row backing this token. */
    sessionId?: string
  }

  interface User {
    role?: UserRole
    locale?: string
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    userId?: string
    role?: UserRole
    locale?: string
    /**
     * Named `isEmailVerified` rather than `emailVerified` on purpose: Auth.js
     * already declares `emailVerified` as a `Date` on its adapter user, and
     * module augmentation would intersect the two into an impossible type.
     */
    isEmailVerified?: boolean
    /** `Session.sessionToken`, so the token can be revoked server-side. */
    sid?: string
  }
}
