'use client'

import { AlertCircleIcon, LockIcon } from 'lucide-react'
import { useActionState, useState } from 'react'
import { useTranslations } from 'next-intl'

import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { CheckField, RadioField } from '@/components/ui/check-field'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Link } from '@/i18n/navigation'
import type { Locale } from '@/i18n/routing'
import { provincesFor } from '@/lib/regions'
import {
  createSearchProfileAction,
  updateSearchProfileAction,
  type SearchProfileFormState,
} from '@/server/search-profiles/actions'

/**
 * The search profile form (REQUIREMENTS §5).
 *
 * Uncontrolled on purpose: every field is a plain input with a `defaultValue`,
 * so the form submits as a normal POST and works before hydration. The only
 * piece of state is the rent/buy choice, because it changes a price hint.
 */

const PROPERTY_TYPES = [
  'APARTMENT',
  'HOUSE',
  'STUDIO',
  'ROOM',
  'VILLA',
  'NEW_BUILD',
  'OTHER',
] as const

const ENERGY_LABELS = [
  'A_PLUS_PLUS_PLUS',
  'A_PLUS_PLUS',
  'A_PLUS',
  'A',
  'B',
  'C',
  'D',
  'E',
  'F',
  'G',
] as const

const ENERGY_LABEL_DISPLAY: Record<string, string> = {
  A_PLUS_PLUS_PLUS: 'A+++',
  A_PLUS_PLUS: 'A++',
  A_PLUS: 'A+',
  A: 'A',
  B: 'B',
  C: 'C',
  D: 'D',
  E: 'E',
  F: 'F',
  G: 'G',
}

const REQUIREMENT_FIELDS = [
  'requireGarden',
  'requireTerrace',
  'requireBalcony',
  'requireParking',
  'requireGarage',
  'requireFurnished',
  'requirePetsAllowed',
  'requireLift',
] as const

const ALL_CHANNELS = ['EMAIL', 'WHATSAPP', 'SMS'] as const

export interface SearchProfileFormValues {
  id?: string
  name: string
  isActive: boolean
  countries: string[]
  provinces: string[]
  municipalities: string
  postalCodes: string
  centerLat: string
  centerLng: string
  radiusKm: string
  listingType: 'RENT' | 'BUY'
  propertyTypes: string[]
  minPrice: string
  maxPrice: string
  minBedrooms: string
  minBathrooms: string
  minLivingArea: string
  maxLivingArea: string
  requirements: Record<(typeof REQUIREMENT_FIELDS)[number], boolean>
  minEnergyLabel: string
  keywords: string
  excludedKeywords: string
  availableFrom: string
  minConstructionYear: string
  notificationChannels: string[]
  notifyOnPriceDrop: boolean
  notifyOnBackAvailable: boolean
  notifyOnAvailabilityChange: boolean
}

export const EMPTY_SEARCH_PROFILE: SearchProfileFormValues = {
  name: '',
  isActive: true,
  countries: ['BE'],
  provinces: [],
  municipalities: '',
  postalCodes: '',
  centerLat: '',
  centerLng: '',
  radiusKm: '',
  listingType: 'RENT',
  propertyTypes: [],
  minPrice: '',
  maxPrice: '',
  minBedrooms: '',
  minBathrooms: '',
  minLivingArea: '',
  maxLivingArea: '',
  requirements: {
    requireGarden: false,
    requireTerrace: false,
    requireBalcony: false,
    requireParking: false,
    requireGarage: false,
    requireFurnished: false,
    requirePetsAllowed: false,
    requireLift: false,
  },
  minEnergyLabel: '',
  keywords: '',
  excludedKeywords: '',
  availableFrom: '',
  minConstructionYear: '',
  notificationChannels: ['EMAIL'],
  notifyOnPriceDrop: false,
  notifyOnBackAvailable: false,
  notifyOnAvailabilityChange: false,
}

const initialState: SearchProfileFormState = { status: 'idle' }

export function SearchProfileForm({
  mode,
  values,
  allowedChannels,
  configuredChannels,
  locale,
}: {
  mode: 'create' | 'edit'
  values: SearchProfileFormValues
  /** Used to label the province list in the reader's language. */
  locale: Locale
  /** Channels the user's plan permits (REQUIREMENTS §18). */
  allowedChannels: string[]
  /** Channels that actually have a working provider configured (§39). */
  configuredChannels: string[]
}) {
  const t = useTranslations('searchProfiles')
  const action = mode === 'create' ? createSearchProfileAction : updateSearchProfileAction
  const [state, formAction, pending] = useActionState(action, initialState)

  const [listingType, setListingType] = useState(values.listingType)

  return (
    <form action={formAction} className="space-y-8" noValidate>
      {values.id ? <input type="hidden" name="id" value={values.id} /> : null}

      <FormAlert state={state} />

      {/* ---------------------------------------------------------------- */}
      <Section title={t('form.sectionBasics')}>
        <Field label={t('form.nameLabel')} errors={state.fieldErrors?.name}>
          <Input
            name="name"
            defaultValue={values.name}
            placeholder={t('form.namePlaceholder')}
            maxLength={80}
            required
            aria-invalid={Boolean(state.fieldErrors?.name)}
          />
        </Field>

        <CheckField
          name="isActive"
          defaultChecked={values.isActive}
          label={t('form.isActiveLabel')}
          hint={t('form.isActiveHint')}
        />
      </Section>

      {/* ---------------------------------------------------------------- */}
      <Section title={t('form.sectionType')}>
        <Field label={t('form.listingTypeLabel')} errors={state.fieldErrors?.listingType}>
          <div className="flex gap-6">
            <RadioField
              name="listingType"
              value="RENT"
              label={t('form.listingTypeRent')}
              defaultChecked={values.listingType === 'RENT'}
              onChange={() => setListingType('RENT')}
            />
            <RadioField
              name="listingType"
              value="BUY"
              label={t('form.listingTypeBuy')}
              defaultChecked={values.listingType === 'BUY'}
              onChange={() => setListingType('BUY')}
            />
          </div>
        </Field>

        <Field label={t('form.propertyTypesLabel')} hint={t('form.propertyTypesHint')}>
          <div className="grid gap-2 sm:grid-cols-2">
            {PROPERTY_TYPES.map((type) => (
              <CheckField
                key={type}
                name="propertyTypes"
                value={type}
                defaultChecked={values.propertyTypes.includes(type)}
                label={t(`form.type${type}`)}
              />
            ))}
          </div>
        </Field>
      </Section>

      {/* ---------------------------------------------------------------- */}
      <Section title={t('form.sectionLocation')}>
        <Field label={t('form.countriesLabel')} errors={state.fieldErrors?.countries}>
          <div className="flex gap-6">
            <CheckField
              name="countries"
              value="BE"
              defaultChecked={values.countries.includes('BE')}
              label={t('form.countryBE')}
            />
            <CheckField
              name="countries"
              value="NL"
              defaultChecked={values.countries.includes('NL')}
              label={t('form.countryNL')}
            />
          </div>
        </Field>

        <Field label={t('form.provincesLabel')} hint={t('form.provincesHint')}>
          {/* A native multi-select rather than 23 checkboxes: the list is long,
              rarely used, and this keeps the form scannable on a phone. */}
          <select
            name="provinces"
            multiple
            size={8}
            defaultValue={values.provinces}
            className="border-input focus-visible:border-ring focus-visible:ring-ring/50 w-full rounded-md border bg-transparent px-3 py-2 text-sm shadow-xs outline-none focus-visible:ring-[3px]"
          >
            {(['BE', 'NL'] as const).map((country) => (
              <optgroup key={country} label={t(`form.country${country}`)}>
                {provincesFor(country).map((province) => (
                  <option key={province.value} value={province.value}>
                    {province.labels[locale]}
                  </option>
                ))}
              </optgroup>
            ))}
          </select>
        </Field>

        <Field
          label={t('form.municipalitiesLabel')}
          hint={t('form.municipalitiesHint')}
          errors={state.fieldErrors?.municipalities}
        >
          <Textarea name="municipalities" defaultValue={values.municipalities} rows={2} />
        </Field>

        <Field
          label={t('form.postalCodesLabel')}
          hint={t('form.postalCodesHint')}
          errors={state.fieldErrors?.postalCodes}
        >
          <Textarea name="postalCodes" defaultValue={values.postalCodes} rows={2} />
        </Field>

        <fieldset className="border-border rounded-lg border p-4">
          <legend className="px-1 text-sm font-medium">{t('form.radiusTitle')}</legend>
          <p className="text-muted-foreground mb-3 text-xs">{t('form.radiusHint')}</p>
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label={t('form.centerLatLabel')} compact>
              <Input name="centerLat" type="number" step="any" defaultValue={values.centerLat} />
            </Field>
            <Field label={t('form.centerLngLabel')} compact>
              <Input name="centerLng" type="number" step="any" defaultValue={values.centerLng} />
            </Field>
            <Field
              label={t('form.radiusKmLabel')}
              compact
              errors={state.fieldErrors?.radiusKm}
            >
              <Input name="radiusKm" type="number" min={1} max={200} defaultValue={values.radiusKm} />
            </Field>
          </div>
        </fieldset>
      </Section>

      {/* ---------------------------------------------------------------- */}
      <Section
        title={t('form.sectionBudget')}
        hint={listingType === 'RENT' ? t('form.priceHintRent') : t('form.priceHintBuy')}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={t('form.minPriceLabel')} errors={state.fieldErrors?.minPrice}>
            <Input name="minPrice" type="number" min={0} inputMode="numeric" defaultValue={values.minPrice} />
          </Field>
          <Field label={t('form.maxPriceLabel')} errors={state.fieldErrors?.maxPrice}>
            <Input name="maxPrice" type="number" min={0} inputMode="numeric" defaultValue={values.maxPrice} />
          </Field>
        </div>
      </Section>

      {/* ---------------------------------------------------------------- */}
      <Section title={t('form.sectionFeatures')}>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={t('form.minBedroomsLabel')}>
            <Input name="minBedrooms" type="number" min={0} max={20} defaultValue={values.minBedrooms} />
          </Field>
          <Field label={t('form.minBathroomsLabel')}>
            <Input name="minBathrooms" type="number" min={0} max={10} defaultValue={values.minBathrooms} />
          </Field>
          <Field label={t('form.minLivingAreaLabel')}>
            <Input name="minLivingArea" type="number" min={0} defaultValue={values.minLivingArea} />
          </Field>
          <Field label={t('form.maxLivingAreaLabel')} errors={state.fieldErrors?.maxLivingArea}>
            <Input name="maxLivingArea" type="number" min={0} defaultValue={values.maxLivingArea} />
          </Field>
        </div>

        <Field label={t('form.requirementsLabel')} hint={t('form.requirementsHint')}>
          <div className="grid gap-2 sm:grid-cols-2">
            {REQUIREMENT_FIELDS.map((field) => (
              <CheckField
                key={field}
                name={field}
                defaultChecked={values.requirements[field]}
                label={t(`form.${field}`)}
              />
            ))}
          </div>
        </Field>

        <Field label={t('form.minEnergyLabelLabel')}>
          <Select name="minEnergyLabel" defaultValue={values.minEnergyLabel}>
            <option value="">{t('form.energyAny')}</option>
            {ENERGY_LABELS.map((label) => (
              <option key={label} value={label}>
                {ENERGY_LABEL_DISPLAY[label]}
              </option>
            ))}
          </Select>
        </Field>
      </Section>

      {/* ---------------------------------------------------------------- */}
      <Section title={t('form.sectionExtra')}>
        <Field label={t('form.keywordsLabel')} hint={t('form.keywordsHint')}>
          <Textarea name="keywords" defaultValue={values.keywords} rows={2} />
        </Field>

        <Field
          label={t('form.excludedKeywordsLabel')}
          hint={t('form.excludedKeywordsHint')}
          errors={state.fieldErrors?.excludedKeywords}
        >
          <Textarea name="excludedKeywords" defaultValue={values.excludedKeywords} rows={2} />
        </Field>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={t('form.availableFromLabel')} errors={state.fieldErrors?.availableFrom}>
            <Input name="availableFrom" type="date" defaultValue={values.availableFrom} />
          </Field>
          <Field label={t('form.minConstructionYearLabel')}>
            <Input
              name="minConstructionYear"
              type="number"
              min={1500}
              max={new Date().getFullYear() + 10}
              defaultValue={values.minConstructionYear}
            />
          </Field>
        </div>
      </Section>

      {/* ---------------------------------------------------------------- */}
      <Section title={t('form.sectionNotifications')}>
        <Field
          label={t('form.channelsLabel')}
          errors={state.fieldErrors?.notificationChannels}
        >
          <div className="space-y-2">
            {ALL_CHANNELS.map((channel) => {
              const planAllows = allowedChannels.includes(channel)
              const providerReady = configuredChannels.includes(channel)
              const disabled = !planAllows || !providerReady

              // Two different reasons a channel can be unavailable, and the user
              // deserves to know which: an upgrade fixes one, nothing they do
              // fixes the other (§39).
              const hint = !planAllows
                ? t('form.channelLocked')
                : !providerReady
                  ? t('form.channelNotConfigured')
                  : undefined

              return (
                <CheckField
                  key={channel}
                  name="notificationChannels"
                  value={channel}
                  disabled={disabled}
                  defaultChecked={!disabled && values.notificationChannels.includes(channel)}
                  label={
                    <span className="inline-flex items-center gap-1.5">
                      {t(`form.channel${channel}`)}
                      {disabled ? <LockIcon className="size-3" aria-hidden="true" /> : null}
                    </span>
                  }
                  {...(hint ? { hint } : {})}
                />
              )
            })}
          </div>
        </Field>

        <div className="space-y-2">
          <CheckField
            name="notifyOnPriceDrop"
            defaultChecked={values.notifyOnPriceDrop}
            label={t('form.notifyOnPriceDropLabel')}
          />
          <CheckField
            name="notifyOnBackAvailable"
            defaultChecked={values.notifyOnBackAvailable}
            label={t('form.notifyOnBackAvailableLabel')}
          />
          <CheckField
            name="notifyOnAvailabilityChange"
            defaultChecked={values.notifyOnAvailabilityChange}
            label={t('form.notifyOnAvailabilityChangeLabel')}
          />
        </div>
      </Section>

      <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
        <Button asChild variant="ghost" type="button">
          <Link href="/searches">{t('form.cancel')}</Link>
        </Button>
        <Button type="submit" size="lg" disabled={pending}>
          {pending
            ? t('form.submitting')
            : mode === 'create'
              ? t('form.submitCreate')
              : t('form.submitUpdate')}
        </Button>
      </div>
    </form>
  )
}

// ---------------------------------------------------------------------------

function Section({
  title,
  hint,
  children,
}: {
  title: string
  hint?: string
  children: React.ReactNode
}) {
  return (
    <section className="space-y-4">
      <div>
        <h2 className="text-base font-semibold">{title}</h2>
        {hint ? <p className="text-muted-foreground mt-0.5 text-sm">{hint}</p> : null}
      </div>
      {children}
    </section>
  )
}

function Field({
  label,
  hint,
  errors,
  compact,
  children,
}: {
  label: string
  hint?: string
  errors?: string[]
  compact?: boolean
  children: React.ReactNode
}) {
  const t = useTranslations('searchProfiles.fieldErrors')

  return (
    <div className={compact ? '' : 'space-y-1.5'}>
      <Label className={compact ? 'text-xs' : ''}>{label}</Label>
      <div className={compact ? 'mt-1' : ''}>{children}</div>
      {hint ? <p className="text-muted-foreground text-xs">{hint}</p> : null}
      {errors?.length ? (
        <ul className="text-destructive space-y-0.5 text-sm">
          {errors.map((key) => (
            <li key={key}>{t(key)}</li>
          ))}
        </ul>
      ) : null}
    </div>
  )
}

function FormAlert({ state }: { state: SearchProfileFormState }) {
  const t = useTranslations('searchProfiles.messages')

  if (state.status !== 'error' || !state.message) return null

  return (
    <Alert variant="destructive">
      <AlertCircleIcon />
      <AlertDescription>{t(state.message)}</AlertDescription>
    </Alert>
  )
}
