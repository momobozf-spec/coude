import { MapPinIcon, PencilIcon, PauseIcon, PlayIcon, Trash2Icon } from 'lucide-react'
import { getFormatter, getTranslations } from 'next-intl/server'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Link } from '@/i18n/navigation'
import {
  deleteSearchProfileAction,
  toggleSearchProfileAction,
} from '@/server/search-profiles/actions'
import type { SearchProfileSummary } from '@/server/search-profiles/service'

/**
 * One search profile in the list.
 *
 * A server component: the toggle and delete are plain form posts to server
 * actions, so they work without JavaScript and need no client bundle.
 */
export async function SearchProfileCard({ profile }: { profile: SearchProfileSummary }) {
  const t = await getTranslations('searchProfiles.card')
  const format = await getFormatter()

  const money = (value: number) =>
    format.number(value, { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 })

  const priceLabel =
    profile.minPrice != null && profile.maxPrice != null
      ? t('priceRange', { min: money(profile.minPrice), max: money(profile.maxPrice) })
      : profile.maxPrice != null
        ? t('priceUpTo', { max: money(profile.maxPrice) })
        : profile.minPrice != null
          ? t('priceFrom', { min: money(profile.minPrice) })
          : t('anyPrice')

  const places = [...profile.municipalities, ...profile.postalCodes]
  const placeLabel =
    places.length > 0 ? places.slice(0, 4).join(', ') + (places.length > 4 ? '…' : '') : null

  return (
    <Card className={profile.isActive ? '' : 'opacity-70'}>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <h3 className="truncate text-base font-semibold">{profile.name}</h3>
            <div className="text-muted-foreground mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
              <span>{profile.listingType === 'RENT' ? t('rent') : t('buy')}</span>
              <span aria-hidden="true">·</span>
              <span>{priceLabel}</span>
            </div>
          </div>

          <Badge variant={profile.isActive ? 'success' : 'muted'}>
            {profile.isActive ? t('active') : t('inactive')}
          </Badge>
        </div>

        {placeLabel ? (
          <p className="text-muted-foreground flex items-start gap-1.5 text-sm">
            <MapPinIcon className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
            <span className="min-w-0 break-words">{placeLabel}</span>
          </p>
        ) : null}

        <div className="text-muted-foreground flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
          <span>{t('matches', { count: profile.matchCount })}</span>
          {profile.lastMatchedAt ? (
            <>
              <span aria-hidden="true">·</span>
              <span>
                {t('lastMatch', {
                  date: format.dateTime(profile.lastMatchedAt, {
                    dateStyle: 'medium',
                    timeStyle: 'short',
                  }),
                })}
              </span>
            </>
          ) : null}
        </div>

        <div className="flex flex-wrap gap-2 pt-1">
          <Button asChild variant="outline" size="sm">
            <Link href={`/searches/${profile.id}`}>
              <PencilIcon />
              {t('edit')}
            </Link>
          </Button>

          <form action={toggleSearchProfileAction}>
            <input type="hidden" name="id" value={profile.id} />
            <input type="hidden" name="isActive" value={profile.isActive ? 'false' : 'true'} />
            <Button type="submit" variant="ghost" size="sm">
              {profile.isActive ? <PauseIcon /> : <PlayIcon />}
              {profile.isActive ? t('deactivate') : t('activate')}
            </Button>
          </form>

          <form action={deleteSearchProfileAction} className="ml-auto">
            <input type="hidden" name="id" value={profile.id} />
            <Button
              type="submit"
              variant="ghost"
              size="sm"
              className="text-destructive hover:text-destructive"
            >
              <Trash2Icon />
              {t('delete')}
            </Button>
          </form>
        </div>
      </CardContent>
    </Card>
  )
}
