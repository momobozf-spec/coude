'use client'

import { useActionState, useId } from 'react'
import { useTranslations } from 'next-intl'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Link } from '@/i18n/navigation'
import { loginAction } from '@/server/auth/actions'

import { AuthFormFeedback, FieldError, initialAuthFormState } from './auth-form-feedback'

export function LoginForm({ callbackUrl }: { callbackUrl?: string }) {
  const t = useTranslations('auth')
  const [state, formAction, pending] = useActionState(loginAction, initialAuthFormState)

  const emailId = useId()
  const passwordId = useId()

  return (
    <form action={formAction} className="space-y-4" noValidate>
      <AuthFormFeedback state={state} />

      {callbackUrl ? <input type="hidden" name="callbackUrl" value={callbackUrl} /> : null}

      <div>
        <Label htmlFor={emailId}>{t('common.emailLabel')}</Label>
        <Input
          id={emailId}
          name="email"
          type="email"
          autoComplete="email"
          inputMode="email"
          required
          autoFocus
          placeholder={t('common.emailPlaceholder')}
          className="mt-1.5"
          aria-invalid={Boolean(state.fieldErrors?.email)}
        />
        <FieldError errors={state.fieldErrors?.email} />
      </div>

      <div>
        <div className="flex items-baseline justify-between gap-3">
          <Label htmlFor={passwordId}>{t('common.passwordLabel')}</Label>
          <Link
            href="/forgot-password"
            className="text-primary text-sm underline-offset-4 hover:underline"
          >
            {t('login.forgotPassword')}
          </Link>
        </div>
        <Input
          id={passwordId}
          name="password"
          type="password"
          autoComplete="current-password"
          required
          className="mt-1.5"
          aria-invalid={Boolean(state.fieldErrors?.password)}
        />
        <FieldError errors={state.fieldErrors?.password} />
      </div>

      <Button type="submit" size="lg" className="w-full" disabled={pending}>
        {pending ? t('login.submitting') : t('login.submit')}
      </Button>
    </form>
  )
}
