'use client'

import { useActionState, useId } from 'react'
import { useTranslations } from 'next-intl'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { resendVerificationAction } from '@/server/auth/actions'

import { AuthFormFeedback, FieldError, initialAuthFormState } from './auth-form-feedback'

export function ResendVerificationForm() {
  const t = useTranslations('auth')
  const [state, formAction, pending] = useActionState(
    resendVerificationAction,
    initialAuthFormState,
  )

  const emailId = useId()

  if (state.status === 'success') {
    return <AuthFormFeedback state={state} />
  }

  return (
    <form action={formAction} className="space-y-3" noValidate>
      <AuthFormFeedback state={state} />

      <p className="text-muted-foreground text-sm">{t('verifyEmail.resendPrompt')}</p>

      <div>
        <Label htmlFor={emailId} className="sr-only">
          {t('common.emailLabel')}
        </Label>
        <Input
          id={emailId}
          name="email"
          type="email"
          autoComplete="email"
          inputMode="email"
          required
          placeholder={t('common.emailPlaceholder')}
          aria-invalid={Boolean(state.fieldErrors?.email)}
        />
        <FieldError errors={state.fieldErrors?.email} />
      </div>

      <Button type="submit" variant="outline" className="w-full" disabled={pending}>
        {pending ? t('verifyEmail.resendSubmitting') : t('verifyEmail.resendButton')}
      </Button>
    </form>
  )
}
