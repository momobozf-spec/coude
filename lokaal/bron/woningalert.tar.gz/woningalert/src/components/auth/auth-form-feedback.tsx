'use client'

import { AlertCircleIcon, CheckCircle2Icon } from 'lucide-react'
import { useTranslations } from 'next-intl'

import { Alert, AlertDescription } from '@/components/ui/alert'
import type { AuthFormState } from '@/server/auth/actions'

export const initialAuthFormState: AuthFormState = { status: 'idle' }

/**
 * Renders the form-level outcome of an auth action.
 *
 * The server returns translation keys, never sentences: at the point the action
 * runs it does not reliably know which of NL/FR/EN the reader uses, and a Dutch
 * error on a French page is worse than no error at all.
 */
export function AuthFormFeedback({ state }: { state: AuthFormState }) {
  const t = useTranslations('auth.messages')

  if (state.status === 'idle' || !state.message) return null

  const isSuccess = state.status === 'success'

  return (
    <Alert variant={isSuccess ? 'success' : 'destructive'} className="mb-4">
      {isSuccess ? <CheckCircle2Icon /> : <AlertCircleIcon />}
      <AlertDescription>{t(state.message)}</AlertDescription>
    </Alert>
  )
}

/** Field-level errors, rendered under the input they belong to. */
export function FieldError({ errors }: { errors: string[] | undefined }) {
  const t = useTranslations('auth.fieldErrors')

  if (!errors?.length) return null

  return (
    <ul className="text-destructive mt-1.5 space-y-0.5 text-sm">
      {errors.map((key) => (
        <li key={key}>{t(key)}</li>
      ))}
    </ul>
  )
}
