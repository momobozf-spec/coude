'use client'

import { useActionState, useId } from 'react'
import { useTranslations } from 'next-intl'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Link } from '@/i18n/navigation'
import { resetPasswordAction } from '@/server/auth/actions'

import { AuthFormFeedback, FieldError, initialAuthFormState } from './auth-form-feedback'

export function ResetPasswordForm({ token }: { token: string }) {
  const t = useTranslations('auth')
  const [state, formAction, pending] = useActionState(resetPasswordAction, initialAuthFormState)

  const passwordId = useId()
  const confirmId = useId()

  if (state.status === 'success') {
    return (
      <div className="space-y-4">
        <AuthFormFeedback state={state} />
        <Button asChild size="lg" className="w-full">
          <Link href="/login">{t('login.submit')}</Link>
        </Button>
      </div>
    )
  }

  return (
    <form action={formAction} className="space-y-4" noValidate>
      <AuthFormFeedback state={state} />

      <input type="hidden" name="token" value={token} />

      <div>
        <Label htmlFor={passwordId}>{t('common.passwordLabel')}</Label>
        <Input
          id={passwordId}
          name="password"
          type="password"
          autoComplete="new-password"
          required
          autoFocus
          minLength={10}
          className="mt-1.5"
          aria-invalid={Boolean(state.fieldErrors?.password)}
          aria-describedby={`${passwordId}-hint`}
        />
        <p id={`${passwordId}-hint`} className="text-muted-foreground mt-1.5 text-xs">
          {t('common.passwordHint')}
        </p>
        <FieldError errors={state.fieldErrors?.password} />
      </div>

      <div>
        <Label htmlFor={confirmId}>{t('common.passwordConfirmLabel')}</Label>
        <Input
          id={confirmId}
          name="passwordConfirm"
          type="password"
          autoComplete="new-password"
          required
          className="mt-1.5"
          aria-invalid={Boolean(state.fieldErrors?.passwordConfirm)}
        />
        <FieldError errors={state.fieldErrors?.passwordConfirm} />
      </div>

      <Button type="submit" size="lg" className="w-full" disabled={pending}>
        {pending ? t('resetPassword.submitting') : t('resetPassword.submit')}
      </Button>

      {state.fieldErrors?.token || state.message?.startsWith('resetToken') ? (
        <Link
          href="/forgot-password"
          className="text-primary block text-center text-sm underline-offset-4 hover:underline"
        >
          {t('resetPassword.requestNew')}
        </Link>
      ) : null}
    </form>
  )
}
