'use client'

import { useActionState, useId } from 'react'
import { useTranslations } from 'next-intl'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type { Locale } from '@/i18n/routing'
import { forgotPasswordAction } from '@/server/auth/actions'

import { AuthFormFeedback, FieldError, initialAuthFormState } from './auth-form-feedback'

export function ForgotPasswordForm({ locale }: { locale: Locale }) {
  const t = useTranslations('auth')
  const [state, formAction, pending] = useActionState(forgotPasswordAction, initialAuthFormState)

  const emailId = useId()

  // The success message is intentionally the same whether or not the address
  // has an account, so the form is replaced by it either way.
  if (state.status === 'success') {
    return <AuthFormFeedback state={state} />
  }

  return (
    <form action={formAction} className="space-y-4" noValidate>
      <AuthFormFeedback state={state} />

      <input type="hidden" name="locale" value={locale} />

      <div>
        <Label htmlFor={emailId}>{t('common.emailLabel')}</Label>
        <Input
          id={emailId}
          name="email"
          type="email"
          autoComplete="email"
          inputMode="email"
          required
          autoFocus
          placeholder={t('common.emailPlaceholder')}
          className="mt-1.5"
          aria-invalid={Boolean(state.fieldErrors?.email)}
        />
        <FieldError errors={state.fieldErrors?.email} />
      </div>

      <Button type="submit" size="lg" className="w-full" disabled={pending}>
        {pending ? t('forgotPassword.submitting') : t('forgotPassword.submit')}
      </Button>
    </form>
  )
}
