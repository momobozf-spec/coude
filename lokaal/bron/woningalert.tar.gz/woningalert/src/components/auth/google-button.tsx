'use client'

import { useFormStatus } from 'react-dom'
import { useTranslations } from 'next-intl'

import { Button } from '@/components/ui/button'
import { googleSignInAction } from '@/server/auth/actions'

/**
 * Only rendered when Google OAuth is actually configured — the page decides,
 * from `integrations.googleOAuth` on the server. A button that cannot work is
 * exactly what REQUIREMENTS §39 forbids.
 */
export function GoogleButton({ callbackUrl }: { callbackUrl?: string }) {
  return (
    <form action={googleSignInAction}>
      {callbackUrl ? <input type="hidden" name="callbackUrl" value={callbackUrl} /> : null}
      <GoogleSubmit />
    </form>
  )
}

function GoogleSubmit() {
  const t = useTranslations('auth.common')
  const { pending } = useFormStatus()

  return (
    <Button type="submit" variant="outline" className="w-full" size="lg" disabled={pending}>
      <GoogleLogo />
      {t('googleButton')}
    </Button>
  )
}

function GoogleLogo() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className="size-4">
      <path
        fill="#4285F4"
        d="M23.06 12.25c0-.85-.08-1.67-.22-2.45H12v4.64h6.2a5.3 5.3 0 0 1-2.3 3.48v2.89h3.72c2.18-2 3.44-4.96 3.44-8.56Z"
      />
      <path
        fill="#34A853"
        d="M12 23.5c3.1 0 5.71-1.03 7.62-2.79l-3.72-2.89c-1.03.69-2.35 1.1-3.9 1.1-3 0-5.55-2.02-6.46-4.75H1.7v2.98A11.5 11.5 0 0 0 12 23.5Z"
      />
      <path
        fill="#FBBC05"
        d="M5.54 14.17a6.9 6.9 0 0 1 0-4.34V6.85H1.7a11.5 11.5 0 0 0 0 10.3l3.84-2.98Z"
      />
      <path
        fill="#EA4335"
        d="M12 5.08c1.69 0 3.2.58 4.4 1.72l3.3-3.3C17.7 1.66 15.1.5 12 .5A11.5 11.5 0 0 0 1.7 6.85l3.84 2.98C6.45 7.1 9 5.08 12 5.08Z"
      />
    </svg>
  )
}
