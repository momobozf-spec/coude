'use client'

import { useActionState, useId, useState } from 'react'
import { useTranslations } from 'next-intl'

import { Button } from '@/components/ui/button'
import { Checkbox, CheckboxIndicator } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type { Locale } from '@/i18n/routing'
import { registerAction } from '@/server/auth/actions'

import { AuthFormFeedback, FieldError, initialAuthFormState } from './auth-form-feedback'

export function RegisterForm({ locale }: { locale: Locale }) {
  const t = useTranslations('auth')
  const [state, formAction, pending] = useActionState(registerAction, initialAuthFormState)

  const nameId = useId()
  const emailId = useId()
  const passwordId = useId()
  const confirmId = useId()
  const termsId = useId()
  const marketingId = useId()

  const [acceptTerms, setAcceptTerms] = useState(false)
  const [marketing, setMarketing] = useState(false)

  // On success the form is replaced by the "check your e-mail" message: leaving
  // the fields on screen invites a second submit that would only be rate
  // limited.
  if (state.status === 'success') {
    return (
      <div className="space-y-4">
        <AuthFormFeedback state={state} />
        <p className="text-muted-foreground text-sm">{t('verifyEmail.pendingBody')}</p>
      </div>
    )
  }

  return (
    <form action={formAction} className="space-y-4" noValidate>
      <AuthFormFeedback state={state} />

      <input type="hidden" name="locale" value={locale} />

      <div>
        <Label htmlFor={nameId}>{t('common.nameLabel')}</Label>
        <Input
          id={nameId}
          name="name"
          type="text"
          autoComplete="name"
          placeholder={t('common.namePlaceholder')}
          className="mt-1.5"
          maxLength={120}
        />
        <FieldError errors={state.fieldErrors?.name} />
      </div>

      <div>
        <Label htmlFor={emailId}>{t('common.emailLabel')}</Label>
        <Input
          id={emailId}
          name="email"
          type="email"
          autoComplete="email"
          inputMode="email"
          required
          placeholder={t('common.emailPlaceholder')}
          className="mt-1.5"
          aria-invalid={Boolean(state.fieldErrors?.email)}
        />
        <FieldError errors={state.fieldErrors?.email} />
      </div>

      <div>
        <Label htmlFor={passwordId}>{t('common.passwordLabel')}</Label>
        <Input
          id={passwordId}
          name="password"
          type="password"
          autoComplete="new-password"
          required
          minLength={10}
          className="mt-1.5"
          aria-invalid={Boolean(state.fieldErrors?.password)}
          aria-describedby={`${passwordId}-hint`}
        />
        <p id={`${passwordId}-hint`} className="text-muted-foreground mt-1.5 text-xs">
          {t('common.passwordHint')}
        </p>
        <FieldError errors={state.fieldErrors?.password} />
      </div>

      <div>
        <Label htmlFor={confirmId}>{t('common.passwordConfirmLabel')}</Label>
        <Input
          id={confirmId}
          name="passwordConfirm"
          type="password"
          autoComplete="new-password"
          required
          className="mt-1.5"
          aria-invalid={Boolean(state.fieldErrors?.passwordConfirm)}
        />
        <FieldError errors={state.fieldErrors?.passwordConfirm} />
      </div>

      <div className="space-y-3 pt-1">
        <div className="flex items-start gap-2.5">
          {/* Radix renders a button, so a hidden input carries the value in the
              FormData that the server action receives. */}
          <Checkbox
            id={termsId}
            checked={acceptTerms}
            onCheckedChange={(checked) => setAcceptTerms(checked === true)}
            aria-invalid={Boolean(state.fieldErrors?.acceptTerms)}
            className="mt-0.5"
          >
            <CheckboxIndicator />
          </Checkbox>
          <input type="hidden" name="acceptTerms" value={acceptTerms ? 'true' : 'false'} />
          <Label htmlFor={termsId} className="text-muted-foreground items-start text-sm leading-relaxed font-normal">
            {t('register.termsLabel')}
          </Label>
        </div>
        <FieldError errors={state.fieldErrors?.acceptTerms} />

        <div className="flex items-start gap-2.5">
          <Checkbox
            id={marketingId}
            checked={marketing}
            onCheckedChange={(checked) => setMarketing(checked === true)}
            className="mt-0.5"
          >
            <CheckboxIndicator />
          </Checkbox>
          <input type="hidden" name="marketingConsent" value={marketing ? 'true' : 'false'} />
          <Label
            htmlFor={marketingId}
            className="text-muted-foreground items-start text-sm leading-relaxed font-normal"
          >
            {t('register.marketingLabel')}
          </Label>
        </div>
      </div>

      <Button type="submit" size="lg" className="w-full" disabled={pending}>
        {pending ? t('register.submitting') : t('register.submit')}
      </Button>
    </form>
  )
}
