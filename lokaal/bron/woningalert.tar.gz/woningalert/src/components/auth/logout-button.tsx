'use client'

import { LogOutIcon } from 'lucide-react'
import { useFormStatus } from 'react-dom'
import { useTranslations } from 'next-intl'

import { Button } from '@/components/ui/button'
import { logoutAction } from '@/server/auth/actions'

export function LogoutButton() {
  return (
    <form action={logoutAction}>
      <LogoutSubmit />
    </form>
  )
}

function LogoutSubmit() {
  const t = useTranslations('nav')
  const { pending } = useFormStatus()

  return (
    <Button type="submit" variant="ghost" size="sm" disabled={pending}>
      <LogOutIcon />
      {t('logout')}
    </Button>
  )
}
