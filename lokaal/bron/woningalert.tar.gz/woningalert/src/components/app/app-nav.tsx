'use client'

import { HomeIcon, MenuIcon, SearchIcon, SettingsIcon, ShieldIcon, XIcon } from 'lucide-react'
import { useState } from 'react'

import { LogoutButton } from '@/components/auth/logout-button'
import { Link, usePathname } from '@/i18n/navigation'
import { cn } from '@/lib/utils'

interface NavLabels {
  dashboard: string
  searches: string
  account: string
  admin: string
  logout: string
  menu: string
}

export function AppNav({
  userEmail,
  userName,
  isAdmin,
  labels,
}: {
  userEmail: string
  userName: string | null
  isAdmin: boolean
  labels: NavLabels
}) {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  const items = [
    { href: '/dashboard', label: labels.dashboard, icon: HomeIcon },
    { href: '/searches', label: labels.searches, icon: SearchIcon },
    { href: '/account', label: labels.account, icon: SettingsIcon },
    ...(isAdmin ? [{ href: '/admin', label: labels.admin, icon: ShieldIcon }] : []),
  ]

  // `/searches/new` should still light up the "searches" tab, so a prefix match
  // is used rather than equality — except for the dashboard, which would then
  // match everything.
  const isActive = (href: string) =>
    href === '/dashboard' ? pathname === href : pathname.startsWith(href)

  return (
    <header className="border-border bg-background/95 supports-[backdrop-filter]:bg-background/80 sticky top-0 z-40 border-b backdrop-blur">
      <div className="mx-auto flex h-14 max-w-5xl items-center gap-4 px-4 sm:px-6">
        <Link href="/dashboard" className="text-primary text-base font-bold tracking-tight">
          WoningAlert
        </Link>

        <nav className="hidden flex-1 items-center gap-1 sm:flex">
          {items.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'rounded-md px-3 py-1.5 text-sm font-medium transition-colors',
                isActive(item.href)
                  ? 'bg-accent text-accent-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent/50',
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto hidden items-center gap-3 sm:flex">
          <span className="text-muted-foreground max-w-[16rem] truncate text-sm">
            {userName ?? userEmail}
          </span>
          <LogoutButton />
        </div>

        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          aria-expanded={open}
          aria-label={labels.menu}
          className="hover:bg-accent ml-auto rounded-md p-2 sm:hidden"
        >
          {open ? <XIcon className="size-5" /> : <MenuIcon className="size-5" />}
        </button>
      </div>

      {open ? (
        <div className="border-border border-t sm:hidden">
          <nav className="mx-auto max-w-5xl space-y-1 px-4 py-3">
            {items.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className={cn(
                  'flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium',
                  isActive(item.href)
                    ? 'bg-accent text-accent-foreground'
                    : 'text-muted-foreground hover:bg-accent/50',
                )}
              >
                <item.icon className="size-4" />
                {item.label}
              </Link>
            ))}
            <div className="border-border mt-2 flex items-center justify-between border-t pt-3">
              <span className="text-muted-foreground truncate text-sm">{userEmail}</span>
              <LogoutButton />
            </div>
          </nav>
        </div>
      ) : null}
    </header>
  )
}
