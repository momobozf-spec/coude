'use client'

import { useId } from 'react'

import { cn } from '@/lib/utils'

/**
 * A native checkbox with our styling.
 *
 * The search profile form has roughly twenty of these. A native input submits
 * its value inside a plain form post, works before hydration, and needs no
 * hidden mirror input the way a Radix checkbox does — which matters on a form
 * this size.
 */
export function CheckField({
  name,
  label,
  hint,
  defaultChecked,
  disabled,
  value = 'on',
  className,
}: {
  name: string
  label: React.ReactNode
  hint?: string
  defaultChecked?: boolean
  disabled?: boolean
  value?: string
  className?: string
}) {
  const id = useId()

  return (
    <div className={cn('flex items-start gap-2.5', className)}>
      <input
        type="checkbox"
        id={id}
        name={name}
        value={value}
        defaultChecked={defaultChecked}
        disabled={disabled}
        className={cn(
          'border-input text-primary accent-primary mt-0.5 size-4 shrink-0 cursor-pointer rounded-[4px] border shadow-xs',
          'focus-visible:ring-ring/50 focus-visible:ring-[3px] focus-visible:outline-none',
          'disabled:cursor-not-allowed disabled:opacity-50',
        )}
      />
      <div className="min-w-0">
        <label
          htmlFor={id}
          className={cn(
            'cursor-pointer text-sm leading-relaxed select-none',
            disabled && 'text-muted-foreground cursor-not-allowed',
          )}
        >
          {label}
        </label>
        {hint ? <p className="text-muted-foreground mt-0.5 text-xs">{hint}</p> : null}
      </div>
    </div>
  )
}

/** Same styling, but a radio for mutually exclusive choices. */
export function RadioField({
  name,
  label,
  value,
  defaultChecked,
  onChange,
}: {
  name: string
  label: React.ReactNode
  value: string
  defaultChecked?: boolean
  onChange?: (value: string) => void
}) {
  const id = useId()

  return (
    <div className="flex items-center gap-2.5">
      <input
        type="radio"
        id={id}
        name={name}
        value={value}
        defaultChecked={defaultChecked}
        onChange={(event) => onChange?.(event.target.value)}
        className={cn(
          'border-input accent-primary size-4 shrink-0 cursor-pointer border shadow-xs',
          'focus-visible:ring-ring/50 focus-visible:ring-[3px] focus-visible:outline-none',
        )}
      />
      <label htmlFor={id} className="cursor-pointer text-sm select-none">
        {label}
      </label>
    </div>
  )
}
