'use client'

import { AlertCircleIcon, CheckCircle2Icon } from 'lucide-react'
import { useTranslations } from 'next-intl'

import { Alert, AlertDescription } from '@/components/ui/alert'
import { Label } from '@/components/ui/label'
import type { AccountFormState } from '@/server/account/actions'

export const initialAccountFormState: AccountFormState = { status: 'idle' }

export function AccountFormFeedback({ state }: { state: AccountFormState }) {
  const t = useTranslations('account.messages')

  if (state.status === 'idle' || !state.message) return null

  const isSuccess = state.status === 'success'

  return (
    <Alert variant={isSuccess ? 'success' : 'destructive'}>
      {isSuccess ? <CheckCircle2Icon /> : <AlertCircleIcon />}
      <AlertDescription>{t(state.message)}</AlertDescription>
    </Alert>
  )
}

export function AccountField({
  label,
  hint,
  errors,
  children,
}: {
  label: string
  hint?: string
  errors?: string[]
  children: React.ReactNode
}) {
  const t = useTranslations('account.fieldErrors')

  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
      {hint ? <p className="text-muted-foreground text-xs">{hint}</p> : null}
      {errors?.length ? (
        <ul className="text-destructive space-y-0.5 text-sm">
          {errors.map((key) => (
            <li key={key}>{t(key)}</li>
          ))}
        </ul>
      ) : null}
    </div>
  )
}
