'use client'

import { useActionState } from 'react'
import { useTranslations } from 'next-intl'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { locales, localeLabels, type Locale } from '@/i18n/routing'
import { updateProfileAction } from '@/server/account/actions'

import { AccountField, AccountFormFeedback, initialAccountFormState } from './account-form-parts'

export function ProfileForm({
  name,
  email,
  locale,
  phoneNumber,
}: {
  name: string | null
  email: string
  locale: Locale
  phoneNumber: string | null
}) {
  const t = useTranslations('account')
  const [state, formAction, pending] = useActionState(updateProfileAction, initialAccountFormState)

  return (
    <form action={formAction} className="space-y-4" noValidate>
      <AccountFormFeedback state={state} />

      <AccountField label={t('profile.emailLabel')} hint={t('profile.emailHint')}>
        {/* Changing an e-mail address means re-verifying it and re-pointing every
            alert already queued for it. That flow is deliberately not part of
            this form. */}
        <Input value={email} readOnly disabled className="opacity-70" />
      </AccountField>

      <AccountField label={t('profile.nameLabel')} errors={state.fieldErrors?.name}>
        <Input name="name" defaultValue={name ?? ''} maxLength={120} />
      </AccountField>

      <AccountField label={t('profile.localeLabel')} hint={t('profile.localeHint')}>
        <Select name="locale" defaultValue={locale}>
          {locales.map((candidate) => (
            <option key={candidate} value={candidate}>
              {localeLabels[candidate]}
            </option>
          ))}
        </Select>
      </AccountField>

      <AccountField
        label={t('profile.phoneLabel')}
        hint={t('profile.phoneHint')}
        errors={state.fieldErrors?.phoneNumber}
      >
        <Input
          name="phoneNumber"
          type="tel"
          inputMode="tel"
          placeholder="+32470123456"
          defaultValue={phoneNumber ?? ''}
        />
      </AccountField>

      <Button type="submit" disabled={pending}>
        {pending ? t('common.saving') : t('common.save')}
      </Button>
    </form>
  )
}
