'use client'

import { useActionState } from 'react'
import { useTranslations } from 'next-intl'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { changePasswordAction } from '@/server/account/actions'

import { AccountField, AccountFormFeedback, initialAccountFormState } from './account-form-parts'

export function PasswordForm() {
  const t = useTranslations('account')
  const [state, formAction, pending] = useActionState(changePasswordAction, initialAccountFormState)

  return (
    <form action={formAction} className="space-y-4" noValidate>
      <AccountFormFeedback state={state} />

      <p className="text-muted-foreground text-sm">{t('password.explanation')}</p>

      <AccountField
        label={t('password.currentLabel')}
        errors={state.fieldErrors?.currentPassword}
      >
        <Input name="currentPassword" type="password" autoComplete="current-password" required />
      </AccountField>

      <AccountField
        label={t('password.newLabel')}
        hint={t('password.newHint')}
        errors={state.fieldErrors?.newPassword}
      >
        <Input
          name="newPassword"
          type="password"
          autoComplete="new-password"
          minLength={10}
          required
        />
      </AccountField>

      <AccountField
        label={t('password.confirmLabel')}
        errors={state.fieldErrors?.newPasswordConfirm}
      >
        <Input name="newPasswordConfirm" type="password" autoComplete="new-password" required />
      </AccountField>

      <Button type="submit" disabled={pending}>
        {pending ? t('common.saving') : t('password.submit')}
      </Button>
    </form>
  )
}
