'use client'

import { LockIcon } from 'lucide-react'
import { useActionState } from 'react'
import { useTranslations } from 'next-intl'

import { Button } from '@/components/ui/button'
import { CheckField } from '@/components/ui/check-field'
import { Input } from '@/components/ui/input'
import { updateNotificationPreferencesAction } from '@/server/account/actions'

import { AccountField, AccountFormFeedback, initialAccountFormState } from './account-form-parts'

export interface PreferenceValues {
  emailEnabled: boolean
  whatsappEnabled: boolean
  smsEnabled: boolean
  marketingEmailEnabled: boolean
  quietHoursStart: number | null
  quietHoursEnd: number | null
  maxAlertsPerDay: number | null
  digestMode: boolean
}

export function NotificationPreferencesForm({
  values,
  allowedChannels,
  configuredChannels,
}: {
  values: PreferenceValues
  allowedChannels: string[]
  configuredChannels: string[]
}) {
  const t = useTranslations('account')
  const [state, formAction, pending] = useActionState(
    updateNotificationPreferencesAction,
    initialAccountFormState,
  )

  const channelState = (channel: string) => {
    const planAllows = allowedChannels.includes(channel)
    const providerReady = configuredChannels.includes(channel)
    return {
      disabled: !planAllows || !providerReady,
      hint: !planAllows
        ? t('notifications.channelLocked')
        : !providerReady
          ? t('notifications.channelNotConfigured')
          : undefined,
    }
  }

  const whatsapp = channelState('WHATSAPP')
  const sms = channelState('SMS')

  return (
    <form action={formAction} className="space-y-5" noValidate>
      <AccountFormFeedback state={state} />

      <div className="space-y-2">
        <CheckField
          name="emailEnabled"
          defaultChecked={values.emailEnabled}
          label={t('notifications.emailLabel')}
        />
        <CheckField
          name="whatsappEnabled"
          defaultChecked={values.whatsappEnabled && !whatsapp.disabled}
          disabled={whatsapp.disabled}
          label={
            <span className="inline-flex items-center gap-1.5">
              {t('notifications.whatsappLabel')}
              {whatsapp.disabled ? <LockIcon className="size-3" aria-hidden="true" /> : null}
            </span>
          }
          {...(whatsapp.hint ? { hint: whatsapp.hint } : {})}
        />
        <CheckField
          name="smsEnabled"
          defaultChecked={values.smsEnabled && !sms.disabled}
          disabled={sms.disabled}
          label={
            <span className="inline-flex items-center gap-1.5">
              {t('notifications.smsLabel')}
              {sms.disabled ? <LockIcon className="size-3" aria-hidden="true" /> : null}
            </span>
          }
          {...(sms.hint ? { hint: sms.hint } : {})}
        />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <AccountField
          label={t('notifications.quietStartLabel')}
          errors={state.fieldErrors?.quietHoursStart}
        >
          <Input
            name="quietHoursStart"
            type="number"
            min={0}
            max={23}
            defaultValue={values.quietHoursStart ?? ''}
          />
        </AccountField>
        <AccountField label={t('notifications.quietEndLabel')}>
          <Input
            name="quietHoursEnd"
            type="number"
            min={0}
            max={23}
            defaultValue={values.quietHoursEnd ?? ''}
          />
        </AccountField>
      </div>
      <p className="text-muted-foreground -mt-3 text-xs">{t('notifications.quietHint')}</p>

      <AccountField
        label={t('notifications.maxPerDayLabel')}
        hint={t('notifications.maxPerDayHint')}
      >
        <Input
          name="maxAlertsPerDay"
          type="number"
          min={1}
          max={500}
          defaultValue={values.maxAlertsPerDay ?? ''}
        />
      </AccountField>

      <div className="space-y-2">
        <CheckField
          name="digestMode"
          defaultChecked={values.digestMode}
          label={t('notifications.digestLabel')}
          hint={t('notifications.digestHint')}
        />
        <CheckField
          name="marketingEmailEnabled"
          defaultChecked={values.marketingEmailEnabled}
          label={t('notifications.marketingLabel')}
          hint={t('notifications.marketingHint')}
        />
      </div>

      <Button type="submit" disabled={pending}>
        {pending ? t('common.saving') : t('common.save')}
      </Button>
    </form>
  )
}
