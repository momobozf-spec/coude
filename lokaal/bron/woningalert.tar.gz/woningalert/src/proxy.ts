import createIntlMiddleware from 'next-intl/middleware'
import { NextResponse, type NextRequest } from 'next/server'

import { routing } from '@/i18n/routing'

const intlMiddleware = createIntlMiddleware(routing)

const isProduction = process.env.NODE_ENV === 'production'

/**
 * Content-Security-Policy (REQUIREMENTS §24).
 *
 * `unsafe-inline` for styles is required by Tailwind's runtime-injected styles
 * and by Leaflet, which sets inline transforms on every tile. Scripts do NOT
 * get `unsafe-inline`: Next.js is given a per-request nonce instead.
 *
 * OpenStreetMap tile hosts are allowed in `img-src` because the map renders
 * tiles from them directly; that is the documented OSM usage.
 */
function buildCsp(nonce: string): string {
  const directives: Record<string, string[]> = {
    'default-src': ["'self'"],
    'script-src': [
      "'self'",
      `'nonce-${nonce}'`,
      "'strict-dynamic'",
      // Next.js injects an inline bootstrap script in development.
      ...(isProduction ? [] : ["'unsafe-eval'", "'unsafe-inline'"]),
    ],
    'style-src': ["'self'", "'unsafe-inline'"],
    'img-src': [
      "'self'",
      'data:',
      'blob:',
      'https://*.tile.openstreetmap.org',
      'https://unpkg.com',
      'https://api.mapbox.com',
    ],
    'font-src': ["'self'", 'data:'],
    'connect-src': [
      "'self'",
      'https://*.tile.openstreetmap.org',
      'https://api.mapbox.com',
      'https://*.ingest.sentry.io',
      'https://*.ingest.de.sentry.io',
      ...(isProduction ? [] : ['ws:', 'wss:']),
    ],
    'frame-ancestors': ["'none'"],
    'form-action': ["'self'"],
    'base-uri': ["'self'"],
    'object-src': ["'none'"],
  }

  if (isProduction) {
    directives['upgrade-insecure-requests'] = []
  }

  return Object.entries(directives)
    .map(([key, values]) => (values.length ? `${key} ${values.join(' ')}` : key))
    .join('; ')
}

function applySecurityHeaders(response: NextResponse, nonce: string): NextResponse {
  response.headers.set('Content-Security-Policy', buildCsp(nonce))
  response.headers.set('X-Content-Type-Options', 'nosniff')
  response.headers.set('X-Frame-Options', 'DENY')
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin')
  response.headers.set(
    'Permissions-Policy',
    'camera=(), microphone=(), geolocation=(self), interest-cohort=()',
  )
  if (isProduction) {
    response.headers.set(
      'Strict-Transport-Security',
      'max-age=63072000; includeSubDomains; preload',
    )
  }
  return response
}

/**
 * Next 16 renamed the `middleware` file convention to `proxy`. This runs on
 * every non-API request: it resolves the locale and stamps the security
 * headers from REQUIREMENTS §24 onto the response.
 */
export default function proxy(request: NextRequest): NextResponse {
  const nonce = Buffer.from(crypto.randomUUID()).toString('base64')

  const requestHeaders = new Headers(request.headers)
  requestHeaders.set('x-nonce', nonce)

  const response = intlMiddleware(request)
  response.headers.set('x-nonce', nonce)

  return applySecurityHeaders(response, nonce)
}

export const config = {
  // Everything except API routes, Next.js internals and static files. API routes
  // are excluded on purpose: they must never be locale-redirected, and they set
  // their own headers.
  matcher: ['/((?!api|_next|_vercel|.*\\..*).*)'],
}
