/**
 * A PostgreSQL for local development, without Docker.
 *
 * docker-compose.yml is the documented path and works everywhere Docker runs.
 * This script exists for machines where Docker Desktop is not installed or not
 * allowed: `embedded-postgres` unpacks a real PostgreSQL binary into `.devdb/`
 * and starts it on its own port. Same engine as production, no installation.
 *
 * Deliberately a different port (5433) from the docker-compose service (5432).
 * Anyone who ever starts both then gets an explicit DATABASE_URL choice instead
 * of a silent connection to the wrong database.
 *
 * Run `npm run dev:db` in its own terminal and leave it open. Ctrl-C stops it
 * cleanly; the data in `.devdb/` survives.
 */
import path from 'node:path'

import EmbeddedPostgres from 'embedded-postgres'

const DATABASE_DIR = path.resolve(process.cwd(), '.devdb')
const PORT = 5433
const USER = 'woningalert'
const PASSWORD = 'woningalert'
const DATABASE = 'woningalert'

const CONNECTION_STRING = `postgresql://${USER}:${PASSWORD}@localhost:${PORT}/${DATABASE}?schema=public`

async function main(): Promise<void> {
  const postgres = new EmbeddedPostgres({
    databaseDir: DATABASE_DIR,
    user: USER,
    password: PASSWORD,
    port: PORT,
    // The data directory persists between sessions; otherwise every restart
    // would be an empty database and a fresh migration run.
    persistent: true,
    /**
     * Without these flags `initdb` inherits the system locale. On a Dutch
     * Windows install that is `Dutch_Belgium.1252`, giving the cluster WIN1252
     * encoding. That looks fine for a long time and then breaks on exactly the
     * wrong row — a municipality called Liège, or a price delta written with a
     * real minus sign:
     *
     *     character with byte sequence 0xe2 0x88 0x92 has no equivalent in
     *     encoding "WIN1252"
     *
     * In a Belgian product serving three languages, UTF-8 is a requirement, not
     * a preference. docker-compose uses it by default and the development
     * database must not quietly differ.
     *
     * `--locale=C` is needed because initdb refuses UTF-8 encoding combined
     * with a 1252 locale. Collation order does not matter here: everything that
     * gets sorted is normalised in the application first.
     */
    initdbFlags: ['--encoding=UTF8', '--locale=C'],
  })

  // `initialise` is idempotent enough: on an existing data directory it skips.
  // The error is swallowed because its wording differs per platform and a
  // second start should not look like a failure.
  try {
    await postgres.initialise()
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    if (!/exists|not empty|already/i.test(message)) throw error
  }

  await postgres.start()

  try {
    await postgres.createDatabase(DATABASE)
    console.log(`Database "${DATABASE}" created.`)
  } catch {
    // Already existed — the normal case on every start after the first.
  }

  console.log('')
  console.log('  PostgreSQL is running for development.')
  console.log('')
  console.log('  Put this in your .env:')
  console.log('')
  console.log(`  DATABASE_URL=${CONNECTION_STRING}`)
  console.log('')
  console.log('  Then, in a second terminal:')
  console.log('    npm run db:migrate')
  console.log('    npm run dev')
  console.log('')
  console.log('  Leave this terminal open. Ctrl-C stops the database.')
  console.log('')

  let stopping = false
  const stop = async (signal: string): Promise<void> => {
    if (stopping) return
    stopping = true
    console.log(`\nStopping PostgreSQL (${signal})…`)
    await postgres.stop()
    process.exit(0)
  }

  process.on('SIGINT', () => void stop('SIGINT'))
  process.on('SIGTERM', () => void stop('SIGTERM'))

  // Keep the process alive.
  await new Promise<void>(() => {})
}

main().catch((error: unknown) => {
  console.error('Failed to start the development database:', error)
  process.exit(1)
})
