# Gap-analyse — REQUIREMENTS.md tegenover de codebase

Bijgewerkt aan het einde van **fase 2**.

Dit is de traceability-matrix tussen de 42 secties van
[REQUIREMENTS.md](../REQUIREMENTS.md) en wat er daadwerkelijk in de repository
staat. Hij wordt aan het einde van elke fase bijgewerkt.

## Uitgangspositie

Er was geen bestaande code voor dit product. De repository `coude/` bevat wel
drie verwante projecten die zijn geïnspecteerd voordat er iets gebouwd werd:

| Project | Wat het is | Wat is overgenomen |
| --- | --- | --- |
| `huiszoeker/` | Vastgoedzoeker op Fastify + CLI. Bevat bronnenonderzoek per portaal (robots.txt-analyse) en een Prisma 7-opzet. | Het Prisma 7-patroon (`prisma.config.ts` + driver adapter) en het juridische denkkader voor bronnen. |
| `immoradar-belgium/` | Acquisitie-intelligentie voor makelaars (Next.js). Ander product, ander datamodel. | Het `embedded-postgres` dev-databasescript, inclusief de UTF-8/`initdb`-les. |
| `halal-home/`, `fsbo-lead-radar/` | Niet-verwante producten. | Niets. |

Er is **niets gewijzigd** aan die projecten (§41: breek geen werkende
functionaliteit).

## Status per sectie

Legenda: **DONE** = gebouwd en geverifieerd · **PARTIAL** = gedeeltelijk, rest
gepland · **TODO** = nog niet begonnen · **CONFIG** = code compleet, wacht op
credentials

| § | Onderwerp | Status na fase 2 | Waar / geplande fase |
| --- | --- | --- | --- |
| 1 | Productdoel | PARTIAL | Accounts en zoekprofielen werken; ingestion en alerts fases 3–4 |
| 2 | Alleen legale bronnen | TODO | `docs/sources.md`, fase 3 |
| 3 | Geen demodata in productie | DONE | `prisma/seed.ts` bevat alleen referentiedata; geen fixture raakt productie |
| 4 | Account & authenticatie | **DONE** | `src/server/auth/**` — end-to-end aangetoond (zie PROGRESS.md) |
| 5 | Zoekprofielen | **DONE** | Alle filters uit §5, Zod-gevalideerd, CRUD met eigenaarschap in de WHERE-clause |
| 6 | Ingestion / connector-interface | TODO | Fase 3 |
| 7 | Crawler & scheduler | PARTIAL | Redis + worker-lifecycle staan; queues fase 3 |
| 8 | Canonical property model | PARTIAL | Schema **DONE** (Property + PropertyOccurrence + blocking keys); gebruik fase 3 |
| 9 | Deduplicatie | TODO | Ontworpen in `architecture.md` §5.2; fase 3 |
| 10 | Matching engine | TODO | Ontworpen in `architecture.md` §5.3; fase 3 |
| 11 | Alerts via echte providers | TODO | Fase 4 |
| 12 | Notification pipeline | TODO | Fase 4 |
| 13 | Latency meten | TODO | Fase 3 (stempels) / fase 6 (p50-p95) |
| 14 | User dashboard | PARTIAL | dashboard, zoekopdrachten, account, notificatievoorkeuren **DONE**; matches en detailpagina fase 3, billing fase 5 |
| 15 | Property status & prijshistoriek | PARTIAL | Schema **DONE** (7 statussen + PriceHistory); logica fase 3 |
| 16 | Kaart | TODO | Fase 3; Leaflet + OSM, Mapbox optioneel |
| 17 | Betalingen (Mollie) | TODO | Fase 5 |
| 18 | Entitlements server-side | **DONE** | Elke mutatie via `assertEntitlement`; limieten en kanalen server-side afgedwongen en met integratietests bewezen |
| 19 | Payment webhooks | TODO | Fase 5 |
| 20 | Admin platform | TODO | Fase 6 |
| 21 | Observability | PARTIAL | `pino` + correlation IDs + `/api/health` **DONE**; Sentry fase 6 |
| 22 | Database | **DONE** | 25 modellen, 14 enums, indexes/constraints/cascades, migratie toegepast |
| 23 | Performance | PARTIAL | Ontworpen (blocking keys, queues); meetbaar vanaf fase 3 |
| 24 | Security | PARTIAL | CSP/HSTS/headers, Zod-validatie, rate limiting, lockout, RBAC-guards **DONE**; dependency-audit in CI. Rate limiting nog niet live getest (geen Redis) |
| 25 | GDPR | TODO | Fase 6 |
| 26 | Transactionele e-mails | PARTIAL | verificatie, welkom, reset, wachtwoord-gewijzigd **gebouwd** (NL/FR/EN, HTML+tekst); betaal- en alertmails fase 4–5 |
| 27 | UX/UI | PARTIAL | Design tokens, 11 UI-primitieven, app-shell met mobiele navigatie, alle schermen mobile-first; matches/kaart fase 3 |
| 28 | Landingpage | PARTIAL | Echte hero-copy uit de spec staat er; volledige pagina fase 6 |
| 29 | i18n NL/FR/EN | DONE | `next-intl`, drie bundels, sleutelpariteit afgedwongen door een test |
| 30 | Deployment | PARTIAL | `Dockerfile`, `Dockerfile.worker`, `docker-compose.yml` geschreven; **niet lokaal gebouwd** (geen Docker op deze machine), CI bouwt ze |
| 31 | CI/CD | DONE | `.github/workflows/ci.yml`: verify, integration, docker, security |
| 32 | Migrations | **DONE** | `docs/migrations.md` + eerste migratie; `db:deploy` in CI |
| 33 | Testing | PARTIAL | **106 unit + 44 integration** tests groen; E2E (Playwright) fase 6 |
| 34 | Configuration | DONE | Volledige `.env.example`, Zod-gevalideerd in `src/lib/env.ts` |
| 35 | Source configuration | PARTIAL | Naamconventie voor credentials vastgelegd; tabellen fase 3 |
| 36 | Launch readiness | TODO | Fase 6 |
| 37 | Backups | TODO | Fase 6 |
| 38 | Analytics | TODO | Fase 6 |
| 39 | Productiestatus in README | PARTIAL | `INTEGRATIONS.md` bestaat en is bijgewerkt; README-tabel groeit mee |
| 40 | Definition of Done | PARTIAL | typecheck/lint/unit/**integration**/build groen; authenticatie, database en migraties afgevinkt |
| 41 | Werkwijze | DONE | Bestaande projecten geïnspecteerd, niets gebroken, ADR's in `docs/decisions/` |
| 42 | Volgorde van aanpak | DONE | Audit → architectuur → gap-analyse → fasering; bouwen begonnen |

## Openstaande risico's

1. **Bronnen (§2, §6, §40).** De DoD eist "minstens één daadwerkelijk
   configureerbare legitieme property source connector". Welke Nederlandse of
   Belgische bron een officiële API, RSS of expliciet toegestane feed biedt is
   nog niet onderzocht. Dit is het grootste inhoudelijke risico van het project
   en het eerste werk van fase 3, vóór er een regel connector-code geschreven
   wordt. Uitkomst komt in `docs/sources.md`.
2. ~~**Auth.js v5 beta tegen Next.js 16.**~~ **Opgelost in fase 1.** De
   combinatie werkt: registratie, login, sessie-uitlezing en server-side
   intrekking zijn over echte HTTP aangetoond. Het blijft een
   beta-afhankelijkheid, dus een versie-upgrade vraagt een eigen CI-run. Zie
   [ADR-0005](./decisions/0005-jwt-sessions-with-a-revocation-registry.md).
3. **Docker onverifieerbaar op deze machine.** De images zijn geschreven maar
   nergens gebouwd. Dat gebeurt pas in CI. Zie
   [ADR-0003](./decisions/0003-local-development-without-docker.md).
4. **Redis lokaal.** Vereist Docker, WSL2 of een managed instance. Zonder Redis
   werkt de worker niet en meldt `/api/health` dat eerlijk.
5. **Image fingerprinting (§9).** Genoemd als "indien mogelijk". Nog geen
   aanpak gekozen; de dedup-scorer is zo opgezet dat er een feature bij kan
   zonder de andere gewichten te herzien.
