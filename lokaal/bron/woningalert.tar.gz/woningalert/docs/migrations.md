# Migraties

REQUIREMENTS §32. Kort samengevat: **`prisma migrate`, nooit `prisma db push`
naar productie.**

`db push` vergelijkt het schema met de database en past het verschil toe, zonder
migratiebestand en zonder historie. Dat is prima voor wegwerp-experimenten en
onbruikbaar voor een systeem met klantdata: er is geen review, geen
reproduceerbaarheid, en geen weg terug.

---

## Een wijziging doorvoeren

```bash
# 1. Pas prisma/schema.prisma aan.

# 2. Genereer en pas de migratie toe op je lokale database.
npm run db:migrate
#    Prisma vraagt om een naam. Gebruik een beschrijvende:
#    add_property_duplicate_audit, not update_schema.

# 3. LEES prisma/migrations/<timestamp>_<naam>/migration.sql.
#    Dit is de belangrijkste stap. Prisma genereert soms een DROP waar je een
#    RENAME bedoelde, en dat merk je hier of in productie.

# 4. Commit het migratiebestand samen met de schemawijziging.
#    Een schemawijziging zonder migratie is een kapotte deploy.
```

## Naar productie

```bash
npm run db:deploy      # prisma migrate deploy
```

`deploy` past alleen bestaande migratiebestanden toe. Hij genereert nooit iets,
vraagt nooit iets, en raakt niets aan wat niet in `prisma/migrations/` staat.
Dat is precies wat je in een CI/CD-pipeline wilt.

**Volgorde bij een deploy:** eerst migreren, dan de nieuwe code uitrollen. Zorg
dus dat elke migratie compatibel is met de *vorige* versie van de code — zie
"Onvermijdelijk brekende wijzigingen" hieronder.

### Gepoolde databases (Neon, Supabase, PgBouncer)

`prisma migrate` werkt niet betrouwbaar door een connection pooler heen: hij
gebruikt advisory locks en sessie-state die een pooler niet doorgeeft. Zet
`DATABASE_URL` bij het migreren daarom op de **directe** verbinding:

```bash
DATABASE_URL="$DIRECT_DATABASE_URL" npm run db:deploy
```

De applicatie zelf blijft de gepoolde URL gebruiken.

---

## Terugdraaien

Prisma heeft geen `migrate down`. Dat is een bewuste keuze van Prisma en het
betekent dat rollback iets is wat je *plant*, niet iets wat je *aanroept*.

**Voorkeursvolgorde bij een probleem in productie:**

1. **Roll forward.** Schrijf een nieuwe migratie die het probleem herstelt. Dit
   is bijna altijd het juiste antwoord: de database blijft vooruit bewegen en de
   historie blijft kloppen.
2. **Herstel uit een backup** als er data verloren of corrupt is. Zie
   [backups.md](./backups.md) voor de procedure en de RPO.
3. **Handmatige SQL** alleen als laatste redmiddel, en dan altijd gevolgd door
   `prisma migrate resolve` zodat Prisma's `_prisma_migrations`-tabel weer
   klopt met de werkelijkheid.

Een half toegepaste migratie markeer je als teruggedraaid met:

```bash
npx prisma migrate resolve --rolled-back <migratienaam>
```

en als toegepast (wanneer je hem handmatig hebt uitgevoerd) met:

```bash
npx prisma migrate resolve --applied <migratienaam>
```

---

## Onvermijdelijk brekende wijzigingen

Een kolom hernoemen of verwijderen breekt de draaiende oude code tijdens de
deploy. Doe dat daarom in drie releases (expand-migrate-contract):

| Release | Migratie | Code |
| --- | --- | --- |
| 1 | Voeg de nieuwe kolom toe, nullable | Schrijft naar oud **en** nieuw |
| 2 | Backfill de nieuwe kolom | Leest nieuw, schrijft beide |
| 3 | Verwijder de oude kolom | Gebruikt alleen nieuw |

Sneller is verleidelijk en kost je een storing tijdens elke rolling deploy.

---

## Seed

```bash
npm run db:seed
```

`prisma/seed.ts` zet **uitsluitend referentiedata** neer: abonnementsplannen en
de registratie van bekende bronnen. Hij is idempotent en veilig om tegen
productie te draaien.

Er komt **nooit** een fictieve woning, gebruiker, betaling of statistiek in een
seed (§3). Testdata staat in `tests/fixtures/` en wordt alleen door de
testomgeving geladen.

---

## Testdatabase

Integratietests draaien tegen een echte PostgreSQL, in een eigen database zodat
ze je ontwikkeldata niet aanraken:

```bash
# Eenmalig aanmaken (naast npm run dev:db op poort 5433)
DATABASE_URL="postgresql://woningalert:woningalert@localhost:5433/woningalert_test?schema=public" \
  npm run db:deploy

# Draaien
DATABASE_URL="postgresql://woningalert:woningalert@localhost:5433/woningalert_test?schema=public" \
  npm run test:integration
```

In CI gebeurt dit automatisch met een PostgreSQL service container; zie
`.github/workflows/ci.yml`.
