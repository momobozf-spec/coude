# WoningAlert — architectuur

Dit document legt vast *waarom* het systeem is zoals het is. De *hoe* staat in de
code. Het is bindend voor alle volgende fases; afwijkingen krijgen een ADR in
[decisions/](./decisions/).

Referenties naar `§n` verwijzen naar de secties in [REQUIREMENTS.md](../REQUIREMENTS.md).

---

## 1. Processen

Het platform draait als **twee processen uit één codebase**:

| Proces | Entrypoint | Verantwoordelijkheid | Schaalt |
| --- | --- | --- | --- |
| `web` | `next start` | UI, auth, API routes, webhooks | horizontaal, stateless |
| `worker` | `tsx src/worker/main.ts` | BullMQ workers + scheduler | horizontaal, altijd aan |

De reden voor de splitsing staat in §30: de crawler mag **niet** afhankelijk zijn
van de serverless request-lifecycle. Een Vercel function wordt afgekapt zodra het
antwoord verstuurd is; een crawl die 40 seconden duurt of een retry over 10
minuten past daar niet in. De worker is daarom een gewoon, langlevend Node-proces
met een eigen container.

Beide processen delen `src/` — dezelfde Prisma-client, dezelfde connectors,
dezelfde matching-engine. Er is geen aparte package en geen monorepo; zie
[ADR-0001](./decisions/0001-single-package-two-processes.md).

---

## 2. Datastores

| Store | Rol |
| --- | --- |
| PostgreSQL | System of record. Alles wat overleeft. |
| Redis | BullMQ queues, distributed locks, rate-limit buckets, worker-heartbeat. |

Redis bevat **geen** data die niet opnieuw op te bouwen is. Een lege Redis kost
één gemiste polling-cyclus, geen datacorruptie.

---

## 3. Queues

BullMQ, één Redis-connection per proces, queue-namen met prefix `wa:`.

| Queue | Producer | Payload | Concurrency |
| --- | --- | --- | --- |
| `source-poll` | repeatable scheduler | `{ sourceId }` | 1 per bron (lock) |
| `listing-ingest` | source-poll | `{ sourceId, crawlerRunId, raw }` | `WORKER_CONCURRENCY` |
| `property-match` | listing-ingest | `{ propertyId, reason }` | `WORKER_CONCURRENCY` |
| `notification-send` | property-match | `{ notificationId }` | `WORKER_CONCURRENCY` |
| `maintenance` | repeatable (nachtelijk) | `{ task }` | 1 |

Elke queue heeft een dead-letter queue `wa:<naam>:dlq`. Een job die alle retries
opgebruikt wordt daarheen verplaatst mét de laatste fout, zodat een admin hem kan
inspecteren en opnieuw kan aanbieden (§7, §20).

**Waarom queues per stap en niet één grote job:** een bron die 500 listings
teruggeeft mag niet één job van tien minuten worden. Faalt listing 480, dan zou
de hele run opnieuw moeten. Nu faalt precies één listing, en de andere 499 zijn
al verwerkt.

---

## 4. Scheduler en distributed safety (§7)

De scheduler is een BullMQ *repeatable job* per ingeschakelde bron, met het
interval uit `PropertySourceConfig.pollIntervalSeconds`. Bij het opstarten
synchroniseert de worker de repeatable jobs met de database: bronnen die
uitgezet zijn verliezen hun schedule, gewijzigde intervallen worden herschreven.

Vier verdedigingslagen tegen dubbel werk, elk tegen een ander faalscenario:

1. **Repeatable job key** — BullMQ zorgt dat er nooit twee schedules voor
   dezelfde bron bestaan. Beschermt tegen: twee workers die beide bij het
   opstarten een schedule aanmaken.
2. **Redis lock per bron** (`SET wa:lock:source:<id> <token> NX PX <ttl>`) —
   beschermt tegen: een tweede worker die dezelfde poll-job pakt terwijl de
   eerste nog bezig is (bijvoorbeeld na een netwerkhapering).
3. **Unique constraint `(sourceId, externalId)` op `PropertyOccurrence`** —
   beschermt tegen: dezelfde advertentie twee keer importeren. Dit is de laatste
   en enige echt harde garantie, want hij zit in de database.
4. **Unique constraint `(searchProfileId, propertyId, kind)` op `Notification`** —
   beschermt tegen: dezelfde gebruiker drie keer dezelfde woning mailen (§12).

Laag 1 en 2 zijn optimalisaties; laag 3 en 4 zijn de garantie. Dat onderscheid is
belangrijk: Redis mag omvallen zonder dat er duplicaten in de database komen.

**Backoff, jitter, circuit breaker.** Retries zijn exponentieel met volle jitter
(`random(0, base * 2^n)`), begrensd op `maxRetries` uit de bronconfiguratie.
Jitter voorkomt dat vijf bronnen na een netwerkstoring synchroon terugkomen. De
circuit breaker leeft in `SourceHealth`: na N opeenvolgende fouten gaat de bron
`OPEN` en worden polls overgeslagen tot de cooldown voorbij is, daarna één
`HALF_OPEN` proefpoging.

---

## 5. Ingestion-pipeline (§6, §8, §9, §10)

```
   repeatable schedule
          │
          ▼
   ┌─────────────┐   lock + breaker + rate limit
   │ source-poll │──────────────────────────────┐
   └─────────────┘                              │
          │ connector.fetchListings()           │  CrawlerRun
          │                                     │  (fetched/inserted/
          ▼                                     │   updated/duplicates/
   ┌────────────────┐                           │   failures/rateLimited)
   │ listing-ingest │ ◄─────── één job per listing
   └────────────────┘
          │ 1. connector.normalize()  → CanonicalListing (Zod)
          │ 2. dedup                  → duplicateProbability 0-100
          │ 3. persist                → Property + PropertyOccurrence
          │ 4. status/prijs-diff      → PropertyPriceHistory
          ▼
   ┌────────────────┐
   │ property-match │ ◄─────── alleen bij nieuw of relevant gewijzigd
   └────────────────┘
          │ 1. kandidaat-SearchProfiles (geïndexeerde prefilter)
          │ 2. harde filters          → pass/fail
          │ 3. score 0-100            → per-dimensie breakdown
          │ 4. PropertyMatch upsert
          │ 5. entitlement-check      → welke kanalen mag deze user?
          ▼
   ┌───────────────────┐
   │ notification-send │
   └───────────────────┘
```

### 5.1 Connector-interface (§6)

```ts
interface PropertySourceConnector {
  readonly sourceId: string
  readonly capabilities: ConnectorCapabilities
  validateConfiguration(config: SourceConfig): ValidationResult
  healthCheck(ctx: ConnectorContext): Promise<HealthCheckResult>
  fetchListings(ctx: ConnectorContext): Promise<RawListingPage>
  fetchListingDetails(ctx: ConnectorContext, ref: ListingRef): Promise<RawListing>
  normalize(raw: RawListing): NormalizeResult
}
```

Connectors zijn **puur**: ze krijgen een context (http-client met rate limiter,
logger, config, credentials) en raken de database niet aan. Dat maakt ze
testbaar met fixtures zonder database, en het maakt de persist-logica één keer
geschreven in plaats van per bron.

`normalize()` geeft een `NormalizeResult` terug, geen exception: een listing die
niet te normaliseren valt levert `{ ok: false, reason }` en telt op in
`CrawlerRun.failures` zonder de hele run te laten klappen.

De registry (`src/connectors/registry.ts`) koppelt `sourceId` aan een
implementatie. Configuratie en aan/uit staan in de database
(`PropertySource` + `PropertySourceConfig`); credentials staan **alleen** in
environment variables, opgehaald via de naamconventie uit `.env.example` (§35).
Geen enkele credential wordt in de database opgeslagen.

### 5.2 Deduplicatie (§9)

Naïef elke listing tegen elke andere vergelijken is O(n²). In plaats daarvan
worden bij het normaliseren drie **blocking keys** berekend en geïndexeerd:

| Key | Samenstelling | Vangt |
| --- | --- | --- |
| `blockAddress` | `country + postalCode + genormaliseerd huisnummer` | exacte adresmatch |
| `blockGeo` | lat/lon afgerond op ±150 m raster | adres anders geschreven, coördinaten gelijk |
| `blockAttributes` | `country+city+propertyType+listingType+bedrooms+round(livingArea/5)` | geen adres bekend (komt veel voor bij huur) |

Kandidaten = alle properties die minstens één blocking key delen, binnen een
prijsband en niet ouder dan 90 dagen. Op die kleine set draait de scorer:

| Feature | Gewicht | Vergelijking |
| --- | --- | --- |
| adres | 30 | exact / fuzzy op genormaliseerde straat |
| postcode + huisnummer | 20 | exact |
| geo-afstand | 15 | afstand → score, 0 m = 15, >500 m = 0 |
| prijs | 15 | relatieve afwijking |
| oppervlakte | 10 | relatieve afwijking |
| slaapkamers | 5 | exact |
| titel-similariteit | 5 | token-set ratio |

Totaal = `duplicateProbability` (0-100). Drempels:

- `>= 85` → automatisch samenvoegen: nieuwe `PropertyOccurrence` op de bestaande
  `Property`.
- `60-84` → apart opslaan én `PropertyDuplicateAudit` met status `REVIEW`, zodat
  een admin het kan beoordelen. Er wordt niet automatisch samengevoegd, want een
  fout-positief laat een gebruiker een échte woning missen.
- `< 60` → nieuwe `Property`.

Elke beslissing, ook `< 60` als er kandidaten waren, schrijft een
`PropertyDuplicateAudit` met de per-feature bijdragen. Dat is de auditinformatie
die §9 vraagt, en het is de enige manier om de drempels later te kunnen
bijstellen op echte data.

Image fingerprinting (§9) staat in de interface maar is nog niet
geïmplementeerd; zie [gap-analysis.md](./gap-analysis.md).

### 5.3 Matching (§10)

Harde filters eerst (land, gemeente/straal, listingType, propertyType, prijs,
minimum slaapkamers/oppervlakte, uitgesloten keywords). Valt de woning daar af,
dan is er geen match — punt. Pas daarna een gewogen score over vijf dimensies:
locatie, prijs, slaapkamers, oppervlakte, extra voorkeuren.

De score wordt opgeslagen als `PropertyMatch.scoreBreakdown` (JSON) plus
`matchReasons` (vertaalbare sleutels met parameters), zodat de UI kan tonen
*waarom* iets matcht zonder de score opnieuw te berekenen.

---

## 6. Latency (§13)

Zes tijdstempels per listing, verspreid over drie tabellen:

| Stempel | Tabel |
| --- | --- |
| `sourcePublishedAt`, `detectedAt` | `PropertyOccurrence` |
| `processedAt` | `Property` |
| `matchedAt` | `PropertyMatch` |
| `notificationQueuedAt`, `notificationSentAt` | `Notification` |

Afgeleide latencies worden niet opgeslagen maar berekend, zodat er geen tweede
waarheid ontstaat. Het admin-dashboard draait één aggregatiequery met
`percentile_cont` voor p50/p95.

---

## 7. Notificaties (§11, §12)

Eén `NotificationChannelProvider` interface, drie implementaties: Resend
(e-mail), Twilio (SMS + optioneel WhatsApp), Meta Cloud API (WhatsApp).
`WHATSAPP_PROVIDER` kiest welke WhatsApp-implementatie geladen wordt; zie
[ADR-0004](./decisions/0004-whatsapp-provider.md).

Lifecycle `QUEUED → SENDING → SENT → DELIVERED` met `FAILED`/`RETRYING`. Elke
poging is een eigen `NotificationAttempt`-rij met provider, `providerMessageId`,
foutcode en kosten. Kosten per bericht komen uit de provider-response, zodat
SMS-uitgaven meetbaar zijn (§11).

`DELIVERED` komt binnen via provider-webhooks (Resend, Twilio status callback,
Meta webhook), elk met signatuurverificatie.

---

## 8. Entitlements (§18)

Plannen staan in de database (`PlanConfig`) zodat prijzen en limieten
admin-configureerbaar zijn (§17), met een code-default als de tabel leeg is. Elke
beschermde handeling roept `assertEntitlement(session, capability)` aan in de
server-laag — nooit alleen in de UI. De UI *verbergt* wat niet mag; de server
*weigert* het.

---

## 9. Security (§24)

- CSP, HSTS (alleen productie), `X-Content-Type-Options`, `Referrer-Policy` via
  `middleware.ts`.
- Sessiecookies: `httpOnly`, `secure` in productie, `sameSite=lax`.
- Elke route-input door een Zod-schema; het schema is de enige bron van waarheid
  voor het type.
- RBAC: `USER` / `ADMIN` op `User.role`; admin-routes achter een layout-guard
  *en* een server-side check per action.
- Rate limiting op Redis (token bucket) voor login, registratie, wachtwoord-reset
  en publieke API-routes.
- Webhooks: Mollie via fetch-back, Resend via svix-signatuur, Twilio via
  `X-Twilio-Signature`, Meta via `X-Hub-Signature-256`.
- Logs redacten `authorization`, `cookie`, `token`, `apiKey`, `password` in de
  logger-configuratie, niet op de call-site — vergeten redacten wordt zo
  onmogelijk.

---

## 10. i18n (§29)

`next-intl` met een `[locale]`-segment. `nl` is default en fallback; `fr` en `en`
zijn volwaardig. Berichten in `src/i18n/messages/<locale>.json`. Matchredenen en
notificatietemplates gebruiken dezelfde sleutels, zodat een Franstalige gebruiker
ook een Franstalige alert krijgt.

---

## 11. Wat expliciet níet gebouwd wordt

- **Geen eigen scraper die ToS schendt.** Bronnen worden per stuk juridisch
  beoordeeld in [sources.md](./sources.md). Een bron zonder toegestane
  toegangsweg wordt niet geïmplementeerd, ook niet "tijdelijk".
- **Geen seed met fictieve woningen.** `prisma/seed.ts` zet uitsluitend
  referentiedata (plannen, bronregistraties) neer. Fixtures voor tests staan in
  `tests/fixtures/` en komen nooit in een productiedatabase (§3, §32).
- **Geen volledige overname van advertentieteksten.** De property-detailpagina
  toont een ingekorte omschrijving en linkt door naar de bron (§14).
