# ADR-0003 — Lokale ontwikkeling zonder Docker

**Status:** geaccepteerd — fase 0
**Context:** REQUIREMENTS §30 (docker-compose voor lokale ontwikkeling)

## Context

`docker-compose.yml` is geleverd zoals de spec vraagt. Op de ontwikkelmachine
waarop dit project is opgezet is **geen Docker geïnstalleerd** (`docker
--version` → niet gevonden). Zonder alternatief zou fase 0 niet lokaal
verifieerbaar zijn.

## Beslissing

Twee wegen naar dezelfde engines, allebei gedocumenteerd:

| | PostgreSQL | Redis |
| --- | --- | --- |
| **Met Docker** | `docker compose up -d db` (poort 5432) | `docker compose up -d redis` (poort 6379) |
| **Zonder Docker** | `npm run dev:db` — `embedded-postgres` pakt een echte PostgreSQL uit in `.devdb/` (poort **5433**) | geen npm-equivalent; zie hieronder |

### PostgreSQL

`embedded-postgres` draait dezelfde engine als productie, alleen zonder
installatie. Bewust een andere poort (5433) dan docker-compose (5432), zodat wie
beide ooit tegelijk start een expliciete `DATABASE_URL`-keuze krijgt in plaats
van een stille verbinding met de verkeerde database.

`initdbFlags: ['--encoding=UTF8', '--locale=C']` is niet optioneel. Zonder die
vlaggen neemt `initdb` de systeemlocale over; op een Nederlandstalige Windows is
dat `Dutch_Belgium.1252` en krijgt de cluster WIN1252 als encoding. Dat gaat
lang goed en breekt dan op Liège of op een prijsverschil met een echt minteken.
In een Belgisch product met drie talen is UTF-8 een vereiste.

### Redis

Er is geen betrouwbaar Windows-equivalent van `embedded-postgres` voor Redis.
BullMQ werkt niet tegen `ioredis-mock` — de blocking commands en Lua-scripts die
BullMQ gebruikt zijn daar niet geïmplementeerd. Een in-memory nep-Redis inbouwen
zou bovendien precies het soort mock zijn dat §3 verbiedt.

Drie werkende opties, in volgorde van voorkeur, staan in de README:

1. **Docker** (`docker compose up -d redis`) — als het beschikbaar is.
2. **WSL2** (`sudo apt install redis-server`) — op Windows de eenvoudigste
   echte Redis.
3. **Managed Redis met gratis tier** (Upstash, Redis Cloud) — werkt vanaf elke
   machine, geen installatie; zet `REDIS_URL` op de meegeleverde `rediss://`-URL.

## Gevolgen

- De worker en alle queue-functionaliteit vereisen een bereikbare Redis. Zonder
  Redis start `npm run worker` niet, en meldt `/api/health` `worker: down`. Dat
  is correct gedrag, geen bug.
- CI heeft dit probleem niet: GitHub Actions levert Postgres en Redis als
  service containers.
- De Docker-images zijn geschreven maar **niet lokaal gebouwd** — er is geen
  Docker om het mee te doen. De CI-job `docker` bouwt beide images op elke pull
  request; dat is de eerste plek waar ze echt geverifieerd worden.
