# ADR-0005 — JWT-sessies met een intrekbare sessieregistratie

**Status:** geaccepteerd — fase 1
**Context:** REQUIREMENTS §4 ("sessies beheren"), §24

## Het probleem

Twee eisen uit §4 spreken elkaar op het eerste gezicht tegen:

1. Inloggen met **e-mail en wachtwoord**.
2. **Sessies beheren** — zien waar je ingelogd bent en een apparaat uitloggen.

Auth.js dwingt bij een Credentials-provider de **JWT-strategie** af; database-
sessies zijn dan niet beschikbaar. En een JWT is per definitie niet in te
trekken: eenmaal uitgegeven is hij geldig tot hij verloopt, waar hij ook is.

Zonder oplossing zou "wachtwoord wijzigen" een gestolen laptop niet uitloggen —
precies het scenario waarvoor die knop bestaat.

## Beslissing

De JWT draagt een `sid` die verwijst naar een rij in de bestaande
`Session`-tabel. Bij **elke** sessie-uitlezing controleert de `jwt`-callback of
die rij nog bestaat en niet verlopen is; zo niet, dan geeft hij `null` terug en
is de sessie voorbij.

- **Uitloggen** verwijdert de rij (`signOut`-event).
- **Wachtwoord resetten** verwijdert álle rijen van de gebruiker.
- **"Overal uitloggen"** en de sessielijst in het account lezen dezelfde tabel.

## Kosten

Eén geïndexeerde lookup per sessie-uitlezing. Dat is de prijs van intrekbaarheid
en hij is het waard: het alternatief is een token dat na een wachtwoordwijziging
nog dagen geldig blijft.

Bewust **niet** geoptimaliseerd met een controle "elke N minuten". Dat zou
betekenen dat "log dit apparaat uit" tot N minuten niets doet, en dan is de knop
een belofte die je niet nakomt.

## Bijwerkingen

- `isSessionValid()` **faalt open** als de database onbereikbaar is. Een
  databasehapering mag niet iedereen uitloggen; de JWT is dan nog steeds
  ondertekend en niet verlopen, dus het ergste geval is dat een intrekking een
  moment later effect heeft.
- De sessierij bewaart `userAgent` en `ipAddress`, zodat een gebruiker zijn
  eigen sessies kan herkennen. Dat zijn persoonsgegevens: ze verdwijnen mee bij
  accountverwijdering (cascade) en bij het opruimen van verlopen sessies.
- `Session` wordt niet meer door de Auth.js-adapter beheerd — bij de
  JWT-strategie raakt die de tabel niet aan. Wij zijn de enige schrijver.

## Waarom niet anders

**Eigen sessielaag zonder Auth.js.** Dan verlies je de OAuth-afhandeling,
account-linking en de CSRF-bescherming van Auth.js, om precies het stuk zelf te
schrijven dat het meest fout kan gaan. De twee zusterprojecten in deze
repository doen dat wel, en de reden is daar dat ze geen OAuth nodig hebben.

**Alleen korte JWT-levensduur.** Een token van vijf minuten met refresh
verkleint het venster maar sluit het niet, en verplaatst het probleem naar het
refresh-token — dat je dan alsnog moet kunnen intrekken.
