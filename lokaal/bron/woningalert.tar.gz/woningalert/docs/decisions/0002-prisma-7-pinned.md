# ADR-0002 — Prisma vastgezet op 7.10.0

**Status:** geaccepteerd — fase 0
**Context:** REQUIREMENTS §22, §32

## Beslissing

`prisma` en `@prisma/client` staan vast op **7.10.0**. De `latest`-tag op npm
wees op het moment van bouwen naar `8.0.0-rc.12`.

## Waarom

`npm view prisma version` gaf `8.0.0-rc.12` — een release candidate, geen stable.
Voor een applicatie die betalende klanten gaat bedienen is een rc als
databaselaag geen verantwoorde keuze: breaking changes zijn nog toegestaan en
migratiepaden liggen nog niet vast.

7.10.0 is de hoogste stabiele versie (`dist-tags.prev` voor de CLI,
`dist-tags.latest` voor `@prisma/client`).

## Gevolgen

Prisma 7 wijkt op twee punten af van wat online veel voorbeelden nog laten zien:

1. **De connectie-URL staat niet meer in `schema.prisma`.** De CLI leest hem uit
   `prisma.config.ts`; de runtime-client krijgt een driver-adapter
   (`@prisma/adapter-pg`) mee. Dat is geen workaround maar het bedoelde model —
   en het levert direct iets op: de migratie-URL en de runtime-URL mógen
   verschillen, wat nodig is bij een gepoolde Postgres (Neon, Supabase,
   PgBouncer).
2. **De generator heet `prisma-client`** (niet `prisma-client-js`) en schrijft
   naar `src/generated/prisma`. Die map staat in `.gitignore` en wordt door
   `npm run build` en CI opnieuw gegenereerd.

Bij een upgrade naar Prisma 8 hoort een eigen ADR en een eigen CI-run; dit is
geen versie die je en passant meeneemt.
