# ADR-0004 — WhatsApp via Twilio als standaard, Meta Cloud API als alternatief

**Status:** geaccepteerd — fase 0
**Context:** REQUIREMENTS §11 ("Meta WhatsApp Cloud API of Twilio WhatsApp")

## Beslissing

Beide worden gebouwd achter één `NotificationChannelProvider`-interface.
`WHATSAPP_PROVIDER` (`none` | `twilio` | `meta`) bepaalt welke implementatie
geladen wordt. **Twilio is de aanbevolen standaard** voor de eerste livegang.

## Waarom Twilio de standaard is

1. **SMS is er toch al.** §11 eist ook SMS, en Twilio is daarvoor de voor de
   hand liggende keuze. Eén provider voor SMS én WhatsApp betekent één account,
   één factuur, één set credentials, één signatuurverificatie
   (`X-Twilio-Signature`) en één statuscallback-formaat. Meta erbij nemen
   verdubbelt dat zonder dat er functionaliteit bijkomt.
2. **Onboarding.** Meta's Cloud API vereist een geverifieerd Meta Business
   account, een WhatsApp Business Account, een gekoppeld telefoonnummer en
   goedkeuring van elk template afzonderlijk. Twilio's WhatsApp-sandbox laat je
   dezelfde code end-to-end testen voordat er iets goedgekeurd is.
3. **Kosten meten.** §11 eist meetbare kosten. Twilio geeft per bericht een
   `price` en `price_unit` terug in de Message-resource; die worden opgeslagen
   op `NotificationAttempt`. Meta rapporteert kosten per conversatie, achteraf,
   via een apart analytics-endpoint — niet per bericht, dus niet direct
   toewijsbaar aan één alert.

## Waarom Meta er tóch in zit

Bij volume wordt Meta's Cloud API duidelijk goedkoper: Twilio rekent zijn eigen
marge bovenop het WhatsApp-conversatietarief. Wie honderdduizenden alerts per
maand stuurt, wil kunnen overstappen zonder de notificatiepijplijn te herbouwen.

Daarom is de keuze een configuratievariabele, geen herschrijving. Beide
implementaties leveren dezelfde lifecycle (`QUEUED → SENDING → SENT →
DELIVERED`), dezelfde `providerMessageId` en dezelfde foutcodes richting de rest
van het systeem.

## Gevolgen

- Beide implementaties worden volledig gebouwd inclusief webhook-verificatie:
  Twilio via `X-Twilio-Signature` (HMAC-SHA1 over URL + gesorteerde parameters),
  Meta via `X-Hub-Signature-256` (HMAC-SHA256 over de ruwe body met het app
  secret).
- WhatsApp blijft **CONFIGURATION REQUIRED** tot er credentials én een
  goedgekeurd template zijn. Een goedgekeurd template is geen formaliteit: buiten
  het 24-uurs servicevenster weigert WhatsApp elk bericht dat geen template is,
  en een woningalert valt per definitie buiten dat venster.
- `WHATSAPP_PROVIDER=none` is de default. Het kanaal is dan niet selecteerbaar in
  de UI — niet zichtbaar-maar-kapot.
