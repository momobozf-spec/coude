# ADR-0001 — Eén package, twee processen (geen monorepo)

**Status:** geaccepteerd — fase 0
**Context:** REQUIREMENTS §30 (worker los van serverless lifecycle)

## Beslissing

Het project is één npm-package met twee entrypoints:

- `next start` → de webapplicatie
- `tsx src/worker/main.ts` → de altijd-aan worker

Geen workspaces, geen `packages/*`, geen aparte `@woningalert/core`.

## Waarom

De spec eist dat de crawler **niet** afhangt van een serverless request. Dat is
een eis over *processen*, niet over *packages*. Twee processen uit één package
voldoen er volledig aan.

Een monorepo zou hier kosten opleveren zonder opbrengst:

- De worker en de webapp delen bijna alles: Prisma-client, connectors, matching,
  entitlements, notificatietemplates. In een monorepo zou vrijwel alle code in
  één gedeeld package belanden en zouden de twee "apps" schillen van tien regels
  zijn. Dan is de packagegrens administratie, geen architectuur.
- Eén `package.json` betekent één versie van `@prisma/client` in beide
  processen. Bij losse packages is versiedrift tussen worker en web een reëel en
  vervelend te vinden probleem: de worker schrijft dan een kolom weg die de
  webapp niet kent.
- Eén lockfile, één CI-install, één Docker build cache.

## Gevolgen

- `tsx` staat in `dependencies`, niet in `devDependencies`: het productie-image
  van de worker draait TypeScript rechtstreeks. Kosten: ~10 MB in het image.
  Alternatief was de worker bundelen met esbuild, wat een extra buildstap en
  een tweede klasse runtime-problemen (native modules, Prisma-engine paden)
  introduceert voor winst die we niet nodig hebben.
- Code die alleen de server mag raken importeert géén `server-only`: dat pakket
  gooit buiten een React-servercontext en zou de worker breken. De scheiding is
  conventie (`src/server/**` is server-side) plus het feit dat `process.env`
  client-side toch leeg is.
- Wordt de worker ooit een eigen deploy-artefact met een eigen releasecyclus,
  dan is opsplitsen alsnog mogelijk. Nu vooruitlopen kost meer dan het later
  doen.
