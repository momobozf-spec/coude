import { defineConfig } from 'vitest/config'

// `.mts` on purpose: this file uses ESM syntax and the package is CommonJS, so
// a plain `.ts` extension makes Vite's native config loader warn.
export default defineConfig({
  resolve: {
    // Vite resolves the `@/*` paths from tsconfig.json natively; the
    // vite-tsconfig-paths plugin is no longer needed.
    tsconfigPaths: true,
  },
  test: {
    projects: [
      {
        resolve: { tsconfigPaths: true },
        test: {
          name: 'unit',
          include: ['tests/unit/**/*.test.ts'],
          environment: 'node',
        },
      },
      {
        resolve: { tsconfigPaths: true },
        test: {
          name: 'integration',
          include: ['tests/integration/**/*.test.ts'],
          environment: 'node',
          // Integration tests talk to a real PostgreSQL and Redis; they are
          // slower than unit tests and run serially to keep the schema stable.
          fileParallelism: false,
          hookTimeout: 120_000,
          testTimeout: 60_000,
          setupFiles: ['tests/integration/setup.ts'],
        },
      },
    ],
  },
})
