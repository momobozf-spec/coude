import 'dotenv/config'
import { defineConfig, env } from 'prisma/config'

/**
 * Read only by the Prisma CLI (migrate, studio, db execute).
 *
 * The application never uses this file: `src/server/db.ts` builds its own
 * driver adapter. Keeping the two apart means a pooled runtime URL and a direct
 * migration URL can differ without the app knowing about it — point
 * DATABASE_URL at the direct connection when running migrations against a
 * pooled Postgres (Neon, Supabase, PgBouncer).
 */
export default defineConfig({
  schema: 'prisma/schema.prisma',
  migrations: {
    path: 'prisma/migrations',
    seed: 'tsx prisma/seed.ts',
  },
  datasource: {
    url: env('DATABASE_URL'),
  },
})
