# PROGRESS

Bijgehouden per fase. Een verse sessie kan hieruit exact opmaken waar het werk staat.

**Laatst bijgewerkt:** einde fase 2
**Bouwmachine:** Windows 11, Node 24.19.0, npm 11.17.0, **geen Docker**

---

## Fase 0 — Audit & fundament · **DONE**

### Wat er gebouwd is

| Onderdeel | Bestand(en) |
| --- | --- |
| Repository-audit + gap-analyse | `docs/gap-analysis.md` |
| Architectuurdocument | `docs/architecture.md` |
| ADR's | `docs/decisions/0001` t/m `0005` |
| Projectstructuur + tooling | `tsconfig.json` (strict + `noUncheckedIndexedAccess`), `eslint.config.mjs`, `vitest.config.mts`, `playwright.config.ts` |
| Env-validatie | `src/lib/env.ts` — Zod, faalt bij boot, plus `integrations` voor eerlijke LIVE/CONFIG-status |
| Structured logging | `src/lib/logger.ts` — pino, redaction in de config, correlation IDs via `AsyncLocalStorage` |
| Database-laag | `prisma.config.ts`, `src/server/db.ts` (Prisma 7 + driver adapter) |
| Redis-laag | `src/server/redis.ts` — gedeelde client + aparte BullMQ-connecties |
| Health endpoint | `src/server/health.ts`, `src/app/api/health/route.ts` |
| Worker-proces | `src/worker/main.ts` — identiteit, heartbeat, graceful shutdown |
| Security headers | `src/proxy.ts` — CSP met nonce, HSTS, X-Frame-Options, Permissions-Policy |
| i18n NL/FR/EN | `src/i18n/**` — next-intl, `nl` default zonder prefix |
| Docker | `Dockerfile`, `Dockerfile.worker`, `docker-compose.yml`, `.dockerignore` |
| Dev-database zonder Docker | `scripts/dev-db.ts` — embedded-postgres op poort 5433 |
| CI | `.github/workflows/ci.yml` — verify, integration, docker, security |
| Configuratie | `.env.example` (volledig, §34) |

### Verificatie-gate

| Stap | Resultaat |
| --- | --- |
| `npm run typecheck` | PASS |
| `npm run lint` | PASS |
| `npm run test:unit` | PASS |
| `npm run build` | PASS |
| App draait lokaal | PASS — `/` → NL, `/fr` → FR, security headers aanwezig |
| `/api/health` | PASS — 503 met per-component status; `database => ok` tegen `npm run dev:db` |
| `npm run dev:db` | PASS — embedded PostgreSQL op poort 5433 |

---

## Fase 1 — Database & auth · **DONE**

### Wat er gebouwd is

| Onderdeel | Bestand(en) |
| --- | --- |
| Volledig Prisma-schema (§22) | `prisma/schema.prisma` — 25 modellen, 14 enums, alle indexes/constraints/cascades |
| Eerste migratie | `prisma/migrations/20260829010540_init/` |
| Migratieworkflow | `docs/migrations.md` — inclusief rollback en expand-migrate-contract |
| Wachtwoorden | `src/server/auth/password.ts` — bcrypt cost 12, lengte-eerst beleid, timing-equalisatie |
| Eenmalige tokens | `src/server/auth/tokens.ts` — SHA-256 gehasht opgeslagen, nooit in de klare |
| Rate limiting | `src/server/auth/rate-limit.ts` — Redis Lua (INCR+EXPIRE atomair), faalt open |
| Account-lockout | `User.failedLoginAttempts` / `lockedUntil`, oplopende duur |
| Sessieregistratie | `src/server/auth/session-registry.ts` — intrekbare JWT-sessies (ADR-0005) |
| Auth.js-configuratie | `src/server/auth/config.ts` — Credentials + Google (conditioneel) |
| Toegangscontrole | `src/server/auth/guards.ts` — `requireUser`, `requireAdmin` |
| Accountlogica | `src/server/auth/service.ts` — registratie, verificatie, reset |
| Server actions | `src/server/auth/actions.ts` — Zod-gevalideerd, vertaalsleutels als antwoord |
| Transactionele e-mail | `src/server/email/**` — Resend, eigen i18n (werkt ook in de worker) |
| UI | `src/components/ui/**` (7 primitieven), `src/components/auth/**` (7 formulieren) |
| Pagina's | login, register, forgot-password, reset-password, verify-email, dashboard |

### Verificatie-gate

| Stap | Resultaat |
| --- | --- |
| `npm run typecheck` | PASS |
| `npm run lint` | PASS |
| `npm run test:unit` | PASS — **66 tests** (wachtwoordbeleid, tokens, schema's, e-mailtemplates, i18n-pariteit) |
| `npm run test:integration` | PASS — **22 tests** tegen echte PostgreSQL |
| `npm run build` | PASS |

### End-to-end aangetoond (echte HTTP, echte database)

| Wat | Uitkomst |
| --- | --- |
| Registratie | User + NotificationPreference + FREE-abonnement in één transactie |
| Wachtwoordopslag | bcrypt-hash, klare tekst nergens |
| Tokenopslag | alleen SHA-256 hash; databaselees-toegang activeert geen account |
| Inloggen (juist wachtwoord) | 302 + sessiecookie; `/api/auth/session` geeft rol, taal, verificatiestatus |
| Inloggen (fout wachtwoord) | 302 met `code=INVALID_CREDENTIALS`, geen sessie, `failedLoginAttempts` → 1 |
| `/dashboard` zonder sessie | 307 → `/login?callbackUrl=%2Fdashboard` |
| **Sessie intrekken** | rij verwijderd → dezelfde cookie geeft `null` en `/dashboard` redirect |
| Wachtwoord resetten | nieuw wachtwoord actief, lockout gewist, **alle** sessies ingetrokken |

### Bewust zo, geen bug

- **Verificatiemails worden als `FAILED` vastgelegd** met `EMAIL_NOT_CONFIGURED`
  zolang er geen `RESEND_API_KEY` is. Niets wordt als verzonden gepresenteerd
  dat een provider niet heeft geaccepteerd (§11). In *development* schrijft de
  logger de link erbij, zodat een verse kloon kan registreren zonder
  Resend-account; in productie is het een harde fout.
- **Google OAuth-knop wordt niet getoond** zolang de keys ontbreken. Geen knop
  die faalt bij het indrukken (§39).
- **Registratie verklapt nooit of een adres al bestaat.** Bestaand adres levert
  exact dezelfde uitkomst op; alleen de mail die de adres-eigenaar krijgt
  verschilt.

### Wat expliciet NIET geverifieerd is

- **Docker-images zijn nooit gebouwd** — geen Docker op deze machine. De CI-job
  `docker` doet dat bij de eerste push. §40's "Docker werkt" is **onbevestigd**.
- **De CI-workflow heeft nooit gedraaid** — er is nog geen GitHub-remote.
- **Redis is nergens bereikbaar op deze machine.** Rate limiting is daardoor
  niet live getest; de code faalt open (bewust — zie `rate-limit.ts`) en de
  account-lockout in de database is wél getest en werkt.
- **Google OAuth-flow is niet doorlopen** — geen credentials.
- **Resend is niet aangeroepen** — geen API-key.

### Credentials die ik nog van je nodig heb

Om fase 2 af te ronden: geen. Om deze fase van CONFIGURATION REQUIRED naar LIVE
te brengen: `RESEND_API_KEY` + `EMAIL_FROM` (e-mail) en optioneel
`GOOGLE_CLIENT_ID` + `GOOGLE_CLIENT_SECRET`. Zie `INTEGRATIONS.md`.

---

## Fase 2 — Zoekprofielen & dashboard-basis · **DONE**

### Wat er gebouwd is

| Onderdeel | Bestand(en) |
| --- | --- |
| Plandefinities (§17) | `src/server/entitlements/plans.ts` — prijzen in centen, limieten, kanalen |
| Entitlements (§18) | `src/server/entitlements/index.ts` — `PlanConfig` uit de database met code-defaults als vangnet |
| Zoekprofiel-validatie (§5) | `src/server/search-profiles/schemas.ts` — alle filters, cross-field regels |
| Zoekprofiel-CRUD | `src/server/search-profiles/service.ts` — eigenaarschap in de WHERE-clause |
| Server actions | `src/server/search-profiles/actions.ts` |
| Kanaalbeschikbaarheid (§39) | `src/server/search-profiles/channels.ts` |
| Accountbeheer (§4) | `src/server/account/{service,actions}.ts` |
| Provincies BE/NL (§5) | `src/lib/regions.ts` — drietalige labels |
| App-shell + navigatie | `src/app/[locale]/(app)/layout.tsx`, `src/components/app/app-nav.tsx` |
| Pagina's | dashboard, searches, searches/new, searches/[id], account |
| UI-primitieven | textarea, select, badge, check-field (native, submit zonder JS) |

### Verificatie-gate

| Stap | Resultaat |
| --- | --- |
| `npm run typecheck` | PASS |
| `npm run lint` | PASS |
| `npm run test:unit` | PASS — **106 tests** (+40: plandefinities, zoekprofiel-schema) |
| `npm run test:integration` | PASS — **44 tests** (+22: CRUD, plangrenzen, eigenaarschap) |
| `npm run build` | PASS — 32 routes |

### End-to-end aangetoond (ingelogd, echte database)

| Wat | Uitkomst |
| --- | --- |
| `/dashboard`, `/searches`, `/searches/new`, `/account` | alle vier HTTP 200 |
| Lege staat | "Nog geen woningbronnen actief.", "Je hebt nog geen zoekopdracht", "0 van 1 zoekopdrachten gebruikt" — geen verzonnen data |
| Kanaalvergrendeling | WhatsApp en SMS zichtbaar maar uitgeschakeld, mét de juiste reden ("Beschikbaar met Premium" vs "Nog niet beschikbaar") |
| Franse versie | `/fr/searches/new` rendert Franse labels |
| Plangrens | tweede zoekopdracht op FREE wordt server-side geweigerd (integratietest) |
| Eigenaarschap | profiel van gebruiker A is voor gebruiker B onvindbaar, niet-bewerkbaar en niet-verwijderbaar (integratietest) |
| Downgrade | bewerken blijft mogelijk; niet-toegestane kanalen worden stilzwijgend weggelaten in plaats van de opslag te weigeren |

### Bewust zo, geen bug

- **Twee verschillende redenen dat een kanaal uitstaat**, en de UI zegt welke:
  het plan staat het niet toe (opwaarderen helpt) of de provider is niet
  geconfigureerd (opwaarderen helpt niet). Eén generieke "niet beschikbaar" zou
  de gebruiker laten betalen voor iets dat daarna nog steeds niet werkt.
- **Een downgrade weigert de opslag niet.** Anders kan iemand die terugvalt naar
  gratis zijn zoekopdracht helemaal niet meer bewerken.
- **Kaartgebied (bounds) staat wel in het schema maar nog niet in het
  formulier.** §5 noemt dit "indien haalbaar"; het wordt in fase 3 uit de kaart
  gezet, niet met de hand ingetypt.

### Wat expliciet NIET geverifieerd is

- **Formulier-submits zijn niet via de browser getest.** De actielogica is wél
  gedekt door 22 integratietests op de servicelaag, en de pagina's renderen
  aantoonbaar. De echte klik-door-de-UI-test is de Playwright E2E van fase 6.
- Docker, CI, Redis, Google OAuth en Resend: onveranderd sinds fase 1 (zie daar).

---

---

## Fase 3 — Ingestion, dedup & matching · **NEXT**

Eerste werk van deze fase is **bronnenonderzoek** (`docs/sources.md`) vóór er een
regel connector-code geschreven wordt. Dat is het grootste inhoudelijke risico
van het project: de DoD eist minstens één werkende, legitieme bron.

Daarna: connector-interface en registry (§6), BullMQ-scheduler met locks,
backoff, DLQ en circuit breaker (§7), deduplicatie met blocking keys (§9),
matching-engine met uitlegbare score (§10), latency-stempels (§13), en de
matches- en detailpagina's (§14) inclusief kaart (§16).

**Hiervoor is Redis nodig** — zie INTEGRATIONS.md voor de drie manieren om er
een te krijgen.

## Fase 4 — Notificaties · TODO
## Fase 5 — Payments & entitlements · TODO
## Fase 6 — Admin, observability, i18n, launch · TODO
