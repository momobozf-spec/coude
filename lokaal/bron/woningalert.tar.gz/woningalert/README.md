# WoningAlert

**Woningalerts voor België en Nederland.**

Eén zoekopdracht in plaats van tien tabbladen. WoningAlert verzamelt nieuwe
woningadvertenties uit meerdere legitieme bronnen, normaliseert ze, haalt
duplicaten eruit en waarschuwt je zodra er iets voorbijkomt dat bij je
zoekprofiel past — per e-mail, WhatsApp of SMS.

> **Status: in aanbouw.** Fase 0 (fundament), fase 1 (database + accounts) en
> fase 2 (zoekprofielen + dashboard) zijn afgerond. Je kunt registreren, je
> e-mailadres bevestigen, in- en uitloggen, je wachtwoord herstellen,
> zoekopdrachten aanmaken en beheren, en je account- en notificatievoorkeuren
> instellen. Woningbronnen komen in fase 3 — tot dan komen er dus nog geen
> matches binnen.
>
> Zie [PROGRESS.md](PROGRESS.md) voor wat er precies staat en
> [INTEGRATIONS.md](INTEGRATIONS.md) voor de eerlijke status per externe
> integratie. Er draait nog **geen enkele woningbron**: de UI meldt dan ook
> *"Nog geen woningbronnen actief."* in plaats van verzonnen woningen te tonen.
>
> Om verificatiemails daadwerkelijk te versturen heb je een `RESEND_API_KEY`
> nodig. Zonder die key legt het systeem elke poging eerlijk vast als mislukt en
> schrijft het de link in development naar de log.

---

## Snel starten

Je hebt **Node 20+** nodig (ontwikkeld op 24.19). Er zijn twee wegen; kies er één.

### Met Docker

```bash
cp .env.example .env
# vul AUTH_SECRET:  openssl rand -base64 32

docker compose up -d db redis
npm install
npm run db:migrate
npm run dev
```

### Zonder Docker

`npm run dev:db` pakt een echte PostgreSQL uit in `.devdb/` en start hem op
poort **5433**. Handig op machines waar Docker niet draait of niet mag.

```bash
cp .env.example .env
npm install
npm run dev:db          # laat deze terminal open staan
```

Zet in een tweede terminal de `DATABASE_URL` uit de uitvoer in je `.env`:

```
DATABASE_URL=postgresql://woningalert:woningalert@localhost:5433/woningalert?schema=public
```

en dan:

```bash
npm run db:migrate
npm run dev
```

**Redis heb je apart nodig** — er is geen npm-equivalent dat BullMQ aankan.
Kies: `docker compose up -d redis`, WSL2 (`sudo apt install redis-server`), of
een gratis managed instance (Upstash, Redis Cloud). Zonder Redis werkt de app,
maar niet de crawler. Zie
[ADR-0003](docs/decisions/0003-local-development-without-docker.md).

Open <http://localhost:3000>.

### De worker

De crawler draait in een **apart, langlevend proces** — bewust niet in een
serverless request:

```bash
npm run worker
```

`/api/health` meldt `worker => down` zolang dit niet draait. Dat is correct
gedrag, geen bug.

---

## Scripts

| Script | Doet |
| --- | --- |
| `npm run dev` | Next.js in ontwikkelmodus |
| `npm run build` | `prisma generate` + productiebuild |
| `npm run start` | Productieserver |
| `npm run worker` | De always-on worker (queues, scheduler) |
| `npm run dev:db` | Lokale PostgreSQL zonder Docker |
| `npm run db:migrate` | Nieuwe migratie maken en toepassen (ontwikkeling) |
| `npm run db:deploy` | Migraties toepassen (productie) |
| `npm run db:studio` | Prisma Studio |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run lint` | ESLint |
| `npm run test` | Unit tests |
| `npm run test:integration` | Integration tests (vereist PostgreSQL + Redis) |
| `npm run test:e2e` | Playwright end-to-end |
| `npm run verify` | Alles achter elkaar: schema, typecheck, lint, tests, build |

---

## Status van externe integraties

Volledige uitleg, inclusief waar je elke credential haalt, staat in
[INTEGRATIONS.md](INTEGRATIONS.md).

| Integratie | Status |
| --- | --- |
| PostgreSQL | **LIVE** (lokaal) |
| Redis | CONFIGURATION REQUIRED |
| Auth.js (e-mail/wachtwoord) | **LIVE** |
| Google OAuth | CONFIGURATION REQUIRED |
| Resend (e-mail) | CONFIGURATION REQUIRED |
| Mollie (iDEAL, Bancontact, creditcard) | NOT AVAILABLE — fase 5 |
| Twilio (SMS) | NOT AVAILABLE — fase 4 |
| WhatsApp (Twilio of Meta Cloud API) | NOT AVAILABLE — fase 4 |
| Sentry | NOT AVAILABLE — fase 6 |
| Kaart (Leaflet + OpenStreetMap) | NOT AVAILABLE — fase 3 |
| Mapbox | NOT AVAILABLE — fase 3 (optionele upgrade) |
| Analytics (Plausible / Umami) | NOT AVAILABLE — fase 6 |
| Woningbronnen | NOT AVAILABLE — fase 3 |

**LIVE** = draait aantoonbaar · **CONFIGURATION REQUIRED** = code compleet,
wacht op credentials · **NOT AVAILABLE** = nog niet gebouwd.

---

## Architectuur in het kort

Twee processen uit één codebase:

- **`web`** — Next.js App Router: UI, auth, API-routes, webhooks. Stateless.
- **`worker`** — gewoon Node-proces: BullMQ-queues en de bron-scheduler.
  Draait altijd, hangt niet aan een request.

Twee datastores: **PostgreSQL** (alles wat overleeft) en **Redis** (queues,
locks, rate limits, worker-heartbeat). Redis bevat niets dat niet opnieuw op te
bouwen is.

De pijplijn: `source-poll → listing-ingest → property-match → notification-send`,
elk een eigen queue met eigen retries en een dead-letter queue.

Het volledige verhaal — inclusief waarom deduplicatie met blocking keys werkt en
waarom de unique constraints de échte garantie tegen dubbele notificaties zijn —
staat in [docs/architecture.md](docs/architecture.md).

Beslissingen met gevolgen staan als ADR in [docs/decisions/](docs/decisions/).

---

## Bronnen en legaliteit

Er wordt uitsluitend gebruikgemaakt van bronnen die dat technisch én juridisch
toestaan: officiële API's, feeds, RSS, partnerfeeds en expliciet toegestane
crawling. `robots.txt`, Terms of Service, rate limits, auteursrecht,
databankrechten en de AVG zijn randvoorwaarden, geen obstakels om omheen te
werken.

Er wordt **niet** gewerkt met CAPTCHA-omzeiling, botdetectie-omzeiling,
IP-rotatie of het nabootsen van authenticatie. Een bron die geen toegestane
toegangsweg biedt, wordt niet geïmplementeerd.

De beoordeling per bron komt in `docs/sources.md` (fase 3), vóór er
connector-code geschreven wordt.

---

## Testen

| Soort | Draait tegen | Commando |
| --- | --- | --- |
| Unit | niets externs | `npm run test:unit` |
| Integration | echte PostgreSQL + Redis | `npm run test:integration` |
| E2E | de gebouwde app | `npm run test:e2e` |

Integration tests gebruiken **geen** mock-database. Een test die tegen een
nep-database slaagt zegt niets over een schemawijziging.

Testdata staat in `tests/fixtures/` en komt nooit in een productiedatabase.
`prisma/seed.ts` bevat uitsluitend referentiedata (plannen, bronregistraties) en
is veilig om tegen productie te draaien.

---

## Deployment

- **web** — container of Vercel
- **worker** — container op een altijd-aan platform (Render Background Worker,
  Fly.io, ECS). Niet serverless.
- **PostgreSQL** — managed
- **Redis** — managed

`Dockerfile` (web), `Dockerfile.worker` en `docker-compose.yml` staan klaar.
De CI-job `docker` bouwt beide images op elke pull request.

Migraties gaan met `npm run db:deploy` (`prisma migrate deploy`), nooit met
`db push`.

---

## Licentie

Propriëtair. Alle rechten voorbehouden.
