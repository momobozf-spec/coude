import type { NextConfig } from 'next'
import createNextIntlPlugin from 'next-intl/plugin'

const withNextIntl = createNextIntlPlugin('./src/i18n/request.ts')

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  serverExternalPackages: ['bullmq', 'ioredis', 'pino', 'pino-pretty'],
  images: {
    // Listing photos are hotlinked from the source portals. Remote patterns are
    // opened per connector in docs/sources.md; nothing is allowed by default.
    remotePatterns: [],
  },
}

export default withNextIntl(nextConfig)
