# INTEGRATIONS

De eerlijke status van elke externe integratie (REQUIREMENTS §39).

**Laatst bijgewerkt:** einde fase 1

## Wat de statussen betekenen

| Status | Betekenis |
| --- | --- |
| **LIVE** | Volledig gebouwd, geconfigureerd en aantoonbaar werkend in deze omgeving. |
| **CONFIGURATION REQUIRED** | Code is compleet: client, retries, foutafhandeling, webhook-verificatie en tests. Het wacht uitsluitend op credentials van jou. |
| **NOT AVAILABLE** | Nog niet gebouwd. |

Niets wordt als "werkend" gepresenteerd zolang het niet daadwerkelijk gedraaid heeft.

---

## Overzicht

| Integratie | Status | Nodig vanaf |
| --- | --- | --- |
| PostgreSQL | **LIVE** (lokaal) | nu |
| Redis | **CONFIGURATION REQUIRED** | fase 3 |
| Auth.js — e-mail/wachtwoord | **LIVE** | nu |
| Google OAuth | **CONFIGURATION REQUIRED** | nu |
| Resend (e-mail) | **CONFIGURATION REQUIRED** | nu |
| Mollie (betalingen) | NOT AVAILABLE | fase 5 |
| Twilio (SMS) | NOT AVAILABLE | fase 4 |
| WhatsApp (Twilio of Meta) | NOT AVAILABLE | fase 4 |
| Sentry | NOT AVAILABLE | fase 6 |
| Kaart (Leaflet + OSM) | NOT AVAILABLE | fase 3 |
| Mapbox (optionele upgrade) | NOT AVAILABLE | fase 3 |
| Analytics (Plausible/Umami) | NOT AVAILABLE | fase 6 |
| Woningbronnen | NOT AVAILABLE | fase 3 |

---

## PostgreSQL — LIVE (lokaal)

Draait via `npm run dev:db` op poort 5433. `/api/health` meldt `database => ok`.

**Env:** `DATABASE_URL`

Voor productie: een managed PostgreSQL (Neon, Supabase, Render, RDS). Gebruikt je
provider een connection pooler, zet `DATABASE_URL` dan bij het draaien van
migraties tijdelijk op de directe verbinding — Prisma's `migrate` werkt niet
betrouwbaar door een pooler heen.

---

## Redis — CONFIGURATION REQUIRED

**Env:** `REDIS_URL`

Er draait geen Redis op deze machine en er is geen Docker. De code is compleet
(gedeelde client, aparte BullMQ-connecties, retry-strategie, key-helpers), maar
niets is er tegenaan gedraaid.

**Wat jij moet doen — kies één:**

1. **Docker:** `docker compose up -d redis` → `REDIS_URL=redis://localhost:6379`
2. **WSL2:** `sudo apt install redis-server && sudo service redis-server start`
   → `REDIS_URL=redis://localhost:6379`
3. **Managed, gratis tier:** [Upstash](https://upstash.com) of
   [Redis Cloud](https://redis.com/try-free/) → zet de meegeleverde
   `rediss://`-URL in `REDIS_URL`

Zonder Redis start de worker niet en meldt `/api/health` dat eerlijk.

---

## Auth.js — LIVE (e-mail/wachtwoord)

Registreren, e-mailverificatie, inloggen, uitloggen, wachtwoord vergeten en
resetten werken en zijn end-to-end aangetoond tegen een echte database en over
echte HTTP. Sessies zijn server-side intrekbaar (zie
[ADR-0005](docs/decisions/0005-jwt-sessions-with-a-revocation-registry.md)).

Eén kanttekening: de **verificatiemail wordt pas daadwerkelijk verstuurd zodra
Resend geconfigureerd is**. Tot die tijd legt het systeem elke poging eerlijk
vast als `FAILED` met code `EMAIL_NOT_CONFIGURED` — er wordt niets als verzonden
gepresenteerd. In development schrijft de logger de verificatielink erbij zodat
je zonder Resend-account kunt registreren.

**Env:** `AUTH_SECRET` (verplicht), `AUTH_URL` (optioneel)

`AUTH_SECRET` genereer je zelf:

```bash
openssl rand -base64 32
```

In productie weigert de app te starten zonder een `AUTH_SECRET` van minstens 32
tekens.

### Google OAuth — CONFIGURATION REQUIRED

De provider is volledig gebouwd, inclusief account-linking en een controle die
een Google-profiel zonder `email_verified` weigert. Hij wordt pas geregistreerd
zodra beide variabelen gezet zijn, en de knop verschijnt dan vanzelf.

**Env:** `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`

1. Ga naar [Google Cloud Console → Credentials](https://console.cloud.google.com/apis/credentials)
2. *Create credentials* → *OAuth client ID* → *Web application*
3. Zet bij **Authorised redirect URIs**: `<APP_URL>/api/auth/callback/google`
   (lokaal: `http://localhost:3000/api/auth/callback/google`)
4. Kopieer client ID en client secret

Zonder deze twee waarden wordt de Google-knop niet getoond — geen knop die faalt
bij het indrukken.

---

## Resend (e-mail) — CONFIGURATION REQUIRED

De verzendlaag is compleet: client, retry op alleen transiënte fouten, een
`Notification`-rij per bericht en een `NotificationAttempt`-rij per poging, plus
transactionele templates (verificatie, welkom, wachtwoordherstel,
wachtwoord-gewijzigd) in NL, FR en EN met HTML én platte tekst.

**Dit is de enige integratie die je nu nodig hebt om het product bruikbaar te
maken.** Zonder deze twee variabelen kan een nieuwe gebruiker zijn e-mailadres
niet bevestigen.

**Env:** `RESEND_API_KEY`, `EMAIL_FROM`, `EMAIL_REPLY_TO` (optioneel),
`RESEND_WEBHOOK_SECRET` (optioneel)

1. Maak een account op [resend.com](https://resend.com)
2. **Verifieer een domein** onder *Domains* — zonder geverifieerd domein mag je
   alleen naar je eigen adres sturen, en dat valt in productie meteen om
3. Maak een API-key onder *API Keys* (scope: *Sending access*)
4. Zet `EMAIL_FROM` op een adres op dat domein, bijvoorbeeld
   `WoningAlert <alerts@jouwdomein.nl>`
5. Voor bounce- en delivery-status: *Webhooks* → endpoint
   `<APP_URL>/api/webhooks/resend` → kopieer het signing secret naar
   `RESEND_WEBHOOK_SECRET`

---

## Mollie (betalingen) — NOT AVAILABLE (fase 5)

**Env:** `MOLLIE_API_KEY`, `MOLLIE_WEBHOOK_TOKEN`, `MOLLIE_PROFILE_ID` (optioneel)

1. [my.mollie.com](https://my.mollie.com) → *Developers* → *API keys*
2. Begin met de **test**-key (`test_...`); de live-key (`live_...`) pas bij
   livegang
3. Zet onder *Website profiles* de betaalmethoden aan: **iDEAL**, **Bancontact**,
   **Credit card**
4. `MOLLIE_WEBHOOK_TOKEN` verzin je zelf — een lange willekeurige string:
   ```bash
   openssl rand -hex 24
   ```
   Die wordt aan de webhook-URL geplakt zodat onbekende bellers er niet bij
   kunnen. Mollie ondertekent zijn webhook-body niet: de webhook bevat alleen
   een payment-id, en de handler haalt die betaling terug op bij Mollie om hem
   te verifiëren. Het token is een extra laag daarbovenop.
5. Voor lokaal testen heb je een publieke URL nodig (`ngrok http 3000` of
   `cloudflared tunnel`), want Mollie moet je machine kunnen bereiken

---

## Twilio (SMS) — NOT AVAILABLE (fase 4)

**Env:** `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_PHONE_NUMBER` of
`TWILIO_MESSAGING_SERVICE_SID`, `TWILIO_STATUS_CALLBACK_URL` (optioneel)

1. [console.twilio.com](https://console.twilio.com) → Account SID en Auth Token
   staan op het dashboard
2. Koop een nummer onder *Phone Numbers → Buy a number* met **SMS**-capability
   (een Belgisch of Nederlands nummer)
3. Zet dat nummer in E.164-notatie in `TWILIO_PHONE_NUMBER`, bijvoorbeeld
   `+32460000000`

Let op: voor SMS naar Nederlandse en Belgische nummers gelden registratie-eisen
voor alfanumerieke sender ID's. Een gekocht nummer omzeilt dat.

---

## WhatsApp — NOT AVAILABLE (fase 4)

Kies één provider met `WHATSAPP_PROVIDER`. De afweging staat in
[ADR-0004](docs/decisions/0004-whatsapp-provider.md); **Twilio is de aanbevolen
start**.

### Optie A — Twilio (`WHATSAPP_PROVIDER=twilio`)

**Env:** de Twilio-variabelen hierboven, plus `TWILIO_WHATSAPP_FROM` en
`TWILIO_WHATSAPP_TEMPLATE_SID`

1. Console → *Messaging* → *Try it out* → *Send a WhatsApp message* voor de
   sandbox (`whatsapp:+14155238886`)
2. Voor productie: *Senders* → *WhatsApp senders* → nummer registreren
3. Maak een **Content Template** onder *Content Template Builder* en laat die
   goedkeuren; zet de SID in `TWILIO_WHATSAPP_TEMPLATE_SID`

### Optie B — Meta Cloud API (`WHATSAPP_PROVIDER=meta`)

**Env:** `WHATSAPP_CLOUD_PHONE_NUMBER_ID`, `WHATSAPP_CLOUD_ACCESS_TOKEN`,
`WHATSAPP_CLOUD_BUSINESS_ACCOUNT_ID`, `WHATSAPP_CLOUD_TEMPLATE_NAME`,
`WHATSAPP_CLOUD_TEMPLATE_LANGUAGE`, `WHATSAPP_CLOUD_VERIFY_TOKEN`,
`WHATSAPP_CLOUD_APP_SECRET`

1. [developers.facebook.com/apps](https://developers.facebook.com/apps) → app
   aanmaken → product *WhatsApp* toevoegen
2. *API Setup* geeft je het Phone Number ID en een tijdelijke token; maak voor
   productie een **System User** met een permanente token
3. *Message Templates* → template aanmaken en laten goedkeuren
4. Webhook: `<APP_URL>/api/webhooks/whatsapp`, met een zelfverzonnen
   `WHATSAPP_CLOUD_VERIFY_TOKEN`; het app secret staat onder *App Settings →
   Basic*

**Belangrijk voor beide:** buiten het 24-uurs servicevenster accepteert WhatsApp
alleen goedgekeurde templates. Een woningalert valt daar per definitie buiten,
dus zonder goedgekeurd template werkt het kanaal niet — hoe correct de code ook is.

---

## Sentry — NOT AVAILABLE (fase 6)

**Env:** `SENTRY_DSN`, `NEXT_PUBLIC_SENTRY_DSN`, `SENTRY_ENVIRONMENT`,
en voor source maps `SENTRY_ORG`, `SENTRY_PROJECT`, `SENTRY_AUTH_TOKEN`

[sentry.io](https://sentry.io) → project (platform: Next.js) → *Settings →
Client Keys (DSN)*.

Zonder DSN blijft error tracking uit; de structured logs blijven wel werken.

---

## Kaart — NOT AVAILABLE (fase 3)

**Env:** `NEXT_PUBLIC_MAP_PROVIDER` (`osm` of `mapbox`), `NEXT_PUBLIC_MAPBOX_TOKEN`

Standaard `osm`: Leaflet met OpenStreetMap-tiles. **Geen token nodig**, werkt
meteen. Houd wel rekening met de
[OSM tile usage policy](https://operations.osmfoundation.org/policies/tiles/) —
bij serieus volume hoor je een eigen tile-server of een betaalde provider te
gebruiken.

Mapbox is de optionele upgrade: [account.mapbox.com](https://account.mapbox.com)
→ *Access tokens*.

---

## Analytics — NOT AVAILABLE (fase 6)

**Env:** `NEXT_PUBLIC_ANALYTICS_PROVIDER` (`none`, `plausible`, `umami`) plus de
bijbehorende variabelen.

Beide zijn cookieloos en daarmee zonder cookiebanner te gebruiken. Standaard
`none`.

---

## Woningbronnen — NOT AVAILABLE (fase 3)

**Env:** patroon `SOURCE_<SOURCE_ID>_API_KEY` / `_USERNAME` / `_PASSWORD`

Nog niet onderzocht welke Nederlandse en Belgische bronnen een officiële API,
RSS of expliciet toegestane feed aanbieden. Dat onderzoek is het eerste werk van
fase 3 en komt in `docs/sources.md`, vóór er connector-code geschreven wordt.

Bronnen worden aan- en uitgezet en getuned (poll-interval, rate limit, retries)
in de admin-UI. Alleen de **secrets** staan in environment variables, zodat er
nooit een credential in de database belandt.
