/**
 * Reference and configuration data only (REQUIREMENTS §3, §32).
 *
 * This seed is safe to run against production, because it never creates a
 * property, a user, a payment or a statistic. It only ensures rows the
 * application needs in order to function at all, and it is idempotent: running
 * it twice changes nothing.
 *
 * Test fixtures live in `tests/fixtures/` and are loaded by the test setup,
 * never by this file.
 */
import { PrismaPg } from '@prisma/adapter-pg'

import { PrismaClient } from '../src/generated/prisma/client'
import { PLAN_DEFAULTS } from '../src/server/entitlements/plans'

const connectionString = process.env.DATABASE_URL

if (!connectionString) {
  throw new Error('DATABASE_URL is required to seed.')
}

const prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString }) })

/**
 * Plans are seeded with `create`-only semantics on purpose.
 *
 * An admin who lowers a price in the UI must not have it silently reset by the
 * next deploy. New plans are added; existing ones are left exactly as the admin
 * configured them.
 */
async function seedPlans(): Promise<void> {
  let created = 0

  for (const definition of Object.values(PLAN_DEFAULTS)) {
    const existing = await prisma.planConfig.findUnique({ where: { plan: definition.plan } })
    if (existing) continue

    await prisma.planConfig.create({
      data: {
        plan: definition.plan,
        displayName: definition.displayName,
        priceAmount: definition.priceCents / 100,
        currency: definition.currency,
        intervalMonths: definition.intervalMonths,
        maxSearchProfiles: definition.maxSearchProfiles,
        allowedChannels: definition.allowedChannels,
        pollPriority: definition.pollPriority,
        matchHistoryDays: definition.matchHistoryDays,
        instantAlerts: definition.instantAlerts,
        sortOrder: definition.sortOrder,
        isActive: true,
      },
    })
    created += 1
  }

  console.log(
    created > 0
      ? `Plans: ${created} created, ${Object.keys(PLAN_DEFAULTS).length - created} left untouched.`
      : 'Plans: all present, nothing changed.',
  )
}

async function main(): Promise<void> {
  console.log('Seeding reference data...')
  await seedPlans()

  // Property sources are registered in phase 3, after each source has a
  // documented legal basis in docs/sources.md. Registering one before that
  // assessment exists would be exactly the shortcut REQUIREMENTS §2 forbids.
  const sources = await prisma.propertySource.count()
  console.log(`Property sources registered: ${sources}.`)

  console.log('Done.')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (error: unknown) => {
    console.error('Seed failed:', error)
    await prisma.$disconnect()
    process.exit(1)
  })
