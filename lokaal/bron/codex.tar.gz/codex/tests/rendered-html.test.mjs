import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

test("contains the finished Muslim Kids Club experience", async () => {
  const source = await readFile("app/MuslimKidsClub.tsx", "utf8");
  assert.match(source, /Islam leren wordt/);
  assert.match(source, /Geen advertenties/);
  assert.match(source, /OUDERDASHBOARD/);
  assert.match(source, /Dagelijkse uitdaging/);
  assert.doesNotMatch(source, /SkeletonPreview/);
});

test("includes production metadata and persistent data architecture", async () => {
  const [layout, schema, hosting] = await Promise.all([
    readFile("app/layout.tsx", "utf8"),
    readFile("db/schema.ts", "utf8"),
    readFile(".openai/hosting.json", "utf8"),
  ]);
  assert.match(layout, /og\.png/);
  assert.match(schema, /child_profiles/);
  assert.match(schema, /content_reviews/);
  assert.equal(JSON.parse(hosting).d1, "DB");
});
