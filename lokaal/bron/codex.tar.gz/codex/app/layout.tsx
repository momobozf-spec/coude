import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Muslim Kids Club — Islam leren wordt een avontuur",
  description: "Een veilige en speelse leerwereld voor islamitische kinderen.",
  icons: { icon: "/favicon.svg" },
  openGraph: { title: "Muslim Kids Club", description: "Islam leren wordt een avontuur.", images: ["/og.png"] },
  twitter: { card: "summary_large_image", title: "Muslim Kids Club", description: "Islam leren wordt een avontuur.", images: ["/og.png"] },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="nl"><body>{children}</body></html>;
}
