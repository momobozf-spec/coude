import { MuslimKidsClub } from "./MuslimKidsClub";

export default function Home() {
  return <MuslimKidsClub />;
}
