"use client";

import { useEffect, useState } from "react";

type View = "home" | "child" | "world" | "game" | "parent";

const worlds = [
  { id: 1, icon: "☪", title: "De Vijf Zuilen", subtitle: "Ontdek de basis van de islam", color: "coral", progress: 72, lessons: "4 van 5 lessen" },
  { id: 2, icon: "◴", title: "Mijn Gebed", subtitle: "Leer over salah en wudu", color: "blue", progress: 38, lessons: "2 van 6 lessen" },
  { id: 3, icon: "♥", title: "Goede Manieren", subtitle: "Groei met mooie gewoontes", color: "mint", progress: 18, lessons: "1 van 6 lessen" },
  { id: 4, icon: "⌁", title: "Verhalen", subtitle: "Binnenkort beschikbaar", color: "lavender", progress: 0, lessons: "Nieuwe wereld", locked: true },
];

const nav = [
  ["⌂", "Start"], ["◇", "Spelen"], ["▤", "Leren"], ["★", "Beloningen"], ["☺", "Mijn avatar"],
];

export function MuslimKidsClub() {
  const [view, setView] = useState<View>("home");
  const [xp, setXp] = useState(740);
  const [answer, setAnswer] = useState<number | null>(null);
  const [mission, setMission] = useState(false);
  const [lang, setLang] = useState("NL");
  const [toast, setToast] = useState("");

  useEffect(() => {
    const saved = window.localStorage.getItem("mkc-demo");
    if (saved) {
      const state = JSON.parse(saved);
      setXp(state.xp ?? 740);
      setMission(state.mission ?? false);
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem("mkc-demo", JSON.stringify({ xp, mission }));
  }, [xp, mission]);

  const go = (next: View) => { setView(next); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const notify = (message: string) => { setToast(message); window.setTimeout(() => setToast(""), 2600); };

  if (view === "home") return <Landing onStart={() => go("child")} onParent={() => go("parent")} lang={lang} setLang={setLang} />;

  return (
    <div className="app-shell">
      {toast && <div className="toast">✓ {toast}</div>}
      <header className="app-header">
        <button className="brand compact" onClick={() => go("home")} aria-label="Naar homepage"><span className="brand-mark">☾</span><span>Muslim Kids<br/><b>Club</b></span></button>
        <div className="level-pill"><span>★</span><b>Level 6</b><i>{xp} XP</i></div>
        <div className="header-actions"><button className="icon-btn" onClick={() => notify("Geluid staat aan")} aria-label="Geluid">♬</button><button className="avatar" onClick={() => notify("Avatar-kast geopend")}>A</button></div>
      </header>

      {view === "child" && <ChildDashboard xp={xp} mission={mission} setMission={setMission} go={go} notify={notify} />}
      {view === "world" && <WorldView go={go} />}
      {view === "game" && <GameView answer={answer} setAnswer={setAnswer} finish={() => { if (answer === 1) setXp(v => Math.min(999, v + 80)); go("child"); }} />}
      {view === "parent" && <ParentDashboard go={go} />}

      {view !== "parent" && <nav className="bottom-nav">{nav.map(([icon,label], i) => <button key={label} className={i === 0 ? "active" : ""} onClick={() => i === 0 ? go("child") : notify(`${label} is klaar om te ontdekken`)}><span>{icon}</span>{label}</button>)}</nav>}
    </div>
  );
}

function Landing({ onStart, onParent, lang, setLang }: { onStart:()=>void; onParent:()=>void; lang:string; setLang:(v:string)=>void }) {
  return <main className="landing">
    <header className="site-header"><div className="brand"><span className="brand-mark">☾</span><span>Muslim Kids <b>Club</b></span></div><nav><a href="#hoe">Hoe het werkt</a><a href="#ouders">Voor ouders</a><a href="#veilig">Veiligheid</a></nav><div className="head-ctas"><select aria-label="Taal" value={lang} onChange={e=>setLang(e.target.value)}><option>NL</option><option>FR</option><option>EN</option><option>AR</option></select><button className="ghost" onClick={onParent}>Inloggen</button><button className="primary small" onClick={onStart}>Begin gratis</button></div></header>
    <section className="hero"><div className="hero-copy"><div className="eyebrow">✦ Veilig leren · Spelenderwijs groeien</div><h1>Islam leren wordt<br/>een <em>avontuur.</em></h1><p>Een veilige en speelse omgeving waarin kinderen stap voor stap leren over hun geloof, goede manieren en mooie gewoontes.</p><div className="hero-buttons"><button className="primary" onClick={onStart}>Begin gratis <span>→</span></button><a href="#hoe" className="video-link"><i>▶</i> Ontdek hoe het werkt</a></div><div className="trust"><div className="faces"><span>Y</span><span>L</span><span>S</span></div><div><b>Geliefd bij gezinnen</b><small>★★★★★ 4,9 · 2.000+ avonturiers</small></div></div></div>
      <div className="hero-world" aria-label="Speelse islamitische leerwereld"><div className="cloud c1"/><div className="cloud c2"/><div className="sun">✦</div><div className="mosque"><span className="minaret">☾</span><span className="dome">☪</span></div><div className="island"><div className="path"/><span className="tree t1">♣</span><span className="tree t2">♣</span><div className="kid">☺<small>Adam</small></div><div className="float-card badge-card"><span>★</span><b>Nieuwe badge!</b><small>Gebedskenner</small></div><div className="float-card xp-card"><b>+50 XP</b><small>Goed gedaan!</small></div></div></div>
    </section>
    <section className="proof"><span>Geen advertenties</span><span>Ouderlijk toezicht</span><span>Veilige omgeving</span><span>Islamitisch verantwoord</span></section>
    <section className="features" id="hoe"><div className="section-title"><span>ZO WERKT HET</span><h2>Kleine stappen. Grote groei.</h2><p>Elke dag een beetje leren, spelen en groeien.</p></div><div className="feature-grid"><Feature icon="☾" title="Spelend leren" text="Afwisselende minigames en verhalen die passen bij de leeftijd van je kind."/><Feature icon="♢" title="Een eigen avontuur" text="Verken kleurrijke werelden, verzamel badges en bouw aan mooie gewoontes."/><Feature icon="⌂" title="Gemaakt voor gezinnen" text="Volg de voortgang, beheer schermtijd en kies wat je kind mag ontdekken."/></div></section>
    <section className="parent-strip" id="ouders"><div><span>VOOR OUDERS</span><h2>Gerust meekijken.<br/>Zonder mee te spelen.</h2><p>Heldere inzichten, veilige profielen en volledige controle — terwijl je kind zelfstandig op avontuur gaat.</p><button className="primary" onClick={onParent}>Bekijk het ouderdashboard →</button></div><div className="mini-report"><div className="report-head"><span className="avatar">M</span><div><b>Mohammed</b><small>8 jaar · Niveau 8–10</small></div><strong>Deze week⌄</strong></div><div className="stats"><div><b>4</b><small>Lessen</small></div><div><b>82%</b><small>Quizscore</small></div><div><b>2</b><small>Badges</small></div></div><div className="chart"><i/><i/><i/><i/><i/><i/><i/></div></div></section>
    <footer id="veilig"><div className="brand"><span className="brand-mark">☾</span><span>Muslim Kids <b>Club</b></span></div><p>Met zorg gemaakt voor moslimgezinnen. Zonder advertenties, publieke profielen of manipulatieve spelmechanieken.</p><button className="ghost" onClick={onParent}>Ouderomgeving</button></footer>
  </main>;
}

function Feature({icon,title,text}:{icon:string;title:string;text:string}) { return <article className="feature"><div>{icon}</div><h3>{title}</h3><p>{text}</p><a href="#">Ontdek meer →</a></article> }

function ChildDashboard({xp, mission, setMission, go, notify}:{xp:number;mission:boolean;setMission:(v:boolean)=>void;go:(v:View)=>void;notify:(v:string)=>void}) {
 return <main className="dashboard"><section className="welcome"><div><p className="sunny">☀ Goedemiddag, avonturier!</p><h1>Assalamu alaikum, <em>Adam!</em></h1><p>Klaar om vandaag iets moois te ontdekken?</p></div><div className="streak"><span>🔥</span><div><b>5 dagen</b><small>op rij!</small></div></div></section>
 <section className="continue-card"><div className="continue-icon">☪</div><div className="continue-info"><span>GA VERDER MET JE AVONTUUR</span><h2>De Vijf Zuilen</h2><p>Les 4 van 5 · Ramadan</p><div className="progress"><i style={{width:"72%"}}/></div><small>72% voltooid</small></div><button className="circle-go" onClick={()=>go("world")}>→</button></section>
 <section className="quick-grid"><button className="quick yellow" onClick={()=>go("game")}><i>◎</i><div><b>Dagelijkse uitdaging</b><small>Verdien vandaag +80 XP</small></div><span>→</span></button><button className="quick blue" onClick={()=>go("game")}><i>◇</i><div><b>Nieuwe game</b><small>Gebeden op volgorde</small></div><span>→</span></button><button className="quick purple" onClick={()=>notify("Dua-audio is voorbereid voor een latere opname")}><i>☾</i><div><b>Dua van de dag</b><small>Voor het slapen</small></div><span>→</span></button></section>
 <section className="worlds-section"><div className="section-row"><div><span>JOUW WERELDEN</span><h2>Waar ga je vandaag heen?</h2></div><button onClick={()=>go("world")}>Bekijk alles →</button></div><div className="world-grid">{worlds.map(w=><button key={w.id} className={`world ${w.color}`} onClick={()=>w.locked?notify("Deze wereld opent binnenkort"):go("world")}><div className="world-art"><span>{w.icon}</span>{w.locked&&<i>🔒</i>}</div><div className="world-body"><small>WERELD {w.id}</small><h3>{w.title}</h3><p>{w.subtitle}</p><div className="progress"><i style={{width:`${w.progress}%`}}/></div><small>{w.lessons}</small></div></button>)}</div></section>
 <section className="daily-mission"><div><span>♥</span><div><small>DAGELIJKSE MISSIE</small><h3>Doe vandaag iets liefs voor iemand thuis.</h3><p>Dit is een vriendelijke motivatie, geen religieuze beoordeling.</p></div></div><button className={mission?"done":""} onClick={()=>setMission(!mission)}>{mission?"✓ Gedaan":"Markeer als gedaan"}</button></section>
 <section className="dua-card"><div className="moon-circle">☾</div><div><small>DUA VAN DE DAG</small><h3>Voor het slapen</h3><p className="arabic" dir="rtl">بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا</p><p>Bismika Allahumma amutu wa ahya</p><strong>“In Uw naam, O Allah, sterf ik en leef ik.”</strong><button onClick={()=>notify("Audio komt beschikbaar na inhoudsreview")}>♬ Luister</button></div><span className="reviewed">✓ Demo · review vereist</span></section>
 </main>
}

function WorldView({go}:{go:(v:View)=>void}) { return <main className="dashboard lesson-page"><button className="back" onClick={()=>go("child")}>← Terug naar mijn werelden</button><div className="lesson-hero"><span>☪</span><div><small>WERELD 1</small><h1>De Vijf Zuilen</h1><p>Vijf belangrijke pijlers die moslims helpen in hun dagelijks leven.</p></div></div><div className="lesson-list">{["Shahada — De geloofsgetuigenis","Salah — Het gebed","Zakat — Delen met anderen","Ramadan — De vastenmaand","Hajj — De reis naar Makkah"].map((l,i)=><article key={l} className={i<3?"complete":i===3?"current":"locked"}><span>{i<3?"✓":i+1}</span><div><small>LES {i+1}</small><h3>{l}</h3><p>{i<3?"Voltooid · uitstekend gedaan":i===3?"Klaar om te starten":"Voltooi eerst de vorige les"}</p></div>{i===3&&<button onClick={()=>go("game")}>Start les →</button>}</article>)}</div></main> }

function GameView({answer,setAnswer,finish}:{answer:number|null;setAnswer:(v:number)=>void;finish:()=>void}) { const choices=["Alleen voor jezelf houden","Samen delen en vragen of je vriend iets wil","Doen alsof je het niet ziet"]; return <main className="game-screen"><div className="game-top"><button onClick={finish}>×</button><div className="progress"><i style={{width:"70%"}}/></div><span>7 / 10</span></div><div className="game-card"><span className="game-label">GOEDE MANIEREN</span><div className="scenario">🍎<span>🥪</span></div><h1>Je vriend is zijn lunch vergeten.<br/>Wat kun je doen?</h1><div className="answers">{choices.map((c,i)=><button className={answer===i?(i===1?"right":"try"):""} onClick={()=>setAnswer(i)} key={c}><span>{String.fromCharCode(65+i)}</span>{c}</button>)}</div>{answer!==null&&<div className={answer===1?"feedback good":"feedback"}><b>{answer===1?"Mooi gekozen!":"Bijna!"}</b><p>{answer===1?"Delen en vriendelijk vragen is een mooi voorbeeld van goed gedrag.":"Een vriendelijk aanbod om samen te delen helpt je vriend."}</p><button onClick={finish}>{answer===1?"Verder +80 XP":"Bekijk het juiste antwoord"} →</button></div>}</div></main> }

function ParentDashboard({go}:{go:(v:View)=>void}) { return <main className="parent-dashboard"><aside><div className="brand compact"><span className="brand-mark">☾</span><span>Muslim Kids<br/><b>Club</b></span></div><nav><button className="active">▦ Overzicht</button><button>☺ Kindprofielen</button><button>↗ Voortgang</button><button>◴ Schermtijd</button><button>⚙ Instellingen</button></nav><button className="child-mode" onClick={()=>go("child")}>Naar kindomgeving →</button></aside><div className="parent-main"><header><div><small>OUDERDASHBOARD</small><h1>Goedemiddag, Amina</h1><p>Hier zie je hoe Adam deze week heeft geleerd en gespeeld.</p></div><button className="avatar">AM</button></header><section className="child-switch"><div className="avatar">A</div><div><b>Adam</b><small>8 jaar · Niveau 8–10 jaar</small></div><button>Wissel kind⌄</button></section><div className="stats parent-stats"><div><span>▤</span><b>4</b><small>Lessen deze week</small></div><div><span>◇</span><b>3</b><small>Games gespeeld</small></div><div><span>◎</span><b>82%</b><small>Gem. quizscore</small></div><div><span>★</span><b>2</b><small>Nieuwe badges</small></div></div><div className="parent-columns"><section className="panel"><div className="section-row"><div><small>VOORTGANG</small><h2>Leerwerelden</h2></div><button>Alles bekijken</button></div>{worlds.slice(0,3).map(w=><div className="progress-row" key={w.title}><span className={w.color}>{w.icon}</span><div><b>{w.title}</b><small>{w.lessons}</small><div className="progress"><i style={{width:`${w.progress}%`}}/></div></div><strong>{w.progress}%</strong></div>)}</section><section className="panel"><small>DEZE WEEK</small><h2>Activiteit</h2><div className="big-time">2u 15m <small>totale leertijd</small></div><div className="bar-chart">{[32,55,42,75,65,22,0].map((h,i)=><div key={i}><i style={{height:`${h}px`}}/><small>{["ma","di","wo","do","vr","za","zo"][i]}</small></div>)}</div><p className="insight">✦ Adam is het sterkst in <b>De Vijf Zuilen</b>.</p></section></div><section className="safety-note"><span>♢</span><div><b>Veilig ontworpen voor kinderen</b><p>Geen chat, advertenties, publieke profielen of locatiegegevens. Betaalacties blijven altijd in de ouderomgeving.</p></div><button>Privacy bekijken</button></section></div></main> }
