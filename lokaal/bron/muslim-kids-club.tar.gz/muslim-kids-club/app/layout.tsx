import type { Metadata } from "next";
import { DM_Sans, Lora } from "next/font/google";
import "./globals.css";

const sans = DM_Sans({ variable: "--font-sans", subsets: ["latin"] });
const display = Lora({ variable: "--font-display", subsets: ["latin"] });

export const metadata: Metadata = {
  metadataBase: new URL("https://muslim-kids-club.openai.site"),
  title: "Muslim Kids Club — Faith-filled learning, joyfully made",
  description: "A safe, ad-free learning world that helps Muslim children ages 3–12 grow in faith, kindness, and confidence.",
  openGraph: { title: "Muslim Kids Club", description: "Faith-filled learning. Joyfully made.", images: [{ url: "/og.png", width: 1200, height: 630 }] },
  twitter: { card: "summary_large_image", title: "Muslim Kids Club", description: "Faith-filled learning. Joyfully made.", images: ["/og.png"] },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body className={`${sans.variable} ${display.variable}`}>{children}</body></html>;
}
