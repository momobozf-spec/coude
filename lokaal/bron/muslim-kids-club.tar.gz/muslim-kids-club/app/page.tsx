"use client";

import { useState } from "react";

const features = [
  { icon: "✦", title: "Tiny lessons, big meaning", text: "Joyful 3–7 minute adventures that make faith, duas, and good character easy to understand." },
  { icon: "☾", title: "Stories they ask for", text: "A calm, interactive story world filled with wonder, kindness, heroes, and bedtime favourites." },
  { icon: "★", title: "Motivation that feels good", text: "Stars, badges, and friendly rewards celebrate consistency—never pressure, streak anxiety, or loot boxes." },
];

const steps = [
  { n: "01", title: "Create their little world", text: "Add each child with their age and interests." },
  { n: "02", title: "Follow a personal path", text: "Lessons gently adapt from first discoveries to deeper learning." },
  { n: "03", title: "Grow together", text: "Celebrate progress and turn daily missions into family moments." },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [dialog, setDialog] = useState<"join" | "login" | null>(null);

  return (
    <main>
      <nav className="nav shell" aria-label="Main navigation">
        <a className="brand" href="#top" aria-label="Muslim Kids Club home">
          <span className="brand-mark">☾</span><span>Muslim Kids <b>Club</b></span>
        </a>
        <button className="menu-button" aria-label="Toggle menu" aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>☰</button>
        <div className={`nav-links ${menuOpen ? "open" : ""}`}>
          <a href="#inside" onClick={() => setMenuOpen(false)}>What’s inside</a>
          <a href="#parents" onClick={() => setMenuOpen(false)}>For parents</a>
          <a href="#pricing" onClick={() => setMenuOpen(false)}>Pricing</a>
          <button className="text-button" onClick={() => setDialog("login")}>Log in</button>
          <button className="button button-small" onClick={() => setDialog("join")}>Join the club <span>→</span></button>
        </div>
      </nav>

      <section id="top" className="hero shell">
        <div className="hero-copy">
          <div className="eyebrow"><span>✦</span> A happier way to learn Islam</div>
          <h1>Little hearts.<br/><em>Big faith.</em><br/>Joyful learning.</h1>
          <p>Short lessons, magical stories, and meaningful daily missions—made to help Muslim children grow with confidence and love.</p>
          <div className="hero-actions">
            <button className="button" onClick={() => setDialog("join")}>Start your family’s journey <span>→</span></button>
            <a className="watch" href="#inside"><span className="play">▶</span> See what’s inside</a>
          </div>
          <div className="trust"><span className="faces">🧒🏽👧🏻👦🏾</span><span><b>Loved by growing families</b><small>Safe, ad-free, and parent approved</small></span></div>
        </div>

        <div className="hero-world" aria-label="Preview of the learning journey">
          <div className="sun"/><div className="cloud cloud-one"/><div className="cloud cloud-two"/>
          <div className="spark s1">✦</div><div className="spark s2">✦</div>
          <div className="path-card card-one"><span className="lesson-icon">☁</span><div><small>Up next</small><b>Who is Allah?</b></div><span className="arrow">→</span></div>
          <div className="path-card card-two"><span className="lesson-icon gold">☾</span><div><small>Story time</small><b>The Kind Neighbour</b></div><span className="arrow">→</span></div>
          <div className="path-card card-three"><span className="lesson-icon coral">♥</span><div><small>Daily mission</small><b>Help someone today</b></div><span className="check">✓</span></div>
          <div className="owl" aria-hidden="true"><div className="ear left"/><div className="ear right"/><div className="owl-face"><span>●</span><i>◆</i><span>●</span></div><div className="owl-body">✦</div></div>
          <div className="hill hill-back"/><div className="hill hill-front"/>
        </div>
      </section>

      <section className="values-strip"><div className="shell value-row"><span>✓ Always ad-free</span><span>✓ Built with Islamic values</span><span>✓ Made for ages 3–12</span><span>✓ Parent-controlled</span></div></section>

      <section id="inside" className="section shell center">
        <div className="kicker">Explore their world</div>
        <h2>Everything they love.<br/><em>Everything you value.</em></h2>
        <p className="section-intro">One beautiful, safe space where curiosity becomes knowledge and small moments become lifelong habits.</p>
        <div className="feature-grid">
          {features.map((item, i) => <article className={`feature-card feature-${i + 1}`} key={item.title}><div className="feature-icon">{item.icon}</div><h3>{item.title}</h3><p>{item.text}</p><a href="#journey">Discover more <span>→</span></a></article>)}
        </div>
      </section>

      <section id="journey" className="journey-section"><div className="shell journey-grid">
        <div><div className="kicker light">A path made for them</div><h2>Learning that grows<br/><em>with your child.</em></h2><p>From a first “Bismillah” to understanding prayer and character, every step is clear, encouraging, and age-appropriate.</p><div className="steps">{steps.map(s => <div className="step" key={s.n}><span>{s.n}</span><div><h3>{s.title}</h3><p>{s.text}</p></div></div>)}</div></div>
        <div className="journey-panel"><div className="panel-top"><div><small>Maryam’s journey</small><h3>Growing in faith</h3></div><span className="streak">★ 12 stars</span></div><div className="progress"><i/></div><p className="progress-label"><span>4 of 6 adventures</span><b>67%</b></p><div className="lesson-list"><div className="done"><span>✓</span><div><small>Completed</small><b>Saying Bismillah</b></div><em>+3 ★</em></div><div className="active"><span>☾</span><div><small>Continue learning</small><b>Why do we pray?</b></div><em>Play →</em></div><div className="locked"><span>◇</span><div><small>Up next</small><b>Being kind to animals</b></div><em>🔒</em></div></div></div>
      </div></section>

      <section id="parents" className="section shell parent-section"><div className="parent-card"><div className="parent-copy"><div className="kicker">You’re part of the journey</div><h2>Peace of mind,<br/><em>built right in.</em></h2><p>See what they’re learning, celebrate their wins, set healthy limits, and turn progress into family conversations.</p><ul><li><span>✓</span> Separate profiles for every child</li><li><span>✓</span> Weekly progress made simple</li><li><span>✓</span> Screen-time and download controls</li></ul></div><div className="report"><div className="report-head"><div className="mini-avatar">M</div><div><small>This week</small><h3>Maryam is blooming!</h3></div><span>•••</span></div><div className="report-stats"><div><b>4</b><small>Lessons</small></div><div><b>2</b><small>Stories</small></div><div><b>6</b><small>Missions</small></div></div><div className="report-win"><span>★</span><div><small>New achievement</small><b>Kindness Champion</b></div></div></div></div></section>

      <section id="pricing" className="section shell center pricing"><div className="kicker">Simple, honest pricing</div><h2>Start free. Grow when<br/><em>your family is ready.</em></h2><div className="price-card"><span className="popular">Most loved</span><div><small>Premium family</small><p><b>€9.99</b> / month</p><span>One membership. The whole learning world.</span></div><ul><li>✓ Unlimited lessons & stories</li><li>✓ Up to 5 child profiles</li><li>✓ Parent dashboard & reports</li><li>✓ Offline downloads</li><li>✓ New adventures every month</li></ul><button className="button" onClick={() => setDialog("join")}>Try premium free <span>→</span></button><small className="fine">7 days free. Cancel anytime.</small></div></section>

      <footer><div className="shell footer-row"><div><a className="brand footer-brand" href="#top"><span className="brand-mark">☾</span><span>Muslim Kids <b>Club</b></span></a><p>Faith-filled learning. Joyfully made.</p></div><div className="footer-links"><a href="#inside">Learning</a><a href="#parents">Parents</a><a href="#pricing">Pricing</a><button onClick={() => setDialog("login")}>Log in</button></div><small>© 2026 Muslim Kids Club · Made with care for every little heart.</small></div></footer>

      {dialog && <div className="modal-backdrop"><section className="modal" role="dialog" aria-modal="true" aria-labelledby="dialog-title"><button className="close" aria-label="Close" onClick={() => setDialog(null)}>×</button><span className="modal-mark">☾</span><h2 id="dialog-title">{dialog === "join" ? "Let’s begin your family’s journey" : "Welcome back"}</h2><p>{dialog === "join" ? "Create your parent account. Your child’s safe learning world comes next." : "Log in to continue your family’s learning journey."}</p><form onSubmit={e => { e.preventDefault(); setDialog(null); }}><label>Email address<input required type="email" placeholder="you@example.com"/></label><label>Password<input required type="password" minLength={8} placeholder="At least 8 characters"/></label><button className="button" type="submit">{dialog === "join" ? "Create parent account" : "Log in"} <span>→</span></button></form><small>By continuing, you agree to our family-friendly terms and privacy policy.</small></section></div>}
    </main>
  );
}
