# Muslim Kids Club — Phase 1 product foundation

## Product promise

Muslim Kids Club helps children aged 3–12 build faith, character, curiosity, and positive habits through short, joyful daily experiences. Parents buy the product; children use it. Every decision must be safe, respectful, age-appropriate, ad-free, and free of manipulative reward mechanics.

## MVP audience

- Ages 3–5: narrated, visual, low-reading experiences with parent participation.
- Ages 6–8: guided independent learning, simple quizzes, stories, and daily missions.
- Ages 9–12: deeper explanations, choice-driven stories, reflection, and meaningful goals.
- Parents: clear setup, progress visibility, approvals, limits, downloads, and billing.

## MVP scope

Landing and authentication; parent onboarding; multiple child profiles; a structured learning journey; five lessons; ten quizzes; five stories; five mini games; parent dashboard; subscription and responsive web UI.

## Product principles

1. Build love before volume: sessions are short, complete, and satisfying.
2. Healthy motivation only: celebrate consistency without loss aversion or infinite grinding.
3. Parent confidence by default: visible content standards, controls, and progress.
4. Islamic respect by design: reviewed educational sources, no rulings from AI, and clear escalation to parents or scholars.
5. Accessible everywhere: touch-first, readable, keyboard-friendly, low-bandwidth, multilingual, and RTL-ready.

## Phase roadmap

1. Foundations: documentation, architecture, data model, UI system, landing, authentication boundary.
2. Learning journey and first lesson set.
3. Story library, narration, favourites, and downloads.
4. Educational games and shared reward events.
5. Parent dashboard, mission approvals, limits, and reports.
6. Guardrailed AI stories and child learning companion.
7. Stripe subscriptions, entitlement enforcement, and lifecycle messaging.
