# Architecture decision record

## Shape

Use a TypeScript monorepo when mobile development begins: `apps/web` (Next.js), `apps/mobile` (Expo), `packages/ui-tokens`, `packages/domain`, `packages/content`, and `packages/i18n`. This Phase 1 site remains a deployable web vertical slice and can move into `apps/web` without changing its component model.

## Boundaries

- Identity: Clerk or Auth.js behind an `AuthService` interface. Authentication is intentionally represented by a UI boundary in this preview; production identity requires provider credentials and server-side sessions.
- Data: PostgreSQL with Prisma in the product runtime. IDs are opaque strings; every family-owned record is authorized server-side against membership.
- Content: versioned lesson/story/game content with draft, review, scheduled, and published states. Published versions are immutable.
- Media: object storage plus signed URLs and offline manifests. Narration and images have locale-specific variants.
- Billing: Stripe Checkout and Customer Portal; webhooks are the source of truth for entitlements.
- AI: provider-neutral server layer with structured output, age band, locale, source policy, moderation, audit record, and parent-only generation controls.
- Notifications: queued delivery with parental consent, quiet hours, locale, and idempotency keys.

## Localization

All user-facing content uses stable message keys. Store locale as BCP 47, fall back from regional locale to base locale to English, and make layouts direction-aware. Arabic is a first-class RTL test target rather than a later translation pass.

## Safety and privacy

Collect the minimum child data, avoid direct child email accounts, and place family ownership on every child record. Never expose a child profile by a guessable public URL. Keep analytics event-based and pseudonymous. AI output is generated only from parent surfaces in the MVP and is filtered, logged, and reviewable.

## Quality gates

Each phase must pass formatting/lint, TypeScript compilation, production build, accessibility smoke checks, unit tests for domain rules, and end-to-end coverage for its primary family journey.
