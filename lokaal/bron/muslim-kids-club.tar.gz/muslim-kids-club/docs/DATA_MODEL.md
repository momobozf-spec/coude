# Initial domain model

The production PostgreSQL/Prisma model should start with these aggregates:

- `User`, `Family`, `FamilyMember`, `Consent`: adult identity, family ownership, roles, and policy records.
- `ChildProfile`: nickname, birth year/month, age band, avatar, locale, accessibility preferences, and content level.
- `ContentItem`, `ContentVersion`, `Translation`, `MediaAsset`: reviewed, versioned lessons, stories, quizzes, and games.
- `LearningPath`, `PathNode`, `Enrollment`, `ProgressEvent`: ordered curriculum and append-only progress history.
- `Mission`, `MissionAssignment`, `MissionApproval`: daily actions with parent verification.
- `RewardDefinition`, `RewardGrant`: deterministic, auditable healthy rewards with no chance mechanics.
- `StoryFavourite`, `DownloadManifest`: family preferences and offline availability.
- `Subscription`, `Entitlement`, `WebhookEvent`: billing state and idempotent access control.
- `AiGeneration`, `SafetyReview`: parent prompt, structured result, model metadata, and moderation outcome.

Every mutable table includes `createdAt`, `updatedAt`, and an optimistic concurrency version where conflicts matter. Family-owned rows carry `familyId`; content references immutable published version IDs so a completed lesson never changes retroactively.
