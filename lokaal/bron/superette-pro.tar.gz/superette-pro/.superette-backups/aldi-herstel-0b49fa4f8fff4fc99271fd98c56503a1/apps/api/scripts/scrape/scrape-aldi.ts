/** ALDI: elke afgewerkte pagina atomisch bewaren; bij netwerkverlies veilig hervatten. */
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { z } from 'zod';
import { buildAldiFeed } from '../../src/compare/scrapers/aldi/feed';
import { ALDI_ORIGIN, PRODUCT_URL, parseAldiProductPage, type ParsedAldiProduct } from '../../src/compare/scrapers/aldi/parse';
import { readCheckpoint, writeCheckpoint, type AldiCheckpoint } from '../../src/compare/scrapers/aldi/checkpoint';
import { BlockedError, PoliteBrowser } from './polite-browser';

const configSchema = z.object({
  sitemapUrl: z.string().url().refine((url) => url.startsWith(`${ALDI_ORIGIN}/`)),
  maxProducts: z.number().int().positive().max(2000).default(300),
  minDelayMs: z.number().int().min(2000).default(5000),
  minProductsToWrite: z.number().int().positive().default(10),
});
async function main() {
  const apiRoot = resolve(__dirname, '..', '..');
  const config = configSchema.parse(JSON.parse(readFileSync(resolve(apiRoot, process.env.SCRAPE_CONFIG ?? 'data/scrape/aldi.json'), 'utf8')));
  const feedDir = resolve(apiRoot, process.env.COMPARE_FEED_DIR ?? 'data/feeds');
  const probe = process.argv[2] ? Number(process.argv[2]) : null;
  if (probe !== null && (!Number.isInteger(probe) || probe < 1 || probe > 2000)) throw new Error('Ongeldig proefaantal.');
  const maxProducts = probe ?? config.maxProducts;
  const signature = JSON.stringify({ config, probe });
  mkdirSync(feedDir, { recursive: true });
  const checkpointFile = join(feedDir, 'aldi.checkpoint.json');
  let checkpoint: AldiCheckpoint = existsSync(checkpointFile)
    ? readCheckpoint(checkpointFile, signature)
    : { version: 1, signature, startedAt: new Date().toISOString(), status: 'RUNNING', inSitemap: 0, urls: [], entries: [] };
  const startedAt = new Date(checkpoint.startedAt);
  const browser = new PoliteBrowser({ origin: ALDI_ORIGIN, contact: process.env.SCRAPE_CONTACT ?? '', minDelayMs: config.minDelayMs, maxPages: maxProducts + 3, headless: process.env.SCRAPE_HEADLESS !== 'false', enforceRobotsOnSubrequests: true });
  const products: ParsedAldiProduct[] = [];
  const skipped = new Map<string, number>();
  const issues: { url: string; kind: string; reason: string }[] = [];
  let withoutSalesUnit = 0, unreadableInARow = 0;
  const applyEntry = (entry: AldiCheckpoint['entries'][number]) => {
    if (!entry.input) {
      const reason = 'niet toegestaan of niet gevonden';
      skipped.set(reason, (skipped.get(reason) ?? 0) + 1);
      issues.push({ url: entry.url, kind: 'not_found_or_disallowed', reason });
      return;
    }
    if (!entry.input.salesUnit) withoutSalesUnit++;
    const result = parseAldiProductPage(entry.input);
    if (result.ok) { products.push(result.product); unreadableInARow = 0; }
    else {
      skipped.set(result.reason, (skipped.get(result.reason) ?? 0) + 1);
      issues.push({ url: entry.url, kind: result.kind, reason: result.reason });
      unreadableInARow = result.kind === 'skipped' ? 0 : unreadableInARow + 1;
      if (result.kind === 'unreadable') console.log(`onleesbaar: ${result.reason} - ${entry.url}`);
    }
    if (unreadableInARow >= 5) throw new BlockedError('5 onleesbare productpagina\'s op rij; run gestopt.');
  };
  let stopped: string | null = null;
  try {
    for (const entry of checkpoint.entries) applyEntry(entry);
    console.log(`Bewaarde voortgang: ${checkpoint.entries.length} paginas, ${products.length} bruikbare producten.`);
    await browser.start();
    if (!checkpoint.urls.length) {
      const xml = await browser.fetchText(config.sitemapUrl);
      if (!xml) throw new BlockedError('Sitemap niet gevonden of niet toegestaan.');
      const all = [...new Set([...xml.matchAll(/<loc>\s*([^<\s]+)\s*<\/loc>/g)].map((match) => match[1]!.replace(/&amp;/g, '&')).filter((url) => PRODUCT_URL.test(url)))];
      checkpoint.inSitemap = all.length;
      checkpoint.urls = all.length <= maxProducts ? all : Array.from({ length: maxProducts }, (_, i) => all[Math.floor(i * all.length / maxProducts)]!);
      if (!checkpoint.urls.length) throw new BlockedError('Sitemap bevat geen herkenbare productpagina\'s.');
      checkpoint.status = 'RUNNING';
      writeCheckpoint(checkpointFile, checkpoint);
    }
    const initialDone = checkpoint.entries.length, phaseStart = Date.now();
    for (let index = initialDone; index < checkpoint.urls.length; index++) {
      const url = checkpoint.urls[index]!;
      const page = await browser.visit(url);
      const input = page ? {
        url,
        jsonLd: await page.$$eval('script[type="application/ld+json"]', (nodes) => nodes.map((node) => node.textContent ?? '')),
        salesUnit: await page.$eval('.tag__marker--salesunit', (node) => node.textContent ?? '').catch(() => null),
      } : null;
      const entry = { url, input };
      checkpoint.entries.push(entry);
      checkpoint.status = 'RUNNING';
      // Eerst bewaren. Netwerk- of procesuitval verliest hoogstens de huidige pagina.
      writeCheckpoint(checkpointFile, checkpoint);
      applyEntry(entry);
      if (checkpoint.entries.length % 10 === 0) {
        const doneThisSession = checkpoint.entries.length - initialDone;
        const minutes = Math.ceil(((Date.now() - phaseStart) / doneThisSession * (checkpoint.urls.length - checkpoint.entries.length)) / 60_000);
        console.log(`productpagina's: ${checkpoint.entries.length}/${checkpoint.urls.length} - ${products.length} ok - nog ongeveer ${minutes} min`);
      }
    }
    checkpoint.status = 'COMPLETE';
  } catch (error) {
    stopped = error instanceof Error ? error.message : String(error);
    checkpoint.status = error instanceof BlockedError ? 'BLOCKED' : 'INTERRUPTED';
  } finally {
    writeCheckpoint(checkpointFile, checkpoint);
    await browser.stop();
  }
  const report = { startedAt: checkpoint.startedAt, finishedAt: new Date().toISOString(), probe: probe !== null, pagesVisited: browser.pagesVisited, completedProducts: checkpoint.entries.length, plannedProducts: checkpoint.urls.length, inSitemap: checkpoint.inSitemap, products: products.length, withoutSalesUnit, skipped: Object.fromEntries(skipped), issues, blocked: stopped, checkpointStatus: checkpoint.status, written: false };
  if (checkpoint.status === 'COMPLETE' && products.length >= (probe !== null ? 1 : config.minProductsToWrite)) {
    const feed = buildAldiFeed(products, startedAt);
    const target = join(feedDir, 'aldi.json');
    writeFileSync(`${target}.tmp`, JSON.stringify(feed, null, 2) + '\n', 'utf8');
    renameSync(`${target}.tmp`, target);
    report.written = true;
    console.log(`${feed.products.length} producten en ${feed.offers.length} prijzen opgeslagen.`);
  }
  writeFileSync(join(feedDir, 'aldi.report.json'), JSON.stringify(report, null, 2) + '\n', 'utf8');
  console.log(`Checkpoint: ${checkpointFile}`);
  if (stopped) { console.error(`Gestopt: ${stopped}. Voortgang bewaard; geen gedeeltelijke feed geimporteerd.`); process.exitCode = 2; }
  else if (!report.written) { console.error('Te weinig bruikbare producten; geen feed geschreven.'); process.exitCode = 1; }
}
main().catch((error) => { console.error(error.message); process.exitCode = 1; });
