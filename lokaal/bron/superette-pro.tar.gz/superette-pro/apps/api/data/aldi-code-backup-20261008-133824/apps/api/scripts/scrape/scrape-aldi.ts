/**
 * ALDI België-prijzen verzamelen → `data/feeds/aldi.json`.
 *
 *   SCRAPE_CONTACT=jij@voorbeeld.be npm run scrape:aldi          (volle run, zie config)
 *   SCRAPE_CONTACT=jij@voorbeeld.be npm run scrape:aldi -- 5     (proefrun: 5 producten)
 *
 * Werkwijze:
 *  1. robots.txt lezen (PoliteBrowser); `/product/` is toegelaten;
 *  2. de officiële productsitemap van ALDI lezen (staat in robots.txt) — de
 *     lijst met productpagina's komt dus van ALDI zelf, niets geraden;
 *  3. daaruit `maxProducts` pagina's kiezen, gelijk gespreid over de lijst
 *     (zo zit er van elke afdeling iets in, niet alleen de eerste rij);
 *  4. per product de schema.org-gegevens + de zichtbare verkoopeenheid
 *     ("1 l", `.tag__marker--salesunit`) lezen (`parseAldiProductPage`);
 *  5. het importbestand valideren en atomisch wegschrijven.
 *
 * Een blokkade (403, 429, captcha) of vijf onleesbare pagina's op rij stopt
 * de run. Bewust overgeslagen producten (wisselend gewicht) tellen niet mee.
 *
 * Daarna inladen: `npm run compare:sync -- aldi`.
 */
import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { z } from 'zod';
import { buildAldiFeed } from '../../src/compare/scrapers/aldi/feed';
import { ALDI_ORIGIN, PRODUCT_URL, parseAldiProductPage, type ParsedAldiProduct } from '../../src/compare/scrapers/aldi/parse';
import { BlockedError, PoliteBrowser } from './polite-browser';

const configSchema = z.object({
  sitemapUrl: z.string().url().refine((url) => url.startsWith(`${ALDI_ORIGIN}/`), 'alleen een sitemap op aldi.be'),
  maxProducts: z.number().int().positive().max(2000).default(300),
  minDelayMs: z.number().int().min(2000).default(5000),
  minProductsToWrite: z.number().int().positive().default(10),
});

/** Alle `<loc>`-adressen uit een sitemap. */
function locs(xml: string): string[] {
  return [...xml.matchAll(/<loc>\s*([^<\s]+)\s*<\/loc>/g)].map((match) => match[1]!.replace(/&amp;/g, '&'));
}

/** `count` elementen, gelijk gespreid over de lijst (deterministisch). */
function spread<T>(items: readonly T[], count: number): T[] {
  if (items.length <= count) return [...items];
  const step = items.length / count;
  return Array.from({ length: count }, (_, i) => items[Math.floor(i * step)]!);
}

async function main() {
  const apiRoot = resolve(__dirname, '..', '..');
  const configPath = resolve(apiRoot, process.env.SCRAPE_CONFIG ?? 'data/scrape/aldi.json');
  const feedDir = resolve(apiRoot, process.env.COMPARE_FEED_DIR ?? 'data/feeds');
  const config = configSchema.parse(JSON.parse(readFileSync(configPath, 'utf8')));

  const probe = process.argv[2] ? Number(process.argv[2]) : null;
  if (probe !== null && (!Number.isInteger(probe) || probe < 1)) throw new Error(`Ongeldig aantal: ${process.argv[2]}`);
  const maxProducts = probe ?? config.maxProducts;
  // Een proefrun schrijft altijd, ook met weinig producten: dat is net de bedoeling.
  const minToWrite = probe !== null ? 1 : config.minProductsToWrite;

  const browser = new PoliteBrowser({
    origin: ALDI_ORIGIN,
    contact: process.env.SCRAPE_CONTACT ?? '',
    minDelayMs: config.minDelayMs,
    maxPages: maxProducts + 3,
    headless: process.env.SCRAPE_HEADLESS !== 'false',
    enforceRobotsOnSubrequests: true,
  });

  const skipped = new Map<string, number>();
  const count = (reason: string) => skipped.set(reason, (skipped.get(reason) ?? 0) + 1);
  const products: ParsedAldiProduct[] = [];
  let inSitemap = 0;
  let withoutSalesUnit = 0;
  let blocked: string | null = null;
  const startedAt = new Date();

  await browser.start();
  try {
    const xml = await browser.fetchText(config.sitemapUrl);
    if (!xml) throw new BlockedError(`sitemap ${config.sitemapUrl} niet gevonden of niet toegestaan`);
    const all = [...new Set(locs(xml).filter((url) => PRODUCT_URL.test(url)))];
    inSitemap = all.length;
    const chosen = spread(all, maxProducts);
    console.log(`sitemap: ${all.length} productpagina's, we bezoeken er ${chosen.length}${probe !== null ? ' (proefrun)' : ''}`);

    let unreadableInARow = 0;
    let done = 0;
    const phaseStart = Date.now();
    for (const url of chosen) {
      if (done > 0 && done % 10 === 0) {
        const perPage = (Date.now() - phaseStart) / done;
        const leftMin = Math.ceil((perPage * (chosen.length - done)) / 60_000);
        console.log(`productpagina's: ${done}/${chosen.length} · ${products.length} ok · nog ongeveer ${leftMin} min`);
      }
      done += 1;
      const page = await browser.visit(url);
      if (!page) {
        count('niet toegestaan of niet gevonden');
        continue;
      }
      const jsonLd = await page.$$eval('script[type="application/ld+json"]', (nodes) => nodes.map((n) => n.textContent ?? ''));
      const salesUnit = await page
        .$eval('.tag__marker--salesunit', (node) => node.textContent ?? '')
        .catch(() => null);
      if (!salesUnit) withoutSalesUnit += 1;

      const result = parseAldiProductPage({ url, jsonLd, salesUnit });
      if (result.ok) {
        products.push(result.product);
        unreadableInARow = 0;
        if (probe !== null) {
          const p = result.product;
          const pack = p.packageQuantity === null ? 'inhoud onbekend' : `${p.packCount > 1 ? `${p.packCount} x ` : ''}${p.packageQuantity} ${p.packageUnit}`;
          console.log(`  ✔ ${p.brand ? `${p.brand} — ` : ''}${p.name} · ${pack} · € ${(p.priceCents / 100).toFixed(2)} · ${url}`);
        }
      } else if (result.kind === 'skipped') {
        count(result.reason);
        unreadableInARow = 0;
        if (probe !== null) console.log(`  – overgeslagen (${result.reason}) · ${url}`);
      } else {
        count(result.reason);
        unreadableInARow += 1;
        if (probe !== null) console.log(`  ✖ ${result.reason} · ${url}`);
        if (unreadableInARow >= 5) {
          throw new BlockedError(`5 productpagina's op rij zonder bruikbare gegevens (laatste: ${result.reason}); vermoedelijk geblokkeerd`);
        }
      }
    }
  } catch (error) {
    if (error instanceof BlockedError) blocked = error.message;
    else throw error;
  } finally {
    await browser.stop();
  }

  const report = {
    startedAt: startedAt.toISOString(),
    finishedAt: new Date().toISOString(),
    probe: probe !== null,
    pagesVisited: browser.pagesVisited,
    inSitemap,
    products: products.length,
    withoutSalesUnit,
    skipped: Object.fromEntries(skipped),
    blocked,
    written: false,
  };

  mkdirSync(feedDir, { recursive: true });
  if (products.length >= minToWrite) {
    const feed = buildAldiFeed(products, startedAt);
    const target = join(feedDir, 'aldi.json');
    const temp = `${target}.tmp`;
    writeFileSync(temp, `${JSON.stringify(feed, null, 2)}\n`, 'utf8');
    renameSync(temp, target);
    report.written = true;
    console.log(`✔ ${feed.offers.length} prijzen → ${target}`);
  } else {
    console.log(`✖ te weinig producten (${products.length} < ${minToWrite}); bestaand bestand blijft staan`);
  }

  writeFileSync(join(feedDir, 'aldi.report.json'), `${JSON.stringify(report, null, 2)}\n`, 'utf8');
  console.log(JSON.stringify(report, null, 2));

  if (blocked) {
    console.error(`⚠ gestopt: ${blocked}`);
    process.exitCode = 2;
  } else if (!report.written) {
    process.exitCode = 1;
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
