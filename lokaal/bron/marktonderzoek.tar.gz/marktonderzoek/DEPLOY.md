# Marktonderzoek online zetten — gratis op Render

This guide gets your survey app live on the public internet. It uses two free services:

1. **Neon** (free Postgres database) — stores survey answers permanently
2. **Render** (free Node.js hosting) — runs the Express server

End result: a URL like `https://marktonderzoek-xxxx.onrender.com` you can share with respondents.

---

## Prerequisites

You need:

- A **GitHub** account — https://github.com/signup (free)
- A **Render** account — https://render.com/register (free, sign in with GitHub)
- A **Neon** account — https://console.neon.tech/signup (free, sign in with GitHub)

All three sign-ups are free, no credit card needed.

---

## Step 1 — Create a Postgres database on Neon (3 min)

1. Go to https://console.neon.tech and click **New Project**.
2. Name: `marktonderzoek`. Region: pick the one closest to Belgium (e.g. **EU Central (Frankfurt)**).
3. After the project is created, copy the **connection string** that looks like:
   ```
   postgresql://neondb_owner:xxxxxx@ep-xxxxx.eu-central-1.aws.neon.tech/neondb?sslmode=require
   ```
4. Save this somewhere — you'll paste it into Render in step 4.

The free Neon tier includes 0.5 GB storage + auto-suspend when idle. More than enough for surveys.

---

## Step 2 — Push the code to GitHub (5 min)

In **PowerShell**, in the `marktonderzoek` folder:

```powershell
cd "C:\Users\mo-bo\OneDrive\Documenten\coude\marktonderzoek"

# Initialise a git repo (only the first time)
git init -b main
git add .
git commit -m "Initial commit"
```

If `git` is not installed, get it from https://git-scm.com/download/win.

Then:

1. Go to https://github.com/new
2. Repository name: `marktonderzoek`
3. Visibility: **Private** (so only you can read the code)
4. **Don't** check "Initialize this repository with a README" — leave it empty
5. Click **Create repository**
6. GitHub now shows a page with commands. Copy the two lines under "**…or push an existing repository from the command line**". They look like:
   ```powershell
   git remote add origin https://github.com/YOUR_USERNAME/marktonderzoek.git
   git push -u origin main
   ```
7. Paste them in PowerShell and run.

---

## Step 3 — Deploy on Render (3 min)

1. Go to https://dashboard.render.com → **New +** → **Web Service**.
2. **Connect a repository** → pick `marktonderzoek`.
3. Render auto-detects `render.yaml`. Click **Apply**.
4. On the service page, go to the **Environment** tab and fill in the three secrets:
   - `ADMIN_USER` → `admin` (or whatever you want)
   - `ADMIN_PASS` → a strong password (you'll use it to view answers)
   - `DATABASE_URL` → paste the Neon connection string from step 1
5. (`SESSION_SECRET` is auto-generated — leave it.)
6. Click **Save changes**. Render will build and deploy (~2 min).

When the status flips to **Live**, your URL is at the top of the page (e.g. `https://marktonderzoek-xxxx.onrender.com`).

---

## Step 4 — Try it

- Public survey: `https://YOUR-URL/survey.html`
- Admin login: `https://YOUR-URL/login.html` (use the `ADMIN_USER`/`ADMIN_PASS` from Render)
- After login: results dashboard at `https://YOUR-URL/results.html`

Share the survey URL with respondents. The first response will create the `survey_responses` table in Neon automatically.

---

## Updating the app later

Edit any file locally, then:

```powershell
git add .
git commit -m "describe what you changed"
git push
```

Render auto-deploys within a minute.

---

## Free-tier gotchas

- **Render free** spins the service down after 15 min of no traffic. The first request after that takes ~30 seconds to wake up. Subsequent requests are instant. Fine for a survey shared with friends. If you're sending it to hundreds of respondents at once, upgrade Render to the $7/month "Starter" plan — it never sleeps.
- **Neon free** auto-suspends idle databases. Same wake-up delay. Storage limit 0.5 GB (≈ ~50,000 survey responses).
- Survey answers survive everything. The Render filesystem is wiped on every restart, but that's fine because data lives in Neon.

---

## Troubleshooting

**"Application Error" on Render**
Open the **Logs** tab on Render. Most likely: `DATABASE_URL` is wrong/missing, or the Neon project was deleted. Re-paste the connection string and click **Manual Deploy → Deploy latest commit**.

**Survey submits but nothing in admin**
Check `https://YOUR-URL/health` — it should return `{"ok":true,"store":"postgres"}`. If `store` says `file`, your `DATABASE_URL` env var isn't being loaded. Re-check Render's Environment tab.

**Want to download all answers as CSV**
Login as admin, go to `https://YOUR-URL/results.html`, click the export button. Or hit `https://YOUR-URL/api/responses/export` directly while logged in.
