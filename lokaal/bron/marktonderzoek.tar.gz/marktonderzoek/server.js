// Marktonderzoek — survey + admin Express app.
// Deployable to Render/Railway/Fly. Local dev still works with no env vars.
//
//   PORT                  - injected by host (default 3000 locally)
//   ADMIN_USER / ADMIN_PASS - admin credentials (default admin/jamiljamila2025)
//   SESSION_SECRET        - random 32+ char string (uses dev default if missing)
//   DATABASE_URL          - Postgres connection string (Neon, Supabase, Render Postgres, etc).
//                           If unset, falls back to a local data/responses.json file.

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const session = require('express-session');

const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'jamiljamila2025';
const VIEWER_USER = process.env.VIEWER_USER || '';
const VIEWER_PASS = process.env.VIEWER_PASS || '';
const SESSION_SECRET = process.env.SESSION_SECRET || 'alnoor_dev_secret_change_me';
const DATABASE_URL = process.env.DATABASE_URL || '';
const RESPONSES_FILE = path.join(__dirname, 'data', 'responses.json');

const app = express();
app.set('trust proxy', 1); // Render/Heroku put us behind a proxy
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use((req, res, next) => { res.setHeader('ngrok-skip-browser-warning', '1'); next(); });
app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 8 * 60 * 60 * 1000,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
  },
}));

// ─── Storage layer ──────────────────────────────────────────
// Two backends: Postgres (when DATABASE_URL is set) or JSON file (local dev).
let store;

if (DATABASE_URL) {
  const { Pool } = require('pg');
  const pool = new Pool({
    connectionString: DATABASE_URL,
    ssl: DATABASE_URL.includes('localhost') ? false : { rejectUnauthorized: false },
  });
  // Create the table on first boot.
  pool.query(`
    CREATE TABLE IF NOT EXISTS survey_responses (
      id BIGSERIAL PRIMARY KEY,
      submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      answers JSONB NOT NULL
    );
  `).then(() => console.log('[db] Postgres ready.'))
    .catch(err => console.error('[db] Failed to init Postgres:', err.message));
  store = {
    async list() {
      const { rows } = await pool.query('SELECT id, submitted_at, answers FROM survey_responses ORDER BY id DESC');
      return rows.map(r => ({ id: String(r.id), timestamp: r.submitted_at.toISOString(), answers: r.answers }));
    },
    async add(answers) {
      await pool.query('INSERT INTO survey_responses (answers) VALUES ($1)', [answers]);
    },
    async clear() {
      await pool.query('DELETE FROM survey_responses');
    },
  };
  console.log('[store] Using Postgres backend.');
} else {
  function readResponses() {
    if (!fs.existsSync(RESPONSES_FILE)) return { responses: [] };
    return JSON.parse(fs.readFileSync(RESPONSES_FILE, 'utf-8'));
  }
  function writeResponses(data) {
    fs.mkdirSync(path.dirname(RESPONSES_FILE), { recursive: true });
    fs.writeFileSync(RESPONSES_FILE, JSON.stringify(data, null, 2));
  }
  store = {
    async list() { return readResponses().responses.slice().reverse(); },
    async add(answers) {
      const data = readResponses();
      data.responses.push({ id: Date.now().toString(), timestamp: new Date().toISOString(), answers });
      writeResponses(data);
    },
    async clear() { writeResponses({ responses: [] }); },
  };
  console.log('[store] Using local JSON file (data/responses.json). Set DATABASE_URL for persistent hosting.');
}

// ─── Auth middleware ────────────────────────────────────────
function requireAuth(req, res, next) {
  if (req.session && (req.session.role === 'admin' || req.session.role === 'viewer')) return next();
  res.redirect('/login.html');
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.role === 'admin') return next();
  res.status(403).json({ error: 'Alleen admin' });
}

// ─── Public pages ──────────────────────────────────────────
app.use('/survey.html', express.static(path.join(__dirname, 'survey.html')));
app.use('/login.html', express.static(path.join(__dirname, 'login.html')));
app.use('/node_modules', express.static(path.join(__dirname, 'node_modules')));

// ─── Protected pages ───────────────────────────────────────
app.get('/results.html', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'results.html')));
app.get('/admin.html', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'admin.html')));

// Root
app.get('/', (req, res) => res.redirect('/survey.html'));

// Health check (Render likes this)
app.get('/health', (req, res) => res.json({ ok: true, store: DATABASE_URL ? 'postgres' : 'file' }));

// ─── Auth API ──────────────────────────────────────────────
app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    req.session.role = 'admin';
    req.session.isAdmin = true; // backwards compat
    return res.json({ success: true, role: 'admin' });
  }
  if (VIEWER_USER && VIEWER_PASS && username === VIEWER_USER && password === VIEWER_PASS) {
    req.session.role = 'viewer';
    return res.json({ success: true, role: 'viewer' });
  }
  res.status(401).json({ error: 'Ongeldige gebruikersnaam of wachtwoord' });
});
app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ success: true }));
});
app.get('/api/auth', (req, res) => {
  const role = req.session && req.session.role;
  res.json({ authenticated: role === 'admin' || role === 'viewer', role: role || null });
});

// ─── Survey responses API ──────────────────────────────────
// Public: submit
app.post('/api/responses', async (req, res) => {
  try {
    await store.add(req.body);
    res.json({ success: true });
  } catch (err) {
    console.error('add response failed:', err);
    res.status(500).json({ error: 'Kon antwoord niet opslaan' });
  }
});

// Protected: list / clear / export
app.get('/api/responses', requireAuth, async (req, res) => {
  try { res.json(await store.list()); }
  catch (err) { console.error(err); res.status(500).json({ error: 'Storage error' }); }
});
app.delete('/api/responses', requireAdmin, async (req, res) => {
  try { await store.clear(); res.json({ success: true }); }
  catch (err) { console.error(err); res.status(500).json({ error: 'Storage error' }); }
});

app.get('/api/responses/export', requireAuth, async (req, res) => {
  const responses = await store.list();
  if (!responses.length) return res.status(400).json({ error: 'Geen antwoorden' });

  const headers = [
    'Tijdstip','Leeftijd','Geslacht','Achtergrond','Regio','Online frequentie',
    'Aankoopkanalen','Gelegenheden','Productcategorieën','Budget product',
    'Budget geschenk','Prijs','Authenticiteit','Halal','Duurzaamheid',
    'Snelle levering','Verpakking','Klantendienst','Loyaliteit',
    'Wat mist u','Wat uniek','E-mail',
  ];

  const rows = responses.map(r => {
    const a = r.answers || {};
    const matrix = (key) => {
      const v = a.matrix?.[key];
      return v ? ['Helemaal niet','Niet','Neutraal','Belangrijk','Zeer'][v - 1] || v : '';
    };
    return [
      r.timestamp,
      a.leeftijd || '', a.geslacht || '',
      Array.isArray(a.achtergrond) ? a.achtergrond.join('; ') : (a.achtergrond || ''),
      a.regio || '', a.frequentie || '',
      Array.isArray(a.kanalen) ? a.kanalen.join('; ') : (a.kanalen || ''),
      Array.isArray(a.gelegenheden) ? a.gelegenheden.join('; ') : (a.gelegenheden || ''),
      Array.isArray(a.categorieen) ? a.categorieen.join('; ') : (a.categorieen || ''),
      a.budget_product || '', a.budget_geschenk || '',
      matrix('prijs'), matrix('authenticiteit'), matrix('halal'),
      matrix('duurzaamheid'), matrix('levering'), matrix('verpakking'),
      matrix('klantendienst'), matrix('loyaliteit'),
      a.mist || '', a.uniek || '', a.email || '',
    ].map(v => `"${String(v).replace(/"/g, '""')}"`).join(',');
  });

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="resultaten.csv"');
  res.send('﻿' + [headers.join(','), ...rows].join('\n'));
});

app.listen(PORT, () => {
  console.log(`\nMarktonderzoek — server gestart`);
  console.log(`Listening on port ${PORT}`);
  console.log(`Admin: ${ADMIN_USER}`);
});
